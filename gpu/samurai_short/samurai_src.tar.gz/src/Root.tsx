import React, { useEffect } from "react";
import { Composition } from "remotion";
import { SamuraiShort, SAMURAI_FRAMES } from "./videos/samurai/SamuraiShort";
const Probe: React.FC = () => {
  useEffect(() => {
    try {
      const c = document.createElement("canvas");
      const g: any = c.getContext("webgl2") || c.getContext("webgl");
      const e = g && g.getExtension("WEBGL_debug_renderer_info");
      console.error("GLRENDERER " + (e ? g.getParameter(e.UNMASKED_RENDERER_WEBGL) : "none"));
    } catch (err) { console.error("GLRENDERER error " + err); }
  }, []);
  return null;
};
const WrappedSam: React.FC = () => <><Probe /><SamuraiShort /></>;
export const Root: React.FC = () => (
  <Composition id="SamuraiShort" component={WrappedSam} durationInFrames={SAMURAI_FRAMES} fps={30} width={1080} height={1920} />
);
