// 2D samurai for the duel short: a posable side-view fighter drawn on the same Pen as the rest of our cast
// (bean head, ink-rimmed round limbs, flat fills). Design space 600 x 1000 (soles at y = 975), facing +x (screen right);
// the Actor's `mirror` flips it. Poses are authored y-UP, x forward: hands relative to the hip, feet as [dx, height];
// arms and legs are solved with two-bone IK so every pose reads as a body. Poses interpolate field by field.
import { Pen, INK, SKIN, mix, shade, headBlob, blobPts, Expr, faceSide, taper, rad, thickAngle } from "../lake/toon";

type P2 = [number, number];
export type Look = {
  kimono: string; hakama: string; obi: string; hair: string; band?: string; steel?: string; tsuka: string; skin?: string;
  seed: number; scarf?: string;
};
export const RONIN: Look = { kimono: "#b8323a", hakama: "#2a2f45", obi: "#e8c45a", hair: "#241726", band: "#f4f1ea", tsuka: "#1d2b4a", seed: 3 };
export const MASTER: Look = { kimono: "#2f5f9a", hakama: "#d8d3c4", obi: "#241726", hair: "#6b6b78", band: "#2f5f9a", tsuka: "#8a2f35", seed: 5 };

export type Blade = {
  /** angle of the blade line in degrees, y-up, 0 = pointing forward, 90 = up, 180 = back, -90 = down */
  ang: number; len?: number; held: "F" | "both" | "B" | "none"; vis?: boolean;
};
export type Pose = {
  hip: P2;                 // hip offset from rest [x forward, y up] in units
  lean: number;            // torso lean forward (deg)
  head: number;            // head tilt (deg, + = chin up)
  hF: P2; hB: P2;          // front / back hand, relative to the hip, y up
  fF: P2; fB: P2;          // front / back foot: [dx from rest hip x, height above the ground]
  blade: Blade;
  blade2?: Blade;          // second (short) sword, held in the back hand
  saya?: boolean;          // scabbard on the hip
  sayaAng?: number;        // scabbard angle (deg, y-up; default -150 = tip back and down)
  expr?: Expr;
  spin?: number;           // whole-body roll (deg) about the body centre, for flips and spinning cuts
  squash?: number;         // 1 = none
  wx?: number;             // world offset along the fight line in metres (lunges, leaps)
  wy?: number;             // world height in metres (jumps; the card leaves the ground)
};

const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const l2 = (a: P2, b: P2, t: number): P2 => [lerp(a[0], b[0], t), lerp(a[1], b[1], t)];
const ease = (t: number) => t * t * (3 - 2 * t);

export const blend = (a: Pose, b: Pose, t: number): Pose => {
  const bl = (x: Blade | undefined, y: Blade | undefined): Blade | undefined => {
    if (!x && !y) return undefined;
    const A = x ?? y!, B = y ?? x!;
    // shortest-arc angle blend
    let d = ((B.ang - A.ang + 540) % 360) - 180;
    return { ang: A.ang + d * t, len: lerp(A.len ?? 300, B.len ?? 300, t), held: t < 0.5 ? A.held : B.held, vis: t < 0.5 ? A.vis : B.vis };
  };
  return {
    hip: l2(a.hip, b.hip, t), lean: lerp(a.lean, b.lean, t), head: lerp(a.head, b.head, t),
    hF: l2(a.hF, b.hF, t), hB: l2(a.hB, b.hB, t), fF: l2(a.fF, b.fF, t), fB: l2(a.fB, b.fB, t),
    blade: bl(a.blade, b.blade)!, blade2: bl(a.blade2, b.blade2),
    saya: t < 0.5 ? a.saya : b.saya, sayaAng: lerp(a.sayaAng ?? -150, b.sayaAng ?? -150, t),
    expr: t < 0.5 ? a.expr : b.expr, spin: lerp(a.spin ?? 0, b.spin ?? 0, t), squash: lerp(a.squash ?? 1, b.squash ?? 1, t),
    wx: lerp(a.wx ?? 0, b.wx ?? 0, t), wy: lerp(a.wy ?? 0, b.wy ?? 0, t),
  };
};
export const ease01 = ease;

/** two-bone solve in y-down canvas space; `bend` = +1 puts the middle joint on the left of root->tip (screen-right facing) */
const ik2 = (root: P2, tip: P2, l1: number, l2_: number, bend: number): { mid: P2; tip: P2 } => {
  let dx = tip[0] - root[0], dy = tip[1] - root[1];
  let d = Math.hypot(dx, dy);
  const max = l1 + l2_ - 0.5;
  if (d > max) { dx *= max / d; dy *= max / d; d = max; tip = [root[0] + dx, root[1] + dy]; }
  d = Math.max(d, Math.abs(l1 - l2_) + 1);
  const a = Math.acos(Math.max(-1, Math.min(1, (l1 * l1 + d * d - l2_ * l2_) / (2 * l1 * d))));
  const base = Math.atan2(dy, dx), k = base + bend * a;
  return { mid: [root[0] + l1 * Math.cos(k), root[1] + l1 * Math.sin(k)], tip };
};

export const CARD_W = 1300, CARD_H = 1250, GROUND = 1225;
const REST_HIP: P2 = [600, 918];
const TORSO = 205, NECK = 28, UA = 100, FA = 98, TH = 152, SHIN = 150;

export const REST: Pose = {
  hip: [0, 0], lean: 0, head: 0, hF: [60, -10], hB: [40, -40], fF: [30, 0], fB: [-30, 0],
  blade: { ang: 60, held: "none", vis: false }, expr: "stern",
};

/** draw one fighter */
export const drawSamurai = (p: Pen, L: Look, po: Pose, light = rad(-120)) => {
  const g = p.g, u = 1, skin = L.skin ?? SKIN;
  const sq = po.squash ?? 1;
  const hip: P2 = [REST_HIP[0] + po.hip[0], REST_HIP[1] - po.hip[1]];
  const lean = rad(po.lean);
  const Y = (v: P2): P2 => [v[0], v[1]];
  // whole-body roll for flips
  if (po.spin) { p.rot = [rad(-po.spin), hip[0], hip[1] - 120]; } else p.rot = null;
  const ink = INK;
  const legCol = shade(L.hakama, 0.78), legColF = L.hakama, armColB = mix(L.kimono, ink, 0.3), armColF = L.kimono;
  const sho: P2 = [hip[0] + Math.sin(lean) * TORSO, hip[1] - Math.cos(lean) * TORSO * sq];
  const neck: P2 = [sho[0] + Math.sin(lean) * NECK, sho[1] - Math.cos(lean) * NECK];
  const H = { ...headBlob(L.seed, 62, 1), asym: 0.1 };
  const hc: P2 = [neck[0] + Math.sin(lean) * 56 + 8, neck[1] - Math.cos(lean) * 56];
  // ---- targets ----
  const handF: P2 = [hip[0] + po.hF[0], hip[1] - po.hF[1]], handB: P2 = [hip[0] + po.hB[0], hip[1] - po.hB[1]];
  const footF: P2 = [REST_HIP[0] + po.fF[0] + po.hip[0] * 0, GROUND - po.fF[1]], footB: P2 = [REST_HIP[0] + po.fB[0], GROUND - po.fB[1]];
  // legs (knees forward = toward +x: for a leg pointing down, the left of root->tip in canvas is +x ... bend = -1)
  const legF = ik2([hip[0] + 6, hip[1]], [footF[0], footF[1] - 8], TH, SHIN, -1);
  const legB = ik2([hip[0] - 6, hip[1]], [footB[0], footB[1] - 8], TH, SHIN, -1);
  // arms: elbows hang down/back
  const armF = ik2(sho, handF, UA, FA, 1), armB = ik2(sho, handB, UA, FA, 1);

  const limb = (a: P2, k: P2, b: P2, w1: number, w2: number, col: string, colEnd = col) => {
    p.line([a, k], col, w1);
    p.line([k, b], colEnd, w2);
  };
  const foot = (f: P2, from: P2, col: string) => {
    // a small tabi / sandal pointing forward, aligned loosely with the shin
    const ang = Math.atan2(f[1] - from[1], f[0] - from[0]);
    const pitch = Math.max(-0.6, Math.min(0.9, ang - Math.PI / 2));
    p.line([[f[0] - 8, f[1] + 2], [f[0] + 34 * Math.cos(pitch * 0.5), f[1] + 8 + 34 * Math.sin(pitch * 0.5) * 0.4]], col, 20);
  };

  // ---- back leg ----
  limb([hip[0] - 6, hip[1]], legB.mid, [footB[0], footB[1] - 8], 58, 44, legCol);
  foot(footB, legB.mid, shade("#e8e2d4", 0.7));
  // ---- back arm (behind torso) unless it holds the sword ----
  const holdB = po.blade.held === "both" || po.blade.held === "B";
  if (!holdB) {
    limb(sho, armB.mid, armB.tip, 30, 26, armColB);
    p.dot(armB.tip[0], armB.tip[1], 15, skin); p.ell(armB.tip[0], armB.tip[1], 15, 15, skin, 6);
  }
  // ---- scabbard (behind the belt line) ----
  const drawSaya = () => {
    const a = rad(po.sayaAng ?? -150);
    const base: P2 = [hip[0] - 4, hip[1] - 26];
    const tip: P2 = [base[0] + Math.cos(a) * 250, base[1] - Math.sin(a) * 250];
    p.line([base, tip], "#1d1722", 14);
    p.stroke([[base[0] + Math.cos(a) * 40, base[1] - Math.sin(a) * 40], [tip[0] - Math.cos(a) * 20, tip[1] + Math.sin(a) * 20]], 4, "#5a4a63");
    p.line([base, [base[0] + Math.cos(a) * 26, base[1] - Math.sin(a) * 26]], L.tsuka, 20);
  };
  // ---- torso: kimono capsule + obi ----
  p.line([[hip[0], hip[1] + 6], [sho[0], sho[1]]], L.kimono, 122);
  // obi band across the waist (perpendicular to the torso axis)
  {
    const ax: P2 = [Math.sin(lean), -Math.cos(lean)], nx: P2 = [-ax[1], ax[0]];
    const c: P2 = [hip[0] + ax[0] * 34, hip[1] + ax[1] * 34];
    p.band([[c[0] - nx[0] * 54, c[1] - nx[1] * 54], [c[0] + nx[0] * 54, c[1] + nx[1] * 54]], L.obi, 30, 5);
    // collar: crossed V at the chest
    const ch: P2 = [sho[0] + ax[0] * 6, sho[1] + ax[1] * 6];
    p.stroke([[ch[0] - nx[0] * 30 + ax[0] * 12, ch[1] - nx[1] * 30 + ax[1] * 12], [hip[0] + ax[0] * 90 + nx[0] * 6, hip[1] + ax[1] * 90 + nx[1] * 6]], 7, "#f4f1ea");
    p.stroke([[ch[0] + nx[0] * 30 + ax[0] * 12, ch[1] + nx[1] * 30 + ax[1] * 12], [hip[0] + ax[0] * 90 - nx[0] * 6, hip[1] + ax[1] * 90 - nx[1] * 6]], 7, "#f4f1ea");
  }
  if (po.saya) drawSaya();
  // ---- front leg ----
  limb([hip[0] + 6, hip[1]], legF.mid, [footF[0], footF[1] - 8], 62, 46, legColF);
  foot(footF, legF.mid, "#efe9db");
  // ---- head ----
  p.rot = po.spin ? [rad(-po.spin), hip[0], hip[1] - 120] : null;
  {
    const tilt = rad(po.head - po.lean * 0.4);
    const hp = blobPts(0, 0, { ...H, rot: H.rot }, 64).map(([x, y]) => [hc[0] + x * Math.cos(-tilt) - y * Math.sin(-tilt), hc[1] + x * Math.sin(-tilt) + y * Math.cos(-tilt)] as P2);
    // topknot behind the crown
    const kx = hc[0] - 30 * Math.cos(-tilt), ky = hc[1] - 66 * Math.cos(-tilt);
    p.ell(kx, ky, 17, 13, L.hair, 6, 0, 360, -20);
    p.poly(hp, skin, 8);
    // hair cap: back and top of the head
    p.clip(hp, () => {
      // hair: a crescent over the back and top of the head (hairline stops well before the face)
      const cap: P2[] = [];
      for (let i = 0; i <= 16; i++) { const a = rad(150 + (i * 172) / 16); cap.push([hc[0] + Math.cos(a) * 96, hc[1] + Math.sin(a) * 96]); }
      for (let i = 16; i >= 0; i--) { const a = rad(150 + (i * 172) / 16); cap.push([hc[0] + Math.cos(a) * 40 - 4, hc[1] + Math.sin(a) * 36 - 6]); }
      p.poly(cap, L.hair, 0);
      if (L.band) p.band([[hc[0] - 70, hc[1] - 44], [hc[0] + 70, hc[1] - 50]], L.band, 14, 3);
    });
    p.poly(hp, null, 8);
    faceSide(p, hc[0] - 4, hc[1] + 8, 2 * 62, po.expr ?? "stern", 0, false, skin);
    if (L.band) {
      // headband tail fluttering behind
      p.stroke([[hc[0] - 56, hc[1] - 48], [hc[0] - 92, hc[1] - 34], [hc[0] - 124, hc[1] - 50]], 12, L.band);
    }
  }
  // ---- weapons ----
  const sword = (b: Blade, grip: P2, hand2: P2 | null, tsukaCol: string, bladeLen: number) => {
    const a = rad(b.ang), dx = Math.cos(a), dy = -Math.sin(a);
    const tLen = 74;
    const pommel: P2 = [grip[0] - dx * 28, grip[1] - dy * 28];
    const tsuba: P2 = [grip[0] + dx * (tLen - 28), grip[1] + dy * (tLen - 28)];
    const tip: P2 = [tsuba[0] + dx * bladeLen, tsuba[1] + dy * bladeLen];
    if (b.vis !== false) {
      // blade: steel body with ink rim, a thin highlight and a pointed tip
      p.line([tsuba, [tip[0] - dx * 18, tip[1] - dy * 18]], "#dfe6ee", 9, true);
      p.stroke([[tsuba[0] + dx * 10, tsuba[1] + dy * 10], [tip[0] - dx * 30, tip[1] - dy * 30]], 3, "#ffffff");
      taper(p, [tip[0] - dx * 22, tip[1] - dy * 22], tip, 12, 3, INK);
    }
    p.line([pommel, tsuba], tsukaCol, 15, true);
    for (let i = 1; i < 4; i++) {
      const q: P2 = [pommel[0] + dx * i * 12 * 1.5 + 8, pommel[1] + dy * i * 12 * 1.5], nx = -dy, ny = dx;
      p.stroke([[q[0] - nx * 7, q[1] - ny * 7], [q[0] + nx * 7, q[1] + ny * 7]], 3, mix(tsukaCol, "#ffffff", 0.45));
    }
    p.ell(tsuba[0], tsuba[1], 10, 20, "#c7a24a", 5, 0, 360, b.ang + 90 - 90);
    return { tip, tsuba, pommel };
  };
  const b1 = po.blade;
  let held1: P2 | null = null;
  if (b1.held !== "none") {
    // grip point: the hand the sword is held in; with `both` the front hand is the lead hand near the guard
    held1 = b1.held === "B" ? armB.tip : armF.tip;
  }
  if (held1 && b1.held !== "none") {
    const info = sword(b1, held1, null, L.tsuka, b1.len ?? 300);
    if (b1.held === "both") {
      // back hand on the pommel end: re-solve the back arm onto the grip end
      const nb = ik2(sho, info.pommel, UA, FA, 1);
      limb(sho, nb.mid, nb.tip, 30, 26, armColB);
      p.ell(nb.tip[0], nb.tip[1], 15, 15, skin, 6);
    } else if (b1.held === "B") {
      limb(sho, armB.mid, armB.tip, 30, 26, armColB);
      p.ell(armB.tip[0], armB.tip[1], 15, 15, skin, 6);
    }
  }
  if (po.blade2) {
    const b2 = po.blade2;
    const hand2 = b2.held === "F" ? armF.tip : armB.tip;
    sword(b2, hand2, null, shade(L.tsuka, 0.9), b2.len ?? 190);
    if (b2.held === "B" && b1.held !== "B" && b1.held !== "both") { limb(sho, armB.mid, armB.tip, 30, 26, armColB); p.ell(armB.tip[0], armB.tip[1], 15, 15, skin, 6); }
  }
  // ---- front arm ----
  limb(sho, armF.mid, armF.tip, 32, 27, armColF);
  p.ell(armF.tip[0], armF.tip[1], 16, 16, skin, 6);
  p.rot = null;
  void g; void u; void Y; void thickAngle; void light;
};

/** a katana on its own (thrown sword card): 600 x 160 design, hilt on the left, blade pointing +x */
export const SWORD_W = 700, SWORD_H = 160;
export const drawSwordOnly = (p: Pen, L: Look, len = 420) => {
  const cy = SWORD_H / 2, x0 = 70;
  p.line([[x0 + 80, cy], [x0 + 80 + len, cy]], "#dfe6ee", 11, true);
  p.stroke([[x0 + 92, cy - 2], [x0 + 60 + len, cy - 2]], 3, "#ffffff");
  taper(p, [x0 + 60 + len, cy], [x0 + 100 + len, cy], 14, 3, INK);
  p.line([[x0 - 20, cy], [x0 + 80, cy]], L.tsuka, 17, true);
  p.ell(x0 + 80, cy, 10, 22, "#c7a24a", 5);
};
