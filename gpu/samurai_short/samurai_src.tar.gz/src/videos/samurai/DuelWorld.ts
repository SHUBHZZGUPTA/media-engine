// The duel world: a dusk temple courtyard (sand circle, torii, stone lanterns, bamboo, cherry trees, Fuji) lit by a low
// fixed sun, plus the paper-cut fighters: flat cards in the fight plane, "exploded" into ghost layers during freezes.
import * as THREE from "three";
import { LIGHTS, LOOK } from "../lake/lights";
import { TONE, untone } from "../lake/shade";
import { lam } from "../lake/build";
import { ctex } from "../lake/paint";
import { NOINK } from "../lake/ink";
import { Pool, Fx, Req } from "../lake/cast";
import { Pen, fxContact, fxBurst } from "../lake/toon";
import { drawSamurai, drawSwordOnly, RONIN, MASTER, CARD_W, CARD_H, GROUND, SWORD_W, SWORD_H, Look } from "./samurai";
import { Clock, FACE, Who, camAt, evalTrack, swordAt, freezeCx, HITS, SU } from "./duel";

const rnd = (seed: number, k = 0) => { const x = Math.sin(seed * 127.1 + k * 311.7) * 43758.5453; return x - Math.floor(x); };
const mat = (key: string, color: string) => lam(key, () => ({ color }));
const box = (m: THREE.Material, cx: number, cy: number, cz: number, sx: number, sy: number, sz: number) => {
  const o = new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), m); o.position.set(cx, cy, cz); o.castShadow = true; o.receiveShadow = true; return o;
};
const cyl = (m: THREE.Material, r0: number, r1: number, h: number, seg = 10) => {
  const o = new THREE.Mesh(new THREE.CylinderGeometry(r1, r0, h, seg), m); o.castShadow = true; o.receiveShadow = true; return o;
};
const ball = (m: THREE.Material, r: number, ws = 12, hs = 9) => { const o = new THREE.Mesh(new THREE.SphereGeometry(r, ws, hs), m); o.castShadow = true; o.receiveShadow = true; return o; };

const blank = (() => { const c = document.createElement("canvas"); c.width = c.height = 2; return new THREE.CanvasTexture(c); })();
const FIGHT = (() => { const g = new THREE.PlaneGeometry(CARD_W * SU, CARD_H * SU); g.translate((650 - 600) * SU, (GROUND - 625) * SU, 0); return g; })();
const SWORDG = (() => { const g = new THREE.PlaneGeometry(SWORD_W * SU, SWORD_H * SU); g.translate((350 - 150) * SU, 0, 0); return g; })();

class Card {
  mesh: THREE.Mesh; mat: THREE.MeshBasicMaterial; r: Req | null = null;
  constructor(parent: THREE.Object3D, geo: THREE.BufferGeometry) {
    this.mat = new THREE.MeshBasicMaterial({ map: blank, alphaTest: 0.5, side: THREE.DoubleSide });
    this.mat.alphaToCoverage = false;
    this.mesh = new THREE.Mesh(geo, this.mat);
    this.mesh.rotation.order = "YXZ"; this.mesh.layers.set(NOINK); this.mesh.visible = false; this.mesh.renderOrder = 1;
    parent.add(this.mesh);
  }
  bind() { const t = this.r?.tex; if (t) this.mat.map = t; }
}
const qk = (v: unknown) => JSON.stringify(v, (_k, x) => (typeof x === "number" ? Math.round(x * 2) / 2 : x));

export class DuelWorld {
  root = new THREE.Group();
  private pool = new Pool();
  private hemi: THREE.HemisphereLight; private sun: THREE.DirectionalLight;
  private skyMat: THREE.ShaderMaterial; private sky: THREE.Mesh;
  private fog = new THREE.Fog("#bccbec", 40, 380);
  private disc: THREE.Sprite; private halo: THREE.Sprite;
  private fighters: Card[] = []; private swords: Card[] = []; private tags: Fx[] = []; private blobs: Fx[] = [];
  private petals: THREE.Mesh[] = [];
  private SUN = new THREE.Vector3(0.28, 0.3, -1).normalize();
  private callouts: { key: string; w: number; h: number; draw: (p: Pen) => void; x: number; y: number; z: number }[] = [];

  constructor() {
    const R = this.root, K = LOOK.golden;
    this.skyMat = new THREE.ShaderMaterial({
      uniforms: { c0: { value: new THREE.Color() }, c1: { value: new THREE.Color() }, c2: { value: new THREE.Color() }, c3: { value: new THREE.Color() }, c4: { value: new THREE.Color() }, e: { value: new THREE.Vector4() } },
      vertexShader: "varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }",
      fragmentShader: `uniform vec3 c0, c1, c2, c3, c4; uniform vec4 e; varying vec3 vP;
        void main(){ float el = asin(clamp(normalize(vP).y, -1.0, 1.0));
          vec3 c = mix(c0, c1, smoothstep(0.0, e.x, el)); c = mix(c, c2, smoothstep(e.x, e.y, el));
          c = mix(c, c3, smoothstep(e.y, e.z, el)); c = mix(c, c4, smoothstep(e.z, e.w, el)); gl_FragColor = vec4(c, 1.0); }`,
      side: THREE.BackSide, depthWrite: false, fog: false,
    });
    this.sky = new THREE.Mesh(new THREE.SphereGeometry(1100, 48, 24), this.skyMat);
    this.sky.renderOrder = -1; this.sky.frustumCulled = false; this.sky.layers.set(NOINK); R.add(this.sky);
    const dtex = ctex("duelDisc", 128, 128, (g) => { const gr = g.createRadialGradient(64, 64, 58, 64, 64, 64); gr.addColorStop(0, "rgba(255,255,255,1)"); gr.addColorStop(1, "rgba(255,255,255,0)"); g.fillStyle = gr; g.fillRect(0, 0, 128, 128); });
    const htex = ctex("duelHalo", 256, 256, (g) => {
      const im = g.createImageData(256, 256);
      for (let y = 0; y < 256; y++) for (let x = 0; x < 256; x++) {
        const u = Math.hypot(x - 127.5, y - 127.5) / 128;
        const a = (0.55 * Math.exp(-((u / 0.25) ** 2)) + 0.35 * Math.exp(-((u / 0.6) ** 2))) * (1 - Math.min(1, Math.max(0, (u - 0.8) / 0.2)));
        const i = (y * 256 + x) * 4; im.data[i] = im.data[i + 1] = im.data[i + 2] = 255; im.data[i + 3] = Math.round(255 * Math.min(1, a));
      }
      g.putImageData(im, 0, 0);
    });
    this.disc = new THREE.Sprite(new THREE.SpriteMaterial({ map: dtex, color: new THREE.Color(6.0, 4.4, 2.4), fog: false, depthWrite: false }));
    this.halo = new THREE.Sprite(new THREE.SpriteMaterial({ map: htex, color: new THREE.Color(1, 1, 1), fog: false, depthWrite: false, depthTest: true, transparent: true, blending: THREE.AdditiveBlending }));
    this.disc.renderOrder = -0.5; this.halo.renderOrder = 5;
    for (const m of [this.disc, this.halo]) { m.frustumCulled = false; m.layers.set(NOINK); R.add(m); }
    this.hemi = new THREE.HemisphereLight("#cfe6ff", "#6c5c8c", 1.1);
    this.sun = new THREE.DirectionalLight("#ffab5e", 5.5);
    this.sun.castShadow = true; this.sun.shadow.mapSize.set(4096, 4096);
    R.add(this.hemi, this.sun, this.sun.target);
    void K;

    // ---- ground ----
    const grass = lam("duelGrass", () => ({ color: "#5b7a46" }));
    const field = new THREE.Mesh(new THREE.CircleGeometry(380, 64).rotateX(-Math.PI / 2), grass); field.receiveShadow = true; R.add(field);
    const rake = ctex("duelRake", 512, 512, (g, r) => {
      g.fillStyle = "#cfc6b8"; g.fillRect(0, 0, 512, 512);
      for (let i = 0; i < 16; i++) { g.strokeStyle = i % 2 ? "rgba(120,100,90,0.16)" : "rgba(255,250,240,0.2)"; g.lineWidth = 7; g.beginPath(); g.moveTo(0, i * 32 + 8); g.lineTo(512, i * 32 + 8); g.stroke(); }
      for (let i = 0; i < 400; i++) { g.fillStyle = `rgba(${120 + r() * 60},${90 + r() * 40},60,0.18)`; g.fillRect(r() * 512, r() * 512, 3, 3); }
    });
    rake.repeat.set(3, 3);
    const sand = new THREE.Mesh(new THREE.CircleGeometry(7.6, 72).rotateX(-Math.PI / 2), lam("duelSand", () => ({ map: rake })));
    sand.position.y = 0.012; sand.receiveShadow = true; R.add(sand);
    const stones = mat("duelStone", "#9b9aa6");
    for (let i = 0; i < 44; i++) {
      const a = (i / 44) * Math.PI * 2, s = box(stones, Math.cos(a) * 7.75, 0.1, Math.sin(a) * 7.75, 0.62, 0.22, 0.34); s.rotation.y = -a; s.scale.y = 0.8 + rnd(i, 2) * 0.5; R.add(s);
    }
    // ---- torii (north and south) ----
    const red = mat("duelRed", "#c23a2c"), black = mat("duelBlack", "#231c24");
    for (const sz of [-1, 1]) {
      const g = new THREE.Group();
      for (const px of [-2.6, 2.6]) { const c = cyl(red, 0.34, 0.3, 6.2, 12); c.position.set(px, 3.1, 0); g.add(c); const b = box(black, px, 0.12, 0, 0.8, 0.24, 0.8); g.add(b); }
      g.add(box(red, 0, 5.2, 0, 6.6, 0.26, 0.42)); // nuki
      const k = box(black, 0, 6.35, 0, 9.0, 0.32, 0.7); g.add(k);
      const k2 = box(red, 0, 6.05, 0, 7.8, 0.34, 0.55); g.add(k2);
      g.add(box(red, 0, 5.75, 0, 0.5, 0.7, 0.5));
      g.position.set(0, 0, sz * 12.5); if (sz > 0) g.rotation.y = Math.PI;
      R.add(g);
    }
    // ---- stone lanterns on the ring ----
    const lampLit = new THREE.MeshBasicMaterial({ color: new THREE.Color(3.2, 1.9, 0.8), fog: false });
    for (let i = 0; i < 6; i++) {
      const a = ((i + 0.5) / 6) * Math.PI * 2, x = Math.cos(a) * 9.2, z = Math.sin(a) * 9.2, g = new THREE.Group();
      const b0 = cyl(stones, 0.42, 0.36, 0.28, 8); b0.position.y = 0.14; g.add(b0);
      const post = cyl(stones, 0.14, 0.12, 1.05, 8); post.position.y = 0.8; g.add(post);
      const lamp = box(stones, 0, 1.55, 0, 0.62, 0.52, 0.62); g.add(lamp);
      const fire = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.3, 0.64), lampLit); fire.position.y = 1.55; g.add(fire);
      const fire2 = new THREE.Mesh(new THREE.BoxGeometry(0.64, 0.3, 0.38), lampLit); fire2.position.y = 1.55; g.add(fire2);
      const roof = new THREE.Mesh(new THREE.ConeGeometry(0.62, 0.42, 4), stones); roof.position.y = 2.0; roof.rotation.y = Math.PI / 4; roof.castShadow = true; g.add(roof);
      g.position.set(x, 0, z); R.add(g);
    }
    // ---- bamboo grove ----
    const bam = [mat("bam0", "#6e9a45"), mat("bam1", "#86ad52"), mat("bam2", "#5a8a40")];
    for (let i = 0; i < 150; i++) {
      const a = rnd(i, 1) * Math.PI * 2, r = 14 + Math.pow(rnd(i, 2), 1.3) * 26, h = 11 + rnd(i, 3) * 6, rr = 0.07 + rnd(i, 4) * 0.06;
      const c = cyl(bam[i % 3], rr, rr * 0.8, h, 7); c.position.set(Math.cos(a) * r, h / 2, Math.sin(a) * r); c.castShadow = i < 45; R.add(c);
      const lf = ball(bam[(i + 1) % 3], 1.3, 7, 5); lf.scale.set(1, 0.5, 1); lf.position.set(Math.cos(a) * r, h - 0.4, Math.sin(a) * r); lf.castShadow = false; R.add(lf);
    }
    // ---- cherry trees ----
    const bark = mat("duelBark", "#4d3a38"), pink = [mat("pinkA", "#f3a6bf"), mat("pinkB", "#ee8fb0"), mat("pinkC", "#f8c0d0")];
    for (let i = 0; i < 9; i++) {
      const a = (i / 9) * Math.PI * 2 + 0.35, r = 12 + rnd(i, 7) * 4, g = new THREE.Group();
      const t = cyl(bark, 0.34, 0.2, 3.4, 8); t.position.y = 1.7; g.add(t);
      for (let k = 0; k < 5; k++) { const b = ball(pink[(i + k) % 3], 1.5 + rnd(i * 5 + k, 1), 9, 7); b.position.set((rnd(i + k, 3) - 0.5) * 3, 3.6 + rnd(i + k, 4) * 1.6, (rnd(i + k, 5) - 0.5) * 3); g.add(b); }
      g.position.set(Math.cos(a) * r, 0, Math.sin(a) * r); R.add(g);
    }
    // ---- hills + Fuji ----
    const hillM = [mat("hillA", "#4f7a58"), mat("hillB", "#456c5a"), mat("hillC", "#58825f")];
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * Math.PI * 2 + 0.2, r = 200 + rnd(i, 5) * 60, s = 50 + rnd(i, 6) * 40;
      const h = ball(hillM[i % 3], 1, 24, 14); h.position.set(Math.cos(a) * r, -s * 0.25, Math.sin(a) * r); h.scale.set(s * 1.6, s * 0.7, s * 1.3); h.castShadow = false; R.add(h);
    }
    const fuji = cyl(mat("fuji", "#5d6d9d"), 120, 6, 125, 40); fuji.position.set(-60, 55, -300); fuji.castShadow = false; R.add(fuji);
    const snow = cyl(mat("fujiSnow", "#f1ecf4"), 33, 6, 40, 40); snow.position.set(-60, 98, -300); snow.castShadow = false; R.add(snow);
    // ---- petals ----
    const pm = new THREE.MeshBasicMaterial({ color: new THREE.Color(1.6, 0.95, 1.05), side: THREE.DoubleSide, fog: true });
    const pg = new THREE.PlaneGeometry(0.12, 0.08);
    for (let i = 0; i < 110; i++) { const m = new THREE.Mesh(pg, pm); m.layers.set(NOINK); R.add(m); this.petals.push(m); }
  }

  private card(list: Card[], i: number, geo: THREE.BufferGeometry) { while (list.length <= i) list.push(new Card(this.root, geo)); return list[i]; }
  private fx(list: Fx[], i: number) { while (list.length <= i) list.push(new Fx(this.root)); return list[i]; }

  update(c: Clock, cam: THREE.PerspectiveCamera, scene: THREE.Scene) {
    const L = LIGHTS.golden, K = LOOK.golden;
    const { cam: cs, yaw, explode } = camAt(c);
    cam.position.set(...cs.pos); cam.up.set(0, 1, 0); cam.lookAt(...cs.look); cam.rotateZ(cs.roll);
    cam.fov = cs.fov; cam.near = 0.2; cam.far = 1500; cam.updateProjectionMatrix(); cam.updateMatrixWorld();
    cam.layers.enable(NOINK);
    const focus = new THREE.Vector3(...cs.look);
    // ---- lights ----
    this.hemi.color.set(L.sky); this.hemi.groundColor.set(L.ground); this.hemi.intensity = L.hemiI;
    this.sun.color.set(L.sunCol); this.sun.intensity = L.sunI;
    this.sun.position.set(0, 0, 0).addScaledVector(this.SUN, 220); this.sun.target.position.set(0, 0, 0);
    const sc = this.sun.shadow.camera; sc.left = -16; sc.right = 16; sc.top = 16; sc.bottom = -16; sc.near = 20; sc.far = 480; sc.updateProjectionMatrix();
    this.sun.shadow.bias = L.bias; this.sun.shadow.normalBias = L.normalBias * 1.4;
    TONE.uLitCol.value.set(1.45, 1.0, 0.62); TONE.uShadeCol.value.set(0.5, 0.42, 0.55); TONE.uShadeLift.value.set(...L.lift);
    TONE.uLambert.value = L.lambert; TONE.uSideK.value = L.sideK; TONE.uTerm.value = L.term; TONE.uBounce.value.set(...K.bounce); TONE.uSat.value = K.sat;
    const su = this.skyMat.uniforms;
    K.sky.c.forEach((h, i) => untone(h, su["c" + i].value));
    const e = K.sky.e.map((d) => THREE.MathUtils.degToRad(d));
    su.e.value.set(e[1], e[2], e[3], e[4]);
    this.sky.position.copy(cam.position);
    untone(L.fog, this.fog.color); this.fog.near = 40; this.fog.far = 380; scene.fog = this.fog; scene.background = null;
    this.disc.position.copy(cam.position).addScaledVector(this.SUN, 900); this.disc.scale.setScalar(2 * 900 * Math.tan(THREE.MathUtils.degToRad(1.9)));
    this.halo.position.copy(this.disc.position); this.halo.scale.setScalar(2 * 900 * Math.tan(THREE.MathUtils.degToRad(26)));
    (this.halo.material as THREE.SpriteMaterial).color.set(L.sunDisc).multiplyScalar(1.3);
    // ---- petals ----
    const T = c.T;
    this.petals.forEach((m, i) => {
      const sp = 0.35 + rnd(i, 1) * 0.5, ph = rnd(i, 2) * 60;
      const x = ((rnd(i, 3) * 40 - 20 + T * (0.9 + rnd(i, 6) * 0.6) + ph) % 40) - 20, y = 7 - ((T * sp + rnd(i, 4) * 7) % 7), z = rnd(i, 5) * 30 - 15 + Math.sin(T * 1.3 + i) * 0.6;
      m.position.set(x, y, z); m.rotation.set(T * 2 + i, T * 1.7 + i * 2, T * 1.1);
      m.visible = m.position.distanceTo(cam.position) > 2.5;
    });
    // ---- cast ----
    const fz = c.fz, hero: Who | null = fz ? fz.hero : null;
    const cx = fz ? freezeCx(fz) : 0;
    const co = Math.cos(yaw), si = Math.sin(yaw);
    const place = (x: number, z: number): [number, number] => [cx + (x - cx) * co + z * si, -(x - cx) * si + z * co];
    let fi = 0, wi = 0, ti = 0, bi = 0;
    const used: Card[] = [], fused: Fx[] = [];
    const lookOf = (w: Who): Look => (w === "ronin" ? RONIN : MASTER);
    const TINT = new THREE.Color(1.02, 0.92, 0.82), GHOST = new THREE.Color(0.72, 0.8, 1.05);
    const putFighter = (w: Who, tw: number, xo: number, yo: number, z: number, ghost: boolean) => {
      const st = evalTrack(w, tw), a = this.card(this.fighters, fi++, FIGHT);
      a.r = this.pool.req(`F|${w}|${qk(st.pose)}`, CARD_W, CARD_H, 1, (p) => drawSamurai(p, lookOf(w), st.pose));
      const [px, pz] = place(xo, z);
      a.mesh.visible = true; a.mesh.position.set(px, yo, pz); a.mesh.rotation.set(0, yaw, 0); a.mesh.scale.set(FACE[w], 1, 1);
      a.mat.color.copy(ghost ? GHOST : TINT);
      used.push(a);
      // contact blob
      const b = this.fx(this.blobs, bi++); const k = Math.max(0.35, 1 - yo * 0.45);
      b.r = this.pool.req("blob|contact|#857b9c", 128, 128, 1, (p) => fxContact(p, "#857b9c")); b.use(false); b.mesh.visible = true;
      b.mesh.position.set(px, 0.03, pz); b.mesh.rotation.set(-Math.PI / 2, 0, 0); b.mesh.scale.set(1.0 * k, 0.55 * k, 1); fused.push(b);
      return st;
    };
    const putSword = (id: 1 | 2, tw: number, xo: number, z: number, ghost: boolean, yoff = 0) => {
      const s = swordAt(id, tw); if (!s.on) return;
      const who: Who = id === 1 ? "master" : "ronin", a = this.card(this.swords, wi++, SWORDG);
      a.r = this.pool.req(`S|${who}`, SWORD_W, SWORD_H, 1, (p) => drawSwordOnly(p, lookOf(who), 420));
      const [px, pz] = place(xo === 0 ? s.x : xo, z);
      a.mesh.visible = true; a.mesh.position.set(px, s.y + yoff, pz); a.mesh.rotation.set(0, yaw, s.roll * (s.face)); a.mesh.scale.set(s.face, 1, 1);
      a.mat.color.copy(ghost ? GHOST : TINT); used.push(a);
    };
    const tw = c.tw;
    this.callouts = [];
    const other: Who | null = hero ? (hero === "ronin" ? "master" : "ronin") : null;
    for (const w of ["ronin", "master"] as Who[]) {
      if (hero === w && fz) {
        const main = evalTrack(w, tw), n = fz.ghosts.length;
        fz.ghosts.forEach((gt, j) => {
          if (explode < 0.02) return;
          const g = evalTrack(w, gt), dep = n - j;
          const gx = main.x + (g.x - main.x) * explode - FACE[w] * dep * 0.4 * explode, gy = main.wy + (g.wy - main.wy) * explode;
          putFighter(w, gt, gx, gy, -dep * 0.95 * explode, true);
          this.callouts.push({ key: `${j + 1}`, w: j + 1, h: 0, draw: () => {}, x: gx, y: gy, z: -dep * 0.95 * explode });
        });
        putFighter(w, tw, main.x, main.wy, 0, false);
        this.callouts.push({ key: `${n + 1}`, w: n + 1, h: 0, draw: () => {}, x: main.x, y: main.wy, z: 0 });
      } else putFighter(w, tw, evalTrack(w, tw).x, evalTrack(w, tw).wy, 0, false);
    }
    void other;
    putSword(1, tw, 0, 0, false); putSword(2, tw, 0, 0, false);
    if (fz?.swordGhosts && explode > 0.02) fz.swordGhosts.forEach((sg, j) => { const dep = fz.swordGhosts!.length - j; const s = swordAt(sg.id, sg.t); putSword(sg.id, sg.t, s.x - FACE[fz.hero] * 0.3 * explode * dep, -dep * 0.5 * explode, true); });
    // impact bursts
    for (const h of HITS) {
      const age = ((fz && Math.abs(fz.tw - h.t) < 1e-6 ? c.u * c.dur : tw - h.t)) / 0.5;
      if (age < 0 || age >= 1) continue;
      const u = Math.round(age * 12) / 12, b2 = this.fx(this.tags, ti++);
      b2.r = this.pool.req(`burst${u}`, 500, 500, 1, (p) => fxBurst(p, u)); b2.use(false); b2.mesh.visible = true;
      const [px, pz] = place(h.x, 0.3);
      b2.mesh.position.set(px, h.y, pz); b2.mesh.quaternion.copy(cam.quaternion); b2.mesh.scale.set(h.s, h.s, 1); fused.push(b2);
    }
    // step callouts (numbered pills over the ghosts and the hero)
    if (fz && explode > 0.3) {
      this.callouts.forEach((co2, j) => {
        const label = fz.tag.steps[j] ?? "", a = Math.min(1, (explode - 0.3) / 0.5);
        const f2 = this.fx(this.tags, ti++);
        f2.r = this.pool.req(`tag|${j + 1}|${label}`, 512, 128, 1, (p) => {
          const g = p.g; g.clearRect(0, 0, 512, 128);
          g.font = "bold 62px BigShoulders, sans-serif"; const tw2 = g.measureText(label).width;
          const W = 150 + tw2, X = 256 - W / 2;
          g.fillStyle = "rgba(20,14,28,0.92)"; g.beginPath(); (g as any).roundRect(X, 20, W, 88, 44); g.fill();
          g.strokeStyle = "#ffffff"; g.lineWidth = 5; g.stroke();
          g.fillStyle = "#ffd23f"; g.beginPath(); g.arc(X + 50, 64, 34, 0, Math.PI * 2); g.fill();
          g.fillStyle = "#231c24"; g.textAlign = "center"; g.textBaseline = "middle"; g.fillText(String(j + 1), X + 50, 68);
          g.fillStyle = "#ffffff"; g.textAlign = "left"; g.fillText(label, X + 100, 68);
        });
        f2.use(false); f2.mesh.visible = true;
        const [px, pz] = place(co2.x, co2.z);
        f2.mesh.position.set(px, co2.y + 1.25 + (j % 3) * 0.31, pz); f2.mesh.quaternion.copy(cam.quaternion);
        const s = 1.35 * (0.6 + 0.4 * a); f2.mesh.scale.set(s, s / 4, 1); fused.push(f2);
      });
    }
    for (let i = fi; i < this.fighters.length; i++) this.fighters[i].mesh.visible = false;
    for (let i = wi; i < this.swords.length; i++) this.swords[i].mesh.visible = false;
    for (let i = ti; i < this.tags.length; i++) this.tags[i].mesh.visible = false;
    for (let i = bi; i < this.blobs.length; i++) this.blobs[i].mesh.visible = false;
    this.pool.flush();
    for (const a of used) a.bind();
    for (const f3 of fused) f3.bind();
    return focus;
  }
}
