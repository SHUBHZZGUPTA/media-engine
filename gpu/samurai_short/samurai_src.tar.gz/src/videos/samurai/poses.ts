// Pose library for the duel (y-up, x forward). Hands are relative to the hip; feet are [dx, height].
import { Pose, REST } from "./samurai";

const P = (o: Partial<Pose> & { blade: Pose["blade"] }): Pose => ({ ...REST, ...o });
const KAT = (ang: number, held: "F" | "both" | "B" | "none" = "both", len = 310) => ({ ang, held, len, vis: true });

export const POSES: Record<string, Pose> = {
  stand: P({ hip: [0, 0], hF: [28, 4], hB: [-8, 6], fF: [20, 0], fB: [-24, 0], saya: true, blade: { ang: 0, held: "none", vis: false } }),
  // hand on the hilt, weight low: the iai stance
  iai: P({ hip: [4, -70], lean: 8, hF: [68, 10], hB: [-30, 26], fF: [95, 0], fB: [-80, 0], saya: true, sayaAng: -168, expr: "stern",
    blade: { ang: -168, held: "none", vis: false } }),
  // the draw-cut itself: sword out of the scabbard, sweeping across the front
  draw: P({ hip: [30, -75], lean: 18, hF: [190, 55], hB: [-40, 28], fF: [130, 0], fB: [-90, 0], saya: true, sayaAng: -168, expr: "stern",
    blade: KAT(8, "F", 330) }),
  cutEnd: P({ hip: [60, -85], lean: 28, hF: [200, 5], hB: [-50, 30], fF: [160, 0], fB: [-100, 0], saya: true, sayaAng: -168, expr: "stern",
    blade: KAT(-35, "F", 330) }),
  ready: P({ hip: [0, -40], lean: 4, hF: [120, 62], fF: [80, 0], fB: [-70, 0], blade: KAT(28, "both"), expr: "stern" }),
  jodan: P({ hip: [10, -45], lean: 2, hF: [60, 330], fF: [90, 0], fB: [-70, 0], blade: KAT(95, "both"), expr: "stern" }),
  chop: P({ hip: [40, -70], lean: 22, hF: [200, 60], fF: [130, 0], fB: [-90, 0], blade: KAT(-12, "both"), expr: "laugh" }),
  // two-sword guard: long sword forward, short sword raised behind
  nito: P({ hip: [0, -50], lean: 4, hF: [140, 75], hB: [30, 175], fF: [95, 0], fB: [-75, 0], blade: KAT(18, "F", 320),
    blade2: { ang: 105, held: "B", len: 190, vis: true }, expr: "stern" }),
  // throw: arm extended, blade flat and flying
  throw: P({ hip: [20, -55], lean: 14, hF: [210, 120], hB: [-60, 40], fF: [110, 0], fB: [-90, 0], blade: KAT(4, "F", 300), expr: "shock" }),
  noSword: P({ hip: [0, -50], lean: 8, hF: [140, 100], hB: [100, 140], fF: [90, 0], fB: [-70, 0], blade: { ang: 0, held: "none", vis: false }, expr: "shock" }),
  // flying kick: body high, front leg driven forward
  kick: P({ hip: [30, 260], lean: 12, hF: [-30, 120], hB: [-90, 60], fF: [270, 330], fB: [-120, 190], blade: KAT(150, "F", 300), spin: -4, expr: "grin" }),
  jump: P({ hip: [0, 240], lean: -6, hF: [90, 280], hB: [20, 300], fF: [40, 120], fB: [-60, 80], blade: KAT(80, "both", 320), expr: "grin" }),
  muto: P({ hip: [30, -65], lean: 16, hF: [190, 40], hB: [130, 120], fF: [120, 0], fB: [-90, 0], blade: { ang: 0, held: "none", vis: false }, expr: "stern" }),
};

// ---- extra poses for the choreography ----
const X = (name: string, o: Partial<Pose> & { blade?: Pose["blade"] }) => { POSES[name] = P({ blade: { ang: 0, held: "none", vis: false }, ...o }); };
X("crouch", { hip: [0, -120], lean: 14, hF: [70, -10], hB: [-30, 10], fF: [60, 0], fB: [-60, 0], expr: "stern" });
X("duck", { hip: [-30, -130], lean: 30, hF: [90, -60], hB: [-10, -40], fF: [30, 0], fB: [-100, 0], expr: "shock" });
X("stagger", { hip: [-40, -30], lean: -22, head: 12, hF: [60, 150], hB: [-70, 110], fF: [10, 0], fB: [-120, 0], expr: "pained" });
X("bow", { hip: [0, -10], lean: 42, head: -10, hF: [40, -30], hB: [0, -30], fF: [20, 0], fB: [-24, 0], expr: "neutral", saya: true, sayaAng: -160 });
X("grab", { hip: [40, -75], lean: 20, hF: [190, 150], hB: [170, 100], fF: [130, 0], fB: [-90, 0], expr: "stern" });
X("twist", { hip: [60, -80], lean: 26, hF: [150, 40], hB: [190, 90], fF: [150, 0], fB: [-90, 0], expr: "grin" });
X("overhead", { hip: [20, -60], lean: 6, hF: [90, 300], fF: [110, 0], fB: [-70, 0], blade: KAT(125, "both"), expr: "stern" });
X("cutDown", { hip: [50, -85], lean: 24, hF: [210, 30], fF: [150, 0], fB: [-90, 0], blade: KAT(-50, "both"), expr: "laugh" });
X("spinCut", { hip: [20, 250], lean: 0, hF: [160, 130], hB: [100, 120], fF: [80, 190], fB: [-80, 160], blade: KAT(0, "both"), spin: 0, expr: "grin" });
X("land", { hip: [60, -100], lean: 18, hF: [180, 20], hB: [100, 40], fF: [150, 0], fB: [-80, 0], blade: KAT(-20, "both"), expr: "grin" });
// the thrown-sword follow through: arm out, no blade
X("thrown", { hip: [30, -65], lean: 18, hF: [220, 110], hB: [-60, 50], fF: [120, 0], fB: [-90, 0], expr: "stern" });
// ready with the sword already out and the second blade drawn
X("clash", { hip: [20, -55], lean: 10, hF: [150, 150], hB: [95, 170], fF: [100, 0], fB: [-80, 0], blade: KAT(52, "F", 320),
  blade2: { ang: 38, held: "B", len: 190, vis: true }, expr: "stern" });
// leaping body for the flying kick (ghosts and apex)
X("leap", { hip: [10, 200], lean: 8, hF: [-30, 100], hB: [-70, 70], fF: [220, 250], fB: [-100, 200], expr: "grin" });
X("leapUp", { hip: [0, 130], lean: -4, hF: [60, 140], hB: [10, 120], fF: [60, 80], fB: [-40, 60], blade: KAT(75, "both", 320), expr: "grin" });
POSES.spinB = { ...POSES.spinCut, spin: -360 };
