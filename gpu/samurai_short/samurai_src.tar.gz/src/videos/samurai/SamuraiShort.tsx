// "Samurai duel breakdown": 2D paper-cut fighters in a 3D dusk courtyard; freeze moments explode each move into ghost layers while the camera orbits.
// Post chain identical to the lake short (ink -> lens blur -> bloom + NEUTRAL tone map + golden grade).
import React, { useEffect, useMemo, useState } from "react";
import * as THREE from "three";
import { AbsoluteFill, continueRender, delayRender, getInputProps, staticFile, useCurrentFrame } from "remotion";
import { ThreeCanvas } from "@remotion/three";
import { useThree } from "@react-three/fiber";
import { EffectComposer } from "@react-three/postprocessing";
import { BlendFunction, BloomEffect, ToneMappingEffect, ToneMappingMode } from "postprocessing";
import { InkPass, noInkFallback } from "../lake/ink";
import { LensBlur } from "../lake/lensblur";
import { GradeEffect, GRADES, GRADE_STRENGTH, gradeFor } from "../lake/grade";
import { DuelWorld } from "./DuelWorld";
import { TOTAL, FPS, FREEZES, FZ_SPAN, clockAt, Clock } from "./duel";
import { CAPS } from "./caps";

export const SAMURAI_FRAMES = TOTAL;
const makeBloom = () => {
  const b = new BloomEffect({ blendFunction: BlendFunction.ADD, intensity: 0.5, luminanceThreshold: 1.0, luminanceSmoothing: 0.2, mipmapBlur: true, levels: 6, radius: 0.6 });
  const mip = b.mipmapBlurPass; const setSize = mip.setSize.bind(mip);
  mip.setSize = (w: number, h: number) => setSize(Math.round((1920 * w) / Math.max(h, 1)), 1920);
  return b;
};
const useFonts = () => {
  const [ok, setOk] = useState(false);
  const [h] = useState(() => delayRender("samurai fonts"));
  useEffect(() => {
    const load = (name: string, file: string, weight = "700") => new FontFace(name, `url(${staticFile("samurai/" + file)})`, { weight }).load().then((f) => document.fonts.add(f));
    Promise.all([load("BigShoulders", "BigShoulders-Bold.ttf"), load("Bricolage", "BricolageGrotesque-Bold.ttf"), load("BricolageR", "BricolageGrotesque-Regular.ttf", "400")])
      .catch((e) => console.error("font load failed " + e)).finally(() => { setOk(true); continueRender(h); });
  }, [h]);
  return ok;
};

const fwd = new THREE.Vector3(), fpt = new THREE.Vector3();
const Inner: React.FC = () => {
  const f = useCurrentFrame();
  const { camera, scene } = useThree();
  const world = useMemo(() => new DuelWorld(), []);
  const fx = useMemo(() => ({
    ink: new InkPass(scene, camera as THREE.PerspectiveCamera), lens: new LensBlur({ maxCoC: 24, nearScale: 1.2 }), bloom: makeBloom(),
    tone: new ToneMappingEffect({ mode: ToneMappingMode.NEUTRAL }), grade: new GradeEffect(GRADES.golden, GRADE_STRENGTH.golden),
  }), [camera, scene]);
  useEffect(() => () => fx.ink.dispose(), [fx]);
  const post = useMemo(() => (
    <EffectComposer multisampling={4}>
      <primitive object={fx.ink} dispose={null} />
      <primitive object={fx.lens.pre} dispose={null} /><primitive object={fx.lens.main} dispose={null} />
      <primitive object={fx.bloom} dispose={null} /><primitive object={fx.tone} dispose={null} /><primitive object={fx.grade} dispose={null} />
    </EffectComposer>
  ), [fx]);
  const cam = camera as THREE.PerspectiveCamera;
  const target = world.update(clockAt(f), cam, scene);
  noInkFallback(world.root);
  cam.getWorldDirection(fwd);
  fx.lens.focus = Math.max(0.3, fpt.copy(target).sub(cam.position).dot(fwd));
  fx.lens.cInf = 9;
  gradeFor(fx.grade, "golden");
  return <><primitive object={world.root} dispose={null} />{post}</>;
};
const dprOverride = () => (getInputProps() as { post?: { dpr?: number } }).post?.dpr;

// ---------------- overlay ----------------
const Overlay: React.FC<{ c: Clock; f: number }> = ({ c, f }) => {
  const T = c.T, fz = c.fz;
  const pops = (t0: number, d = 0.35) => Math.min(1, Math.max(0, (T - t0) / d));
  const back = (x: number) => 1 + 1.7 * Math.pow(x - 1, 3) + 0.7 * Math.pow(x - 1, 2);
  const fi = c.fi, doneN = FZ_SPAN.filter((sp) => T >= sp[1]).length;
  const inT = fz ? c.u * c.dur : 0;
  const flash = fz && inT < 0.14 ? [0.9, 0.6, 0.35, 0.15][Math.floor(inT * FPS)] ?? 0 : 0;
  const outT = fz ? Math.max(0, c.dur - inT) : 0;
  const tagA = fz ? Math.min(back(Math.min(1, Math.max(0, (inT - 0.25) / 0.45))), 1.06) * Math.min(1, outT / 0.3) : 0;
  const doc = fz?.tag.kind === "DOCUMENTED";
  const nm = fz?.tag.name ?? "";
  return (
    <AbsoluteFill style={{ pointerEvents: "none" }}>
      {fz && <AbsoluteFill style={{ background: "radial-gradient(ellipse at 50% 45%, rgba(0,0,0,0) 45%, rgba(20,10,30,0.5) 100%)" }} />}
      {/* header strip + progress pips */}
      <div style={{ position: "absolute", top: 64, left: 0, right: 0, textAlign: "center", fontFamily: "Bricolage, sans-serif", fontWeight: 700, fontSize: 30, letterSpacing: 8, color: "rgba(255,255,255,0.9)", textShadow: "0 2px 8px rgba(0,0,0,0.5)" }}>SAMURAI DUEL BREAKDOWN</div>
      <div style={{ position: "absolute", top: 118, left: 0, right: 0, display: "flex", justifyContent: "center", gap: 16 }}>
        {FREEZES.map((z, i) => (
          <div key={i} style={{ width: 70, height: 10, borderRadius: 5, background: i < doneN || i === fi ? (z.tag.kind === "DOCUMENTED" ? "#3ddc84" : "#ff3d81") : "rgba(255,255,255,0.3)", opacity: i === fi ? 1 : 0.85 }} />
        ))}
      </div>
      {T < 3.7 && (
        <div style={{ position: "absolute", top: 250, left: 40, right: 40, textAlign: "center", fontFamily: "BigShoulders, sans-serif", fontWeight: 700, fontSize: 170, lineHeight: 0.95, color: "#fff", textShadow: "0 6px 0 #231c24, 0 0 30px rgba(0,0,0,0.4)", opacity: Math.min(1, pops(0.2)) * Math.min(1, (3.7 - T) / 0.4) }}>
          TWO SAMURAI.<br /><span style={{ color: "#ffd23f" }}>ONE DUEL.</span>
        </div>
      )}
      {fz && (
        <div style={{ position: "absolute", left: 56, right: 56, top: 160, transform: `translateY(${(1 - tagA) * -80}px) scale(${0.94 + 0.06 * tagA})`, opacity: Math.min(1, tagA * 1.5), background: "rgba(24,16,32,0.86)", border: "4px solid #fff", borderRadius: 30, padding: "20px 36px 24px", boxShadow: "0 10px 40px rgba(0,0,0,0.45)" }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 12, background: doc ? "#3ddc84" : "#ff3d81", color: "#17101d", fontFamily: "Bricolage, sans-serif", fontWeight: 700, fontSize: 34, letterSpacing: 4, padding: "8px 22px 8px 16px", borderRadius: 40 }}>
            <span style={{ width: 20, height: 20, borderRadius: 10, background: "#17101d", display: "inline-block" }} />{fz.tag.kind}
          </div>
          <div style={{ fontFamily: "BigShoulders, sans-serif", fontWeight: 700, fontSize: Math.min(170, 2300 / Math.max(8, nm.length)), lineHeight: 1.0, color: "#fff", marginTop: 8, whiteSpace: "nowrap" }}>{nm}</div>
          <div style={{ fontFamily: "Bricolage, sans-serif", fontWeight: 700, fontSize: 44, color: "#ffd23f", marginTop: 2 }}>{fz.tag.school}</div>
          <div style={{ fontFamily: "BricolageR, sans-serif", fontWeight: 400, fontSize: 38, lineHeight: 1.22, color: "rgba(255,255,255,0.95)", marginTop: 10 }}>{fz.tag.fact}</div>
        </div>
      )}
      {T >= 51.5 && (
        <div style={{ position: "absolute", left: 40, right: 40, top: 230, textAlign: "center" }}>
          <div style={{ fontFamily: "BigShoulders, sans-serif", fontWeight: 700, fontSize: 150, lineHeight: 0.95, color: "#fff", textShadow: "0 6px 0 #231c24" }}>
            <div style={{ opacity: pops(51.6, 0.3) }}>FIVE MOVES.</div>
            <div style={{ color: "#3ddc84", opacity: pops(52.7, 0.3) }}>FOUR ARE REAL.</div>
          </div>
          <div style={{ fontFamily: "Bricolage, sans-serif", fontWeight: 700, fontSize: 56, color: "#ffd23f", marginTop: 20, textShadow: "0 3px 0 #231c24", opacity: pops(53.8, 0.3) }}>WHICH WOULD YOU PICK?</div>
        </div>
      )}
      {CAPS.filter((k) => k.a >= 4 && T >= k.a && T < k.b).map((k, i) => (
        <div key={i} style={{ position: "absolute", left: 70, right: 70, bottom: 250, textAlign: "center", fontFamily: "Bricolage, sans-serif", fontWeight: 700, fontSize: 54, lineHeight: 1.2, color: "#fff", textShadow: "0 3px 0 #231c24, 0 0 14px rgba(0,0,0,0.6)" }}>{k.text}</div>
      ))}
      {flash > 0 && <AbsoluteFill style={{ background: "#fff", opacity: flash }} />}
      {fz && inT < 0.35 && (
        <svg width={1080} height={1920} style={{ position: "absolute", inset: 0, opacity: 1 - inT / 0.35 }}>
          {Array.from({ length: 28 }).map((_, i) => { const a = (i / 28) * Math.PI * 2 + 0.1, r0 = 330 + inT * 600, r1 = r0 + 520; return <line key={i} x1={540 + Math.cos(a) * r0} y1={1000 + Math.sin(a) * r0 * 1.5} x2={540 + Math.cos(a) * r1} y2={1000 + Math.sin(a) * r1 * 1.5} stroke="#fff" strokeWidth={5 + (i % 3) * 3} strokeLinecap="round" />; })}
        </svg>
      )}
    </AbsoluteFill>
  );
};

export const SamuraiShort: React.FC = () => {
  const f = useCurrentFrame();
  const ok = useFonts();
  if (!ok) return null;
  const c = clockAt(f);
  return (
    <AbsoluteFill style={{ background: "#2a1830" }}>
      <AbsoluteFill>
        <ThreeCanvas width={1080} height={1920} {...(dprOverride() ? { dpr: dprOverride() } : {})} shadows gl={{ antialias: false, stencil: false, powerPreference: "high-performance", toneMappingExposure: 1.0 }} camera={{ fov: 46, near: 0.2, far: 1500 }}>
          <Inner />
        </ThreeCanvas>
      </AbsoluteFill>
      <Overlay c={c} f={f} />
    </AbsoluteFill>
  );
};
