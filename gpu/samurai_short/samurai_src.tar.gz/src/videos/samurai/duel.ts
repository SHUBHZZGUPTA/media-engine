// Choreography, freeze moments and camera for the samurai duel short.
// World time `tw` (seconds of fight) is separate from real time T: each freeze holds tw while the camera keeps moving.
import { Pose, blend, ease01 } from "./samurai";
import { POSES } from "./poses";

export const FPS = 30;
export const SU = 0.0026; // metres per design unit (a standing fighter is ~1.8 m)
export type Who = "ronin" | "master";
export const FACE: Record<Who, number> = { ronin: 1, master: -1 };

// ---------------- tracks ----------------
type K = { t: number; pose: string; x: number; wy?: number; e?: number };
const RONIN: K[] = [
  { t: 0, pose: "stand", x: -2.2 }, { t: 3.5, pose: "stand", x: -2.2 }, { t: 5.0, pose: "iai", x: -1.7 }, { t: 6.5, pose: "iai", x: -1.7 },
  { t: 6.78, pose: "draw", x: -1.2, e: 0.6 }, { t: 7.0, pose: "cutEnd", x: -0.75, e: 0.6 },
  { t: 9.0, pose: "ready", x: -1.1 }, { t: 9.4, pose: "ready", x: -1.0 }, { t: 9.8, pose: "chop", x: -0.5, e: 0.6 },
  { t: 10.6, pose: "ready", x: -0.9 }, { t: 11.9, pose: "ready", x: -1.2 }, { t: 14.2, pose: "jodan", x: -1.4 }, { t: 14.8, pose: "jodan", x: -1.4 },
  { t: 15.2, pose: "duck", x: -1.5, e: 0.5 }, { t: 16.0, pose: "ready", x: -1.4 }, { t: 17.4, pose: "crouch", x: -1.3 }, { t: 18.0, pose: "crouch", x: -1.3 },
  { t: 18.4, pose: "leap", x: -0.8, wy: 0.35, e: 0.7 }, { t: 18.75, pose: "kick", x: 0.3, wy: 0.55, e: 0.6 },
  { t: 19.2, pose: "leapUp", x: 0.0, wy: 0.9 }, { t: 19.5, pose: "spinCut", x: 0.0, wy: 1.0 }, { t: 19.95, pose: "spinB", x: 0.0, wy: 1.0 },
  { t: 20.7, pose: "land", x: -0.2, wy: 0 }, { t: 21.2, pose: "ready", x: -0.8 }, { t: 21.55, pose: "overhead", x: -0.6 },
  { t: 22.0, pose: "cutDown", x: -0.3, e: 0.5 }, { t: 22.4, pose: "stagger", x: -0.9, e: 0.6 }, { t: 24.2, pose: "stagger", x: -1.1 }, { t: 25.0, pose: "bow", x: -1.3 }, { t: 27, pose: "bow", x: -1.3 },
];
const MASTER: K[] = [
  { t: 0, pose: "stand", x: 2.2 }, { t: 3.5, pose: "stand", x: 2.2 }, { t: 5.0, pose: "ready", x: 1.7 }, { t: 6.5, pose: "ready", x: 1.7 },
  { t: 6.9, pose: "duck", x: 2.0, e: 0.5 }, { t: 7.6, pose: "ready", x: 1.6 }, { t: 9.4, pose: "ready", x: 1.1 }, { t: 9.8, pose: "ready", x: 0.55, e: 0.6 },
  { t: 10.4, pose: "ready", x: 0.8 }, { t: 10.9, pose: "clash", x: 0.9 }, { t: 11.9, pose: "nito", x: 1.0 }, { t: 14.2, pose: "nito", x: 0.85 },
  { t: 14.8, pose: "throw", x: 0.7, e: 0.6 }, { t: 15.2, pose: "thrown", x: 0.65 }, { t: 16.4, pose: "noSword", x: 1.0 }, { t: 18.4, pose: "noSword", x: 0.95 },
  { t: 18.9, pose: "stagger", x: 1.35, e: 0.5 }, { t: 19.6, pose: "stagger", x: 1.7 }, { t: 20.7, pose: "noSword", x: 1.3 }, { t: 21.3, pose: "muto", x: 1.0 },
  { t: 21.8, pose: "muto", x: 0.85 }, { t: 22.1, pose: "grab", x: 0.7, e: 0.5 }, { t: 22.5, pose: "twist", x: 0.6 }, { t: 24.2, pose: "stand", x: 1.2 }, { t: 25.0, pose: "bow", x: 1.3 }, { t: 27, pose: "bow", x: 1.3 },
];
export const TRACKS: Record<Who, K[]> = { ronin: RONIN, master: MASTER };
export const TW_END = 26.4;

export type State = { pose: Pose; x: number; wy: number };
export const evalTrack = (who: Who, t: number): State => {
  const ks = TRACKS[who];
  let i = 0;
  while (i + 1 < ks.length - 1 && t >= ks[i + 1].t) i++;
  const a = ks[i], b = ks[Math.min(i + 1, ks.length - 1)];
  const raw = b.t > a.t ? Math.min(1, Math.max(0, (t - a.t) / (b.t - a.t))) : 1;
  const u = b.e ? Math.pow(raw, b.e) : ease01(raw);
  const pose = blend(POSES[a.pose], POSES[b.pose], u);
  return { pose, x: a.x + (b.x - a.x) * u, wy: (a.wy ?? 0) + ((b.wy ?? 0) - (a.wy ?? 0)) * u };
};

// ---------------- swords in flight ----------------
export type SwordS = { x: number; y: number; roll: number; face: number; on: boolean };
const sm = (u: number) => { const c = Math.min(1, Math.max(0, u)); return c * c * (3 - 2 * c); };
/** 1: thrown by the master (Empi) over the ducking ronin, plants in the ground. 2: the ronin's sword, twisted away in Muto. */
export const swordAt = (id: 1 | 2, t: number): SwordS => {
  if (id === 1) {
    if (t < 14.86) return { x: 0, y: 0, roll: 0, face: -1, on: false };
    if (t < 15.7) { const u = (t - 14.86) / 0.84; return { x: 0.25 + (-3.5 - 0.25) * u, y: 1.45 + 0.25 * Math.sin(u * Math.PI) - 0.5 * u, roll: 0.6 * u, face: -1, on: true }; }
    const u = sm((t - 15.7) / 0.25);
    return { x: -3.5, y: 0.95 - 0.0 * u, roll: 0.6 + (1.38 - 0.6) * u, face: -1, on: true };
  }
  if (t < 22.35) return { x: 0, y: 0, roll: 0, face: 1, on: false };
  if (t < 23.4) { const u = (t - 22.35) / 1.05; return { x: -0.1 + (-2.9) * u, y: 0.9 + 2.0 * Math.sin(u * Math.PI) * (1 - u) - 0.85 * u * u, roll: 9 * u, face: 1, on: true }; }
  return { x: -3.0, y: 0.06, roll: 9 + 0.12, face: 1, on: true };
};

/** impact bursts (world time t, world x, height y, size in metres) */
export const HITS = [{ t: 7.0, x: 0.2, y: 1.0, s: 1.7 }, { t: 9.8, x: 0.05, y: 1.1, s: 2.1 }, { t: 15.7, x: -3.5, y: 0.2, s: 1.3 }, { t: 18.78, x: 0.95, y: 1.15, s: 2.5 }, { t: 22.1, x: 0.25, y: 1.0, s: 1.6 }];

// ---------------- freezes ----------------
export type Tag = { kind: "DOCUMENTED" | "CINEMATIC"; name: string; school: string; fact: string; steps: string[] };
export type Freeze = { tw: number; hero: Who; ghosts: number[]; swordGhosts?: { id: 1 | 2; t: number }[]; spin?: boolean; tag: Tag; arc: [number, number]; r: [number, number]; h: [number, number]; fov: number };
export const FREEZES: Freeze[] = [
  { tw: 7.0, hero: "ronin", ghosts: [5.95, 6.8], arc: [-34, 42], r: [5.8, 4.8], h: [1.1, 1.4], fov: 46,
    tag: { kind: "DOCUMENTED", name: "IAIJUTSU", school: "Katori Shintō-ryū", fact: "Draw and cut in one motion: mostly a counter, sometimes a surprise.", steps: ["STANCE", "DRAW", "CUT"] } },
  { tw: 11.9, hero: "master", ghosts: [9.85, 10.9], arc: [30, -36], r: [5.8, 4.8], h: [1.2, 1.1], fov: 46,
    tag: { kind: "DOCUMENTED", name: "NITEN ICHI-RYŪ", school: "Miyamoto Musashi", fact: "“Two heavens as one”: katana and wakizashi together.", steps: ["BLOCK", "DRAW 2ND", "TWO BLADES"] } },
  { tw: 15.15, hero: "master", ghosts: [14.2, 14.8], swordGhosts: [{ id: 1, t: 14.98 }, { id: 1, t: 15.07 }], arc: [-32, 38], r: [6.2, 5.2], h: [1.1, 1.3], fov: 48,
    tag: { kind: "DOCUMENTED", name: "EMPI", school: "Yagyū Shinkage-ryū", fact: "“Swallow takes flight”: a thrown sword to spear the opponent.", steps: ["GUARD", "THROW", "RELEASE"] } },
  { tw: 19.58, hero: "ronin", ghosts: [18.0, 18.42, 18.75, 19.2], spin: true, arc: [0, 360], r: [5.8, 5.8], h: [1.1, 1.1], fov: 50,
    tag: { kind: "CINEMATIC", name: "FLYING KICK → SPIN CUT", school: "Movie flourish", fact: "We found no documented school for this one.", steps: ["CROUCH", "LEAP", "KICK", "JUMP", "SPIN CUT"] } },
  { tw: 22.1, hero: "master", ghosts: [21.25, 21.85], arc: [-30, 34], r: [5.6, 4.6], h: [1.2, 1.1], fov: 46,
    tag: { kind: "DOCUMENTED", name: "MUTŌ", school: "Yagyū Shinkage-ryū", fact: "Bare hands against the sword.", steps: ["DISARMED", "STEP IN", "WRIST CATCH"] } },
];
/** real time T (s, = voice time) -> world time tw. Segments with `fz` are freezes (tw held); others may run slower or faster than real time. */
type Seg = { T0: number; T1: number; tw0: number; tw1: number; fz?: number };
export const CLK: Seg[] = [
  { T0: 0, T1: 3.7, tw0: 0, tw1: 3.5 }, { T0: 3.7, T1: 6.6, tw0: 3.5, tw1: 7.0 }, { T0: 6.6, T1: 11.6, tw0: 7.0, tw1: 7.0, fz: 0 },
  { T0: 11.6, T1: 18.2, tw0: 7.0, tw1: 9.8 }, { T0: 18.2, T1: 21.0, tw0: 9.8, tw1: 11.9 }, { T0: 21.0, T1: 26.0, tw0: 11.9, tw1: 11.9, fz: 1 },
  { T0: 26.0, T1: 29.9, tw0: 11.9, tw1: 14.8 }, { T0: 29.9, T1: 30.7, tw0: 14.8, tw1: 15.15 }, { T0: 30.7, T1: 37.2, tw0: 15.15, tw1: 15.15, fz: 2 },
  { T0: 37.2, T1: 38.0, tw0: 15.15, tw1: 15.9 }, { T0: 38.0, T1: 39.0, tw0: 17.0, tw1: 18.0 }, { T0: 39.0, T1: 40.4, tw0: 18.0, tw1: 19.58 },
  { T0: 40.4, T1: 45.2, tw0: 19.58, tw1: 19.58, fz: 3 }, { T0: 45.2, T1: 48.5, tw0: 19.58, tw1: 22.1 }, { T0: 48.5, T1: 52.0, tw0: 22.1, tw1: 22.1, fz: 4 },
  { T0: 52.0, T1: 56.3, tw0: 22.1, tw1: 26.4 },
];
export const TOTAL_S = CLK[CLK.length - 1].T1;
export const TOTAL = Math.round(TOTAL_S * FPS);
export const FZ_SPAN = CLK.filter((s) => s.fz !== undefined).map((s) => [s.T0, s.T1] as const);

export type Clock = { tw: number; fz: Freeze | null; fi: number; u: number; T: number; dur: number };
export const clockAt = (f: number): Clock => {
  const T = Math.min(f / FPS, TOTAL_S - 1e-6);
  const s = CLK.find((x) => T >= x.T0 && T < x.T1) ?? CLK[CLK.length - 1];
  const u = (T - s.T0) / (s.T1 - s.T0);
  if (s.fz !== undefined) return { tw: s.tw0, fz: FREEZES[s.fz], fi: s.fz, u, T, dur: s.T1 - s.T0 };
  return { tw: s.tw0 + (s.tw1 - s.tw0) * u, fz: null, fi: -1, u, T, dur: 0 };
};

// ---------------- camera ----------------
export type V3 = [number, number, number];
export type CamS = { pos: V3; look: V3; fov: number; roll: number };
const glide = (u: number) => { const x = Math.min(1, Math.max(0, u)); return x * x * x * (x * (6 * x - 15) + 10); };
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
type On = "mid" | "ronin" | "master" | "zero";
type CK = { t: number; az: number; r: number; h: number; on: On; dx?: number; ly: number; fov: number; roll?: number; cut?: boolean };
const rad = (d: number) => (d * Math.PI) / 180;
const focusX = (on: On, tw: number) => on === "zero" ? 0 : on === "mid" ? (evalTrack("ronin", tw).x + evalTrack("master", tw).x) / 2 : evalTrack(on, tw).x;
const camPose = (k: CK, tw: number, az = k.az): CamS => {
  const lx = focusX(k.on, tw) + (k.dx ?? 0), look: V3 = [lx, k.ly, 0];
  return { pos: [lx + k.r * Math.sin(rad(az)), k.h, k.r * Math.cos(rad(az))], look, fov: k.fov, roll: k.roll ?? 0 };
};
const mixC = (a: CamS, b: CamS, k: number): CamS => ({
  pos: a.pos.map((v, i) => lerp(v, b.pos[i], k)) as V3, look: a.look.map((v, i) => lerp(v, b.look[i], k)) as V3, fov: lerp(a.fov, b.fov, k), roll: lerp(a.roll, b.roll, k),
});
/** play cameras, keyed in world time; `cut` keys jump, the others glide from the previous key */
const PLAY: CK[] = [
  { t: 0, az: 22, r: 10.5, h: 1.0, on: "mid", ly: 1.4, fov: 50 }, { t: 3.5, az: 6, r: 9.0, h: 1.2, on: "mid", ly: 1.35, fov: 50 },
  { t: 3.5, cut: true, az: -16, r: 7.6, h: 1.0, on: "mid", ly: 1.3, fov: 48 }, { t: 6.3, az: 8, r: 6.4, h: 1.05, on: "mid", ly: 1.3, fov: 48 },
  { t: 6.5, cut: true, az: -10, r: 5.2, h: 0.9, on: "ronin", dx: 0.6, ly: 1.25, fov: 46 }, { t: 7.0, az: -4, r: 4.8, h: 0.95, on: "ronin", dx: 0.7, ly: 1.25, fov: 46 },
  { t: 7.0, cut: true, az: 14, r: 7.6, h: 1.3, on: "mid", ly: 1.3, fov: 48 }, { t: 9.0, az: 4, r: 7.0, h: 1.2, on: "mid", ly: 1.3, fov: 48 },
  { t: 9.0, cut: true, az: -12, r: 5.4, h: 1.1, on: "mid", ly: 1.3, fov: 46 }, { t: 11.9, az: 10, r: 5.0, h: 1.2, on: "mid", ly: 1.3, fov: 46 },
  { t: 11.9, cut: true, az: 20, r: 6.6, h: 1.2, on: "master", dx: -0.4, ly: 1.3, fov: 47 }, { t: 14.2, az: 8, r: 5.8, h: 1.2, on: "master", dx: -0.5, ly: 1.3, fov: 47 },
  { t: 14.2, cut: true, az: -22, r: 8.2, h: 1.2, on: "mid", ly: 1.3, fov: 50 }, { t: 15.15, az: -12, r: 7.4, h: 1.2, on: "mid", ly: 1.3, fov: 50 },
  { t: 15.15, cut: true, az: 6, r: 7.8, h: 1.4, on: "mid", ly: 1.3, fov: 50 }, { t: 17.9, az: -2, r: 7.0, h: 1.2, on: "mid", ly: 1.3, fov: 50 },
  { t: 17.0, cut: true, az: -10, r: 7.4, h: 1.2, on: "mid", ly: 1.3, fov: 50 }, { t: 17.9, cut: true, az: -18, r: 5.8, h: 0.55, on: "ronin", dx: 0.9, ly: 1.25, fov: 54 }, { t: 19.58, az: 4, r: 6.2, h: 0.9, on: "ronin", dx: 0.9, ly: 1.35, fov: 54 },
  { t: 19.58, cut: true, az: 0, r: 8.4, h: 1.7, on: "mid", ly: 1.3, fov: 50 }, { t: 21.25, az: -8, r: 7.4, h: 1.4, on: "mid", ly: 1.3, fov: 48 },
  { t: 21.25, cut: true, az: 10, r: 5.4, h: 1.2, on: "mid", ly: 1.3, fov: 46 }, { t: 22.1, az: 2, r: 4.6, h: 1.2, on: "mid", ly: 1.3, fov: 46 },
  { t: 22.1, cut: true, az: -8, r: 7.6, h: 1.3, on: "mid", ly: 1.3, fov: 48 }, { t: 24.6, az: 4, r: 8.0, h: 2.0, on: "mid", ly: 1.3, fov: 48 },
  { t: 24.6, cut: true, az: 30, r: 9.5, h: 1.6, on: "zero", ly: 1.35, fov: 48 }, { t: TW_END, az: 20, r: 11.5, h: 4.0, on: "zero", ly: 1.3, fov: 46 },
];
const camPlayAt = (tw: number): CamS => {
  // find the active segment (last cut key <= tw), then glide to the next key
  let ci = 0;
  for (let i = 0; i < PLAY.length; i++) if (PLAY[i].t <= tw && PLAY[i].cut) ci = i;
  const a = PLAY[ci];
  const nx = PLAY[ci + 1];
  if (!nx || nx.cut) return camPose(a, tw);
  const k = glide((tw - a.t) / (nx.t - a.t));
  return mixC(camPose(a, tw), camPose(nx, tw), k);
};
export const freezeCx = (z: Freeze) => evalTrack(z.hero, z.tw).x - FACE[z.hero] * 0.1 * (z.ghosts.length + 1);
export const camFreeze = (z: Freeze, u: number, tw: number, dur: number): { cam: CamS; yaw: number; explode: number } => {
  const hx = evalTrack(z.hero, tw).x, g = glide(u);
  const az = z.spin ? 360 * g : lerp(z.arc[0], z.arc[1], g);
  // dolly: in/out, small crane for the spin
  const r = z.spin ? z.r[0] + 0.5 * Math.sin(Math.PI * g) : lerp(z.r[0], z.r[1], g);
  const h = z.spin ? z.h[0] + 0.7 * Math.sin(Math.PI * g) : lerp(z.h[0], z.h[1], g);
  const cx = freezeCx(z);
  const cam: CamS = { pos: [cx + r * Math.sin(rad(az)), h, r * Math.cos(rad(az))], look: [cx, z.spin ? 2.0 : 1.55, -0.6], fov: z.fov, roll: 0.02 * Math.sin(g * Math.PI * 2) };
  const yaw = z.spin ? az - 14 * Math.sin(Math.PI * g) : 0;
  // ghosts burst out in the first 0.55 s and fold back in the last 0.45 s
  const t0 = u * dur;
  const out = Math.min(1, t0 / 0.55), inn = Math.min(1, (dur - t0) / 0.45);
  const back = (x: number) => 1 + 2.2 * Math.pow(x - 1, 3) + 1.2 * Math.pow(x - 1, 2);
  const explode = Math.min(back(out), 1.12) * glide(inn);
  return { cam, yaw: (yaw * Math.PI) / 180, explode };
};
export const camAt = (c: Clock): { cam: CamS; yaw: number; explode: number } => {
  if (c.fz) return camFreeze(c.fz, c.u, c.tw, c.dur);
  const cam = camPlayAt(c.tw);
  // tiny hand-held drift
  const T = c.T;
  cam.pos = [cam.pos[0] + 0.03 * Math.sin(T * 0.9), cam.pos[1] + 0.02 * Math.sin(T * 1.3 + 1), cam.pos[2]];
  return { cam, yaw: 0, explode: 0 };
};
