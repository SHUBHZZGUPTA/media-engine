// 3D terrain scenes for the Snake Island video. Seekable: render(scene, cam, t) draws one frame.
import * as T3 from './three.module.js';
const W = 1920, H = 1080;
export const GL = {};
const R = new T3.WebGLRenderer({ canvas: document.getElementById('gl'), antialias: true, preserveDrawingBuffer: true });
const SS = +(new URLSearchParams(location.search).get('ss') || 1);
R.setPixelRatio(1); R.setSize(W * SS, H * SS, false);
R.outputColorSpace = T3.LinearSRGBColorSpace;
const META = await (await fetch('assets/terrain.json')).json();
const SCENES = {};
async function loadTex(url) { return await new Promise(r => new T3.TextureLoader().load(url, t => { t.colorSpace = T3.NoColorSpace; t.anisotropy = 16; t.generateMipmaps = true; t.minFilter = T3.LinearMipmapLinearFilter; r(t); })); }
async function build(name, exag) {
  const M = META[name]; const [gw, gh] = M.grid;
  const buf = await (await fetch(`assets/${name}_h.bin`)).arrayBuffer(); const h = new Float32Array(buf);
  const g = new T3.PlaneGeometry(M.wkm, M.hkm, gw - 1, gh - 1);
  const p = g.attributes.position;
  for (let i = 0; i < p.count; i++) p.setZ(i, h[i] / 1000 * exag);
  g.computeVertexNormals();
  const tex = await loadTex(`assets/${name}_tex.jpg`);
  const U = { map: { value: tex }, grade: { value: new T3.Vector3(1, 1, 1) }, dark: { value: 1 } };
  const mat = new T3.ShaderMaterial({ uniforms: U,
    vertexShader: `varying vec2 vUv; varying float vZ; varying vec3 vW; void main(){ vUv = uv; vZ = position.z; vec4 w = modelMatrix * vec4(position,1.0); vW = w.xyz; gl_Position = projectionMatrix * viewMatrix * w; }`,
    fragmentShader: `uniform sampler2D map; uniform vec3 grade; uniform float dark; varying vec2 vUv; varying float vZ; varying vec3 vW;
      void main(){ vec3 c = texture2D(map, vUv).rgb; float lu = dot(c, vec3(.3,.59,.11)); c = mix(vec3(lu), c, .85);
        c *= grade * dark; gl_FragColor = vec4(c, 1.0); }` });
  const mesh = new T3.Mesh(g, mat);
  // water
  const WU = { lvl: { value: 0 }, col: { value: new T3.Color('#1b5260') }, deep: { value: new T3.Color('#07222c') }, t: { value: 0 }, dark: { value: 1 } };
  const wmat = new T3.ShaderMaterial({ uniforms: WU, transparent: true, depthWrite: false,
    vertexShader: `uniform float lvl; varying vec2 vP; void main(){ vec3 p = position; p.z = lvl; vP = p.xy; gl_Position = projectionMatrix * modelViewMatrix * vec4(p,1.0); }`,
    fragmentShader: `uniform vec3 col, deep; uniform float t, dark; varying vec2 vP;
      float n(vec2 q){ return sin(q.x*7.0+t*0.9)*sin(q.y*6.0-t*0.7)*0.5+0.5; }
      void main(){ float w = n(vP*3.0)*0.6 + n(vP*11.0+3.0)*0.4; vec3 c = mix(deep, col, 0.55 + 0.25*w); gl_FragColor = vec4(c*dark, 0.97); }` });
  const water = new T3.Mesh(new T3.PlaneGeometry(M.wkm * 80, M.hkm * 80, 1, 1), wmat);
  const sc = new T3.Scene(); sc.add(mesh); sc.add(water);
  { const c = document.createElement('canvas'); c.width = 4; c.height = 256; const x = c.getContext('2d'); const gr = x.createLinearGradient(0, 0, 0, 256);
    gr.addColorStop(0, '#05101a'); gr.addColorStop(.55, '#123241'); gr.addColorStop(.75, '#3b4a52'); gr.addColorStop(1, '#0a1c24'); x.fillStyle = gr; x.fillRect(0, 0, 4, 256);
    const bt = new T3.CanvasTexture(c); sc.background = bt; }
  sc.fog = new T3.Fog('#1d3540', M.wkm * 0.6, M.wkm * 2.2);
  const [l0, l1, b0, b1] = M.bbox; const kx = M.wkm / (l1 - l0), ky = M.hkm / (b1 - b0);
  const toXY = (lon, lat) => [(lon - (l0 + l1) / 2) * kx, (lat - (b0 + b1) / 2) * ky];
  const hAt = (lon, lat) => { const u = (lon - l0) / (l1 - l0) * (gw - 1), v = (b1 - lat) / (b1 - b0) * (gh - 1);
    if (u < 0 || v < 0 || u > gw - 1 || v > gh - 1) return 0; const x = Math.floor(u), y = Math.floor(v), fx = u - x, fy = v - y, x1 = Math.min(x + 1, gw - 1), y1 = Math.min(y + 1, gh - 1);
    const g = (a, b) => h[b * gw + a]; return ((g(x, y) * (1 - fx) + g(x1, y) * fx) * (1 - fy) + (g(x, y1) * (1 - fx) + g(x1, y1) * fx) * fy) / 1000 * exag; };
  SCENES[name] = { sc, U, WU, toXY, hAt, M, exag, fogBase: [M.wkm * 0.6, M.wkm * 2.2] };
}
await build('island', 1.5);
await build('coast', 6.0);
const cam = new T3.PerspectiveCamera(35, W / H, 0.005, 3000); cam.up.set(0, 0, 1);
function ease(u) { u = Math.min(1, Math.max(0, u)); return u * u * (3 - 2 * u); }
function keyed(K, t) { if (t <= K[0][0]) return K[0].slice(1);
  for (let i = 1; i < K.length; i++) { const a = K[i - 1], b = K[i]; if (t <= b[0]) { const p = ease((t - a[0]) / (b[0] - a[0])); return a.slice(1).map((v, k) => v + (b[k + 1] - v) * p); } }
  return K[K.length - 1].slice(1); }
GL.keyed = keyed;
// cam keys: [t, lon, lat, distKm, elevDeg, yawDeg]; returns projector for labels
GL.render = (name, S, lt) => {
  const s = SCENES[name]; const k = keyed(S.cam, lt); const [lon, lat, dist, el, yaw] = k;
  const [tx, ty] = s.toXY(lon, lat); const tz = S.tz !== undefined ? S.tz : 0;
  const e = el * Math.PI / 180, y = yaw * Math.PI / 180;
  cam.position.set(tx + Math.sin(y) * Math.cos(e) * dist, ty - Math.cos(y) * Math.cos(e) * dist, tz + Math.sin(e) * dist);
  cam.lookAt(tx, ty, tz); cam.near = Math.max(0.003, dist / 400); cam.far = dist * 40 + 50; cam.updateProjectionMatrix(); cam.updateMatrixWorld();
  s.WU.lvl.value = (S.sea ? keyed(S.sea, lt)[0] : 0) / 1000 * s.exag; s.WU.t.value = lt;
  const dk = S.dark !== undefined ? S.dark : 0.8; s.U.dark.value = dk; s.WU.dark.value = dk;
  const gr = S.grade || [0.85, 1.0, 1.05]; s.U.grade.value.set(...gr);
  s.sc.fog.near = dist * 1.2; s.sc.fog.far = dist * 5;
  R.render(s.sc, cam);
  return (lon2, lat2, up) => { const [x, y2] = s.toXY(lon2, lat2); const v = new T3.Vector3(x, y2, s.hAt(lon2, lat2) + (up || 0)).project(cam);
    return [(v.x + 1) / 2 * W, (1 - v.y) / 2 * H, v.z]; };
};
GL.ready = true;
