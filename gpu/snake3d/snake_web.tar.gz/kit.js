// 2D vector kit: flat, dark, Depth-Theory-like look. Everything is a pure function of time.
export const W = 1920, H = 1080;
export const C = { red: '#E5141B', amber: '#F5A623', gold: '#D9A441', goldD: '#8A5A1C', ink: '#04121A', teal: '#0E2F3A', white: '#F2F2F2' };
export const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
export const ease = u => { u = clamp(u, 0, 1); return u * u * (3 - 2 * u); };
export const eout = u => { u = clamp(u, 0, 1); return 1 - Math.pow(1 - u, 3); };
export const eback = u => { u = clamp(u, 0, 1); const c1 = 1.70158, c3 = 2.70158; return 1 + c3 * Math.pow(u - 1, 3) + c1 * Math.pow(u - 1, 2); };
export const lerp = (a, b, u) => a + (b - a) * u;
export const ramp = (t, t0, d) => clamp((t - t0) / (d || .4), 0, 1);
// deterministic random
export function rnd(i) { const x = Math.sin(i * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); }

// ---------- backgrounds ----------
export function bg(kind, t, o = {}) {
  const pal = {
    forest: ['#0d2a24', '#05120f'], sea: ['#0d2c38', '#04121a'], night: ['#0b1626', '#03070d'], card: ['#10232b', '#050d12'],
    dawn: ['#2a3b40', '#0a1a20'], thermal: ['#1a0a35', '#070214'], lab: ['#14262c', '#061015'] }[kind] || ['#10232b', '#050d12'];
  let s = `<defs><radialGradient id="bgg" cx="50%" cy="38%" r="75%"><stop offset="0" stop-color="${pal[0]}"/><stop offset="1" stop-color="${pal[1]}"/></radialGradient>
    <linearGradient id="ray" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".16"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient></defs>
    <rect width="${W}" height="${H}" fill="url(#bgg)"/>`;
  if (o.rays !== false && kind !== 'thermal' && kind !== 'card') {
    for (let i = 0; i < 5; i++) { const x = 300 + i * 340 + Math.sin(t * .2 + i) * 30, w = 60 + rnd(i) * 90, sk = 220 + rnd(i + 9) * 160;
      s += `<polygon points="${x},-20 ${x + w},-20 ${x + w + sk},${H} ${x + sk - w * .5},${H}" fill="url(#ray)" opacity="${.35 + .25 * Math.sin(t * .5 + i * 2)}"/>`; }
  }
  return s;
}
export function particles(t, n = 60, col = '#cfe8e0', o = 0.5) {
  let s = '';
  for (let i = 0; i < n; i++) { const x = (rnd(i) * W + t * (8 + rnd(i + 3) * 18)) % W, y = (rnd(i + 7) * H - t * (6 + rnd(i + 5) * 14) + H * 10) % H, r = 1 + rnd(i + 11) * 2.4;
    s += `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${r.toFixed(1)}" fill="${col}" opacity="${(o * (.3 + .7 * rnd(i + 2)) * (.6 + .4 * Math.sin(t * 1.3 + i))).toFixed(2)}"/>`; }
  return s;
}
export function vignette() { return `<defs><radialGradient id="vg" cx="50%" cy="50%" r="72%"><stop offset=".6" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".55"/></radialGradient></defs><rect width="${W}" height="${H}" fill="url(#vg)"/>`; }

// ---------- text ----------
// rich label: words wrapped in [..] are red, {..} amber
export function rich(txt) { return txt.replace(/\[(.+?)\]/g, `<tspan fill="${C.red}">$1</tspan>`).replace(/\{(.+?)\}/g, `<tspan fill="${C.amber}">$1</tspan>`); }
export const OPT = { noBottom: true };   // bottom band text (narration written out) removed at Shubham's request
export function lab(t, t0, txt, x, y, o = {}) {
  if (OPT.noBottom && y >= 800 && !o.keep) return '';
  if (t < t0) return ''; if (o.out !== undefined && t >= o.out) return '';
  const a = eout(ramp(t, t0, .35)) * (o.out !== undefined ? clamp((o.out - t) / .2, 0, 1) : 1); const dy = (1 - a) * 18;
  const size = o.size || 46, anchor = o.anchor || 'middle', wt = o.weight || 800, col = o.color || C.white;
  return `<text x="${x}" y="${y + dy}" font-family="M" font-weight="${wt}" font-size="${size}" fill="${col}" text-anchor="${anchor}" letter-spacing="${o.ls !== undefined ? o.ls : 2}" opacity="${a.toFixed(3)}" style="paint-order:stroke" stroke="#000" stroke-opacity=".35" stroke-width="${o.sw !== undefined ? o.sw : 6}">${rich(txt)}</text>`;
}
export function big(t, t0, txt, x, y, size = 120, o = {}) { return lab(t, t0, txt, x, y, Object.assign({ size, weight: 900, ls: -1, sw: 10 }, o)); }
// pill tag with background
export function tag(t, t0, txt, x, y, o = {}) {
  if (OPT.noBottom && y >= 800 && !o.keep) return '';
  if (t < t0) return ''; const a = eback(ramp(t, t0, .35)); const size = o.size || 34; const w = txt.replace(/[\[\]{}]/g, '').length * size * .68 + 50;
  return `<g transform="translate(${x},${y}) scale(${a.toFixed(3)})"><rect x="${-w / 2}" y="${-size * 1.05}" width="${w}" height="${size * 1.6}" rx="${size * .35}" fill="${o.fill || C.red}"/>
    <text y="${size * .08}" font-family="M" font-weight="800" font-size="${size}" fill="#fff" text-anchor="middle" letter-spacing="1.5">${txt.replace(/[\[\]{}]/g, '')}</text></g>`;
}
export function stamp(t, t0, txt, x, y, o = {}) {
  if (t < t0) return ''; const u = ramp(t, t0, .22); const sc = lerp(1.8, 1, eout(u)); const size = o.size || 64; const w = txt.length * size * .7 + 60; const col = o.color || C.red;
  return `<g transform="translate(${x},${y}) rotate(${o.rot || -10}) scale(${sc.toFixed(3)})" opacity="${Math.min(1, u * 3).toFixed(2)}"><rect x="${-w / 2}" y="${-size * .95}" width="${w}" height="${size * 1.5}" rx="10" fill="none" stroke="${col}" stroke-width="8"/>
    <text y="${size * .32}" font-family="M" font-weight="900" font-size="${size}" fill="${col}" text-anchor="middle" letter-spacing="4">${txt}</text></g>`;
}
export function strike(t, t0, x1, y1, x2, y2, o = {}) {
  if (t < t0) return ''; const u = eout(ramp(t, t0, .3)); return `<line x1="${x1}" y1="${y1}" x2="${lerp(x1, x2, u)}" y2="${lerp(y1, y2, u)}" stroke="${o.color || C.red}" stroke-width="${o.w || 12}" stroke-linecap="round"/>`;
}
export function cross(t, t0, x, y, r = 60) { if (t < t0) return ''; const u = eout(ramp(t, t0, .25));
  return `<g stroke="${C.red}" stroke-width="14" stroke-linecap="round"><line x1="${x - r}" y1="${y - r}" x2="${lerp(x - r, x + r, u)}" y2="${lerp(y - r, y + r, u)}"/>${u > .5 ? `<line x1="${x + r}" y1="${y - r}" x2="${lerp(x + r, x - r, (u - .5) * 2)}" y2="${lerp(y - r, y + r, (u - .5) * 2)}"/>` : ''}</g>`; }
export function arrow(t, t0, x1, y1, x2, y2, o = {}) { // hand-drawn red arrow that draws on
  if (t < t0) return ''; const u = eout(ramp(t, t0, .45)); const mx = (x1 + x2) / 2 + (o.bend || 60), my = (y1 + y2) / 2 - (o.bend || 60) * .3;
  const d = `M${x1},${y1} Q${mx},${my} ${x2},${y2}`; const L = Math.hypot(x2 - x1, y2 - y1) * 1.2;
  const ang = Math.atan2(y2 - my, x2 - mx); const hx = x2, hy = y2, a1 = ang + 2.6, a2 = ang - 2.6, hl = 30;
  return `<path d="${d}" fill="none" stroke="${C.red}" stroke-width="9" stroke-linecap="round" stroke-dasharray="${L}" stroke-dashoffset="${(1 - u) * L}"/>` +
    (u > .9 ? `<path d="M${hx + Math.cos(a1) * hl},${hy + Math.sin(a1) * hl} L${hx},${hy} L${hx + Math.cos(a2) * hl},${hy + Math.sin(a2) * hl}" fill="none" stroke="${C.red}" stroke-width="9" stroke-linecap="round" stroke-linejoin="round"/>` : '');
}
export function counter(t, t0, d, from, to, fmt) { const u = eout(ramp(t, t0, d)); const v = Math.round(lerp(from, to, u)); return fmt(v.toLocaleString('en-US')); }
export function pop(t, t0, inner, x, y, s = 1, d = .35) { if (t < t0) return ''; const a = eback(ramp(t, t0, d)) * s; return `<g transform="translate(${x},${y}) scale(${a.toFixed(3)})">${inner}</g>`; }
export function fade(t, t0, inner, d = .4, out) { if (t < t0) return ''; let a = ease(ramp(t, t0, d)); if (out !== undefined) a *= clamp((out - t) / .3, 0, 1); return `<g opacity="${a.toFixed(3)}">${inner}</g>`; }
export function dots(i, n) { // chapter progress dots, top-centre
  let s = ''; for (let k = 0; k < n; k++) s += `<circle cx="${W / 2 - (n - 1) * 14 + k * 28}" cy="44" r="${k === i ? 8 : 6}" fill="${k <= i ? '#fff' : '#ffffff55'}"/>`; return s; }

// ---------- figures (all drawn around origin, ~unit sizes in px) ----------
// golden lancehead, side view, head to the right. len ~ 900 px at s=1. phase animates the body wave.
export function snake(ph = 0, o = {}) {
  const pts = []; const N = 40, L = o.len || 900, A = o.amp || 55;
  for (let i = 0; i <= N; i++) { const u = i / N; const x = -L / 2 + u * L; const y = Math.sin(u * Math.PI * 2.2 - ph) * A * (0.35 + 0.65 * Math.sin(u * Math.PI)) * (o.flat ? .3 : 1); pts.push([x, y]); }
  const d = 'M' + pts.map(p => p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' L');
  const hx = pts[N][0], hy = pts[N][1]; const ang = Math.atan2(pts[N][1] - pts[N - 2][1], pts[N][0] - pts[N - 2][0]) * 180 / Math.PI;
  const tongue = o.tongue ? `<path d="M88,4 L130,4 L146,-8 M130,4 L146,16" stroke="${C.red}" stroke-width="5" fill="none" stroke-linecap="round" stroke-linejoin="round" opacity="${o.tongue}"/>` : '';
  const pit = o.pit ? `<circle cx="58" cy="-6" r="${7 + 5 * o.pit}" fill="${C.amber}" opacity="${o.pit}"/><circle cx="58" cy="-6" r="${18 + 14 * o.pit}" fill="${C.amber}" opacity="${o.pit * .25}"/>` : '';
  return `<g><path d="${d}" fill="none" stroke="#5a3a12" stroke-width="${(o.w || 46) + 8}" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="${d}" fill="none" stroke="${C.gold}" stroke-width="${o.w || 46}" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="${d}" fill="none" stroke="${C.goldD}" stroke-width="${(o.w || 46) * .7}" stroke-dasharray="26 34" stroke-linecap="round" opacity=".85"/>
    <path d="${d}" fill="none" stroke="#f3cf7a" stroke-width="${(o.w || 46) * .18}" stroke-linecap="round" opacity=".55" transform="translate(0,-${(o.w || 46) * .22})"/>
    <g transform="translate(${hx},${hy}) rotate(${ang})">${tongue}
      <path d="M-30,-30 C10,-44 70,-30 96,-4 C100,2 98,8 92,12 C60,30 10,34 -30,26 Z" fill="${C.gold}" stroke="#5a3a12" stroke-width="5"/>
      <path d="M-10,-26 C30,-34 70,-22 92,-4" fill="none" stroke="${C.goldD}" stroke-width="7" stroke-linecap="round"/>
      <circle cx="40" cy="-12" r="9" fill="#1b1200"/><circle cx="43" cy="-15" r="3" fill="#fff" opacity=".8"/>${pit}
      <circle cx="74" cy="-2" r="3.5" fill="#3a2508"/></g></g>`;
}
// coiled snake (top/oblique view) for "thousands" crowds
export function coil(s = 1, col = C.gold) {
  return `<g transform="scale(${s})"><path d="M0,0 m-40,0 a40,26 0 1,0 80,0 a40,26 0 1,0 -80,0 M-26,-4 a26,16 0 1,1 52,0" fill="none" stroke="#3a2508" stroke-width="20"/>
    <path d="M0,0 m-40,0 a40,26 0 1,0 80,0 a40,26 0 1,0 -80,0 M-26,-4 a26,16 0 1,1 52,0" fill="none" stroke="${col}" stroke-width="13" stroke-dasharray="10 8"/>
    <path d="M24,-8 L50,-30 L66,-26 L56,-14 Z" fill="${col}" stroke="#3a2508" stroke-width="3"/></g>`;
}
export function bird(ph = 0, s = 1, col = '#d7e3e6') { const f = Math.sin(ph) * 22;
  return `<g transform="scale(${s})"><path d="M-30,0 Q-10,${-6 - f} 0,0 Q10,${-6 - f} 30,0 Q10,-2 0,6 Q-10,-2 -30,0 Z" fill="${col}"/><ellipse cx="0" cy="3" rx="10" ry="5" fill="${col}"/></g>`; }
export function person(o = {}) { // tiny hiker with backpack (the viewer). origin at feet, ~150 px tall
  const c = o.col || '#e9eef0', glow = o.thermal ? `<ellipse cx="0" cy="-80" rx="60" ry="100" fill="url(#therm)" opacity=".9"/>` : '';
  const torch = o.torch ? `<polygon points="22,-96 520,-180 520,0" fill="url(#beam)" opacity="${o.torch}"/>` : '';
  return `<g>${torch}${glow}<circle cx="0" cy="-132" r="14" fill="${c}"/><path d="M-14,-116 L14,-116 L18,-62 L10,-62 L8,0 L-2,0 L0,-56 L-4,0 L-14,0 L-14,-62 L-20,-62 Z" fill="${c}"/>
    <rect x="-30" y="-114" width="18" height="44" rx="6" fill="${o.pack || '#9aa7ab'}"/><path d="M14,-108 L28,-96" stroke="${c}" stroke-width="8" stroke-linecap="round"/><rect x="24" y="-102" width="12" height="9" rx="2" fill="#fff"/></g>`;
}
export function boat(s = 1) { return `<g transform="scale(${s})"><path d="M-120,0 L120,0 L95,40 L-100,40 Z" fill="#d9dfe1"/><rect x="-40" y="-40" width="70" height="40" rx="6" fill="#b8c3c6"/><rect x="-30" y="-32" width="22" height="18" fill="#4a6670"/><path d="M-120,40 L120,40" stroke="#04121a" stroke-width="4"/></g>`; }
export function islandSil(col = '#0a1f1a', s = 1) { return `<g transform="scale(${s})"><path d="M-520,0 C-460,-30 -420,-60 -360,-70 C-300,-160 -220,-200 -150,-190 C-90,-260 -10,-280 40,-240 C110,-260 170,-200 210,-150 C280,-140 340,-90 380,-60 C430,-40 480,-20 540,0 Z" fill="${col}"/>
  <path d="M-150,-190 C-130,-210 -110,-215 -90,-205 M40,-240 C60,-262 90,-266 110,-248" stroke="#163a30" stroke-width="10" fill="none" stroke-linecap="round"/></g>`; }
export function trees(t, y0, col = '#06150f', n = 9, seed = 0) { let s = '';
  for (let i = 0; i < n; i++) { const x = i * (W / (n - 1)) + (rnd(i + seed) - .5) * 120, h = 380 + rnd(i + seed + 4) * 300, r = 120 + rnd(i + seed + 8) * 90, sw = Math.sin(t * .6 + i) * 4;
    s += `<rect x="${x - 16}" y="${y0 - h}" width="32" height="${h}" fill="${col}"/><g transform="rotate(${sw} ${x} ${y0 - h})"><circle cx="${x}" cy="${y0 - h}" r="${r}" fill="${col}"/><circle cx="${x - r * .7}" cy="${y0 - h + 40}" r="${r * .7}" fill="${col}"/><circle cx="${x + r * .7}" cy="${y0 - h + 30}" r="${r * .75}" fill="${col}"/></g>`; }
  return s; }
export function branch(x1, y1, x2, y2, col = '#2a1d12', w = 34) { const mx = (x1 + x2) / 2, my = (y1 + y2) / 2 + 30;
  return `<path d="M${x1},${y1} Q${mx},${my} ${x2},${y2}" stroke="${col}" stroke-width="${w}" fill="none" stroke-linecap="round"/><path d="M${mx},${my - 10} q60,-50 120,-60" stroke="${col}" stroke-width="${w * .5}" fill="none" stroke-linecap="round"/>`; }
export function leaves(x, y, s = 1, col = '#123a24') { return `<g transform="translate(${x},${y}) scale(${s})" fill="${col}"><ellipse cx="0" cy="0" rx="60" ry="22" transform="rotate(-20)"/><ellipse cx="50" cy="-30" rx="55" ry="20" transform="rotate(-50 50 -30)"/><ellipse cx="-50" cy="-24" rx="50" ry="18" transform="rotate(20 -50 -24)"/></g>`; }
export function mouse(s = 1, col = '#cfd6d8') { return `<g transform="scale(${s})"><ellipse cx="0" cy="0" rx="46" ry="28" fill="${col}"/><circle cx="40" cy="-10" r="20" fill="${col}"/><circle cx="34" cy="-30" r="12" fill="${col}"/><circle cx="52" cy="-12" r="3" fill="#111"/><path d="M-44,6 Q-90,10 -100,-14" stroke="${col}" stroke-width="5" fill="none"/></g>`; }
export function monkey(s = 1, col = '#cfd6d8') { return `<g transform="scale(${s})"><circle cx="0" cy="-60" r="34" fill="${col}"/><circle cx="-34" cy="-66" r="13" fill="${col}"/><circle cx="34" cy="-66" r="13" fill="${col}"/><ellipse cx="0" cy="-52" rx="20" ry="16" fill="#8b9599"/><ellipse cx="0" cy="0" rx="34" ry="40" fill="${col}"/><path d="M30,20 Q80,30 70,-20" stroke="${col}" stroke-width="9" fill="none" stroke-linecap="round"/></g>`; }
export function lighthouse(s = 1, beam = 0, ang = 0) { return `<g transform="scale(${s})">${beam ? `<g transform="rotate(${ang} 0 -330)"><polygon points="0,-330 900,-420 900,-240" fill="url(#lbeam)" opacity="${beam}"/></g>` : ''}
  <path d="M-50,0 L-34,-300 L34,-300 L50,0 Z" fill="#e8ecec"/><path d="M-46,-80 L46,-80 L42,-130 L-42,-130 Z M-39,-190 L39,-190 L36,-240 L-36,-240 Z" fill="${C.red}"/>
  <rect x="-40" y="-340" width="80" height="40" fill="#2b3a40"/><rect x="-30" y="-336" width="60" height="30" fill="#ffe39a"/><path d="M-50,-340 L0,-380 L50,-340 Z" fill="#2b3a40"/></g>`; }
export function house(s = 1, win = '#ffd27a', open = 0) { return `<g transform="scale(${s})"><rect x="-150" y="-180" width="300" height="180" fill="#2b3640"/><path d="M-180,-180 L0,-300 L180,-180 Z" fill="#1d262e"/>
  <rect x="-90" y="-130" width="70" height="70" fill="${win}"/><g transform="translate(-90,-130) scale(${1 - open * .9},1)"><rect width="70" height="70" fill="#40505c" stroke="#1d262e" stroke-width="4"/></g><rect x="50" y="-110" width="60" height="110" fill="#1d262e"/></g>`; }
export function heart(s = 1, col = C.red) { return `<path transform="scale(${s})" d="M0,30 C-60,-10 -80,-50 -50,-75 C-25,-95 -5,-80 0,-60 C5,-80 25,-95 50,-75 C80,-50 60,-10 0,30 Z" fill="${col}"/>`; }
export function pill(s = 1) { return `<g transform="scale(${s}) rotate(-30)"><rect x="-70" y="-26" width="140" height="52" rx="26" fill="#f2f2f2"/><path d="M0,-26 L44,-26 A26,26 0 0 1 44,26 L0,26 Z" fill="${C.amber}"/></g>`; }
export function vial(s = 1) { return `<g transform="scale(${s})"><rect x="-34" y="-120" width="68" height="20" rx="4" fill="#9aa7ab"/><rect x="-28" y="-100" width="56" height="130" rx="10" fill="#dfe8ea" opacity=".9"/><rect x="-28" y="-30" width="56" height="60" rx="10" fill="${C.amber}"/></g>`; }
export function boot(s = 1) { return `<g transform="scale(${s})"><path d="M-30,-140 L30,-140 L34,-40 L110,-20 Q130,-10 126,10 L-36,10 Z" fill="#6b4a2a"/><path d="M-30,-120 L32,-120 M-30,-100 L33,-100 M-30,-80 L33,-80" stroke="#3b2a18" stroke-width="5"/><rect x="-36" y="10" width="162" height="14" fill="#2a1d12"/></g>`; }
export function watch(t, s = 1, spin = 0) { return `<g transform="scale(${s})"><rect x="-16" y="-130" width="32" height="24" rx="4" fill="#cfd6d8"/><circle r="100" fill="#0b1a20" stroke="#e9eef0" stroke-width="12"/>
  <line x1="0" y1="0" x2="${Math.sin(spin) * 76}" y2="${-Math.cos(spin) * 76}" stroke="${C.red}" stroke-width="8" stroke-linecap="round"/><circle r="9" fill="#e9eef0"/></g>`; }
export function thermo(level, s = 1) { const h = 260 * level; return `<g transform="scale(${s})"><rect x="-26" y="-300" width="52" height="300" rx="26" fill="#1c2a30" stroke="#e9eef0" stroke-width="7"/><circle cy="20" r="46" fill="${C.red}" stroke="#e9eef0" stroke-width="7"/>
  <rect x="-13" y="${-h}" width="26" height="${h + 10}" fill="${C.red}"/></g>`; }
export function shield(s = 1) { return `<path transform="scale(${s})" d="M0,-120 L100,-80 C100,20 60,90 0,120 C-60,90 -100,20 -100,-80 Z" fill="#2e6d8a" stroke="#e9eef0" stroke-width="8"/>`; }
export function lock(s = 1) { return `<g transform="scale(${s})"><path d="M-50,-20 L-50,-70 A50,50 0 0 1 50,-70 L50,-20" fill="none" stroke="#e9eef0" stroke-width="18"/><rect x="-80" y="-20" width="160" height="120" rx="14" fill="${C.amber}"/><circle cy="30" r="14" fill="#3a2508"/></g>`; }
export function pricetag(txt, s = 1) { return `<g transform="scale(${s}) rotate(-12)"><path d="M-200,-70 L150,-70 L220,0 L150,70 L-200,70 Z" fill="${C.amber}"/><circle cx="160" cy="0" r="14" fill="#04121a"/>
  <text x="-20" y="26" font-family="M" font-weight="900" font-size="78" text-anchor="middle" fill="#04121a">${txt}</text></g>`; }
export function radiator(t, s = 1) { const k = Math.sin(t * 8) * 12; return `<g transform="scale(${s})"><rect x="-120" y="-180" width="240" height="160" rx="16" fill="${C.red}"/>${[0, 1, 2, 3, 4].map(i => `<rect x="${-100 + i * 44}" y="-165" width="26" height="130" rx="10" fill="#ff6a5a"/>`).join('')}
  <path d="M-60,-20 L${-70 + k},60 M60,-20 L${70 - k},60" stroke="#e9eef0" stroke-width="16" stroke-linecap="round"/><path d="M${-70 + k},60 l-30,0 M${70 - k},60 l30,0" stroke="#e9eef0" stroke-width="16" stroke-linecap="round"/>
  ${[0, 1, 2].map(i => `<path d="M${-60 + i * 60},-200 q-15,-30 0,-60 q15,-30 0,-60" stroke="${C.amber}" stroke-width="7" fill="none" opacity="${.5 + .5 * Math.sin(t * 4 + i)}"/>`).join('')}</g>`; }
export function paper(w, h, title, lines = 5, o = {}) { let s = `<rect x="${-w / 2}" y="${-h / 2}" width="${w}" height="${h}" rx="8" fill="${o.fill || '#e9e4d6'}"/>`;
  if (title) s += `<text x="${-w / 2 + 40}" y="${-h / 2 + 70}" font-family="M" font-weight="800" font-size="${o.ts || 38}" fill="#1b1b1b">${title}</text>`;
  for (let i = 0; i < lines; i++) s += `<rect x="${-w / 2 + 40}" y="${-h / 2 + 110 + i * 40}" width="${(w - 80) * (.6 + .4 * rnd(i + 3))}" height="14" rx="7" fill="#9a958a"/>`;
  return s; }
export function pitch(s = 1, col = '#2f7a3e') { return `<g transform="scale(${s})"><rect x="-52" y="-34" width="104" height="68" fill="${col}" stroke="#e9eef0" stroke-width="3"/><line x1="0" y1="-34" x2="0" y2="34" stroke="#e9eef0" stroke-width="2"/><circle r="9" fill="none" stroke="#e9eef0" stroke-width="2"/></g>`; }
export function court(s = 1) { return `<g transform="scale(${s})"><rect x="-134" y="-61" width="268" height="122" fill="#2f6d8a" stroke="#e9eef0" stroke-width="4"/><line x1="0" y1="-61" x2="0" y2="61" stroke="#e9eef0" stroke-width="6"/><line x1="-134" y1="-53" x2="134" y2="-53" stroke="#e9eef0" stroke-width="2"/><line x1="-134" y1="53" x2="134" y2="53" stroke="#e9eef0" stroke-width="2"/><line x1="-40" y1="-61" x2="-40" y2="61" stroke="#e9eef0" stroke-width="2"/><line x1="40" y1="-61" x2="40" y2="61" stroke="#e9eef0" stroke-width="2"/></g>`; }
export const DEFS = `<defs><radialGradient id="therm"><stop offset="0" stop-color="#fff6b0"/><stop offset=".3" stop-color="#ffb400"/><stop offset=".6" stop-color="#ff3c00" stop-opacity=".8"/><stop offset="1" stop-color="#7a00a0" stop-opacity="0"/></radialGradient>
  <linearGradient id="beam" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff" stop-opacity=".9"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>
  <linearGradient id="lbeam" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffe39a" stop-opacity=".8"/><stop offset="1" stop-color="#ffe39a" stop-opacity="0"/></linearGradient></defs>`;
