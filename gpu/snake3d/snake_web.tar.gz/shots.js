import { S } from './sents.js';
import * as K from './kit.js';
const { W, H, C, lab, big, tag, stamp, strike, cross, arrow, pop, fade, ramp, ease, eout, eback, lerp, clamp, rnd } = K;
const s0 = i => S[i][0], w = (i, k) => S[i][2][Math.min(k, S[i][2].length - 1)];
// scene wrapper: background, gentle push-in, particles, vignette
function scene(kind, t, u, inner, o = {}) {
  const z = 1 + (o.push === undefined ? .05 : o.push) * ease(u);
  return K.bg(kind, t, o) + `<g transform="translate(${W / 2},${H / 2}) scale(${z.toFixed(4)}) translate(${-W / 2},${-H / 2})">${inner}</g>` +
    (o.parts === false ? '' : K.particles(t, o.np || 50, o.pcol || '#cfe8e0', o.po || .45)) + K.vignette();
}
const sh = [];
const add = (t0, t1, o) => sh.push(Object.assign({ t0, t1, id: sh.length }, o));
const cut = i => Math.max(0, s0(i) - 0.12);   // cut a hair before the sentence starts

// ===================== COLD OPEN =====================
// 0: 3D approach over the sea to the island at dusk
add(0, cut(2), { gl: 'island', g: { cam: [[0, -46.676, -24.487, 6.0, 4, 205], [cut(2), -46.676, -24.488, 2.6, 9, 195]], dark: .9 },
  draw: (t, lt, u) => lab(t, 1.6, 'OFF THE COAST OF {SÃO PAULO}', W / 2, 980, { size: 40 }) });
// 1: green forest / black rocks / not a single person
add(cut(2), cut(5), { gl: 'island', g: { cam: [[0, -46.676, -24.486, 1.25, 18, 150], [5, -46.676, -24.486, 1.1, 22, 132]], dark: .95 },
  draw: (t) => lab(t, s0(2), 'GREEN FOREST', 520, 900, { size: 44 }) + lab(t, s0(3), 'BLACK ROCKS', 960, 980, { size: 44 }) + lab(t, s0(4), '[0] PEOPLE', 1400, 900, { size: 44 }) });
// 2: you jump off the boat onto a flat rock
add(cut(5), cut(6), { draw: (t, lt, u) => {
  const jump = clamp((lt - .7) / .9, 0, 1); const px = lerp(1180, 860, jump), py = lerp(735, 760, jump) - Math.sin(jump * Math.PI) * 170;
  const bob = Math.sin(t * 2) * 6;
  return scene('sea', t, u, `<g transform="translate(820,690)">${K.islandSil('#0a1f1a', 1.3)}</g>` + `<rect y="690" width="${W}" height="390" fill="#071c24"/>` +
    `<path d="M520,770 C600,735 980,730 1040,760 L1060,800 L500,810 Z" fill="#26353a"/><path d="M520,770 C600,735 980,730 1040,760" stroke="#3c4f55" stroke-width="6" fill="none"/>` +
    `<g transform="translate(1320,${800 + bob})">${K.boat(1.2)}</g>` + `<g transform="translate(${px},${py})">${K.person({})}</g>` +
    `<path d="M0,815 Q480,${800 + bob} 960,815 T1920,815 L1920,1080 L0,1080 Z" fill="#06171e" opacity=".95"/>` +
    lab(t, s0(5) + .2, 'A FLAT ROCK', 760, 880, { size: 38 }) + lab(t, s0(5) + 1.4, '[YOU]', px, py - 200, { size: 46 }), { parts: false, push: .03 }); } });
// 3: the forest is quiet: no monkeys, no rats, not even a mouse
add(cut(6), cut(11), { draw: (t, lt, u) => {
  const icons = [[K.monkey(1.3), 560, s0(8)], [K.mouse(1.4), 960, s0(9)], [K.mouse(.9), 1360, s0(10)]];
  let s = K.trees(t, 1080, '#04100c', 8, 1) + `<rect y="900" width="${W}" height="180" fill="#03100b"/>`;
  s += lab(t, s0(6), 'QUIET', W / 2, 200, { size: 54 }) + lab(t, s0(7), '[TOO] QUIET', W / 2, 270, { size: 40 });
  icons.forEach(([g, x, ti], i) => { s += pop(t, ti, g, x, 640) + K.cross(t, ti + .3, x, 600, 90); });
  return scene('forest', t, u, s); } });
// 4: first clue: something ate the easy food long ago
add(cut(11), cut(13), { draw: (t, lt, u) => {
  let s = `<rect y="860" width="${W}" height="220" fill="#06140f"/>` + K.trees(t, 1000, '#04100c', 7, 5);
  for (let i = 0; i < 9; i++) { const x = 300 + i * 160, a = clamp(1 - (lt - 1.2 - i * .25) / .6, 0, 1);
    s += `<g opacity="${a.toFixed(2)}" transform="translate(${x},${880 - (i % 2) * 30}) scale(.45)">${K.mouse(1, '#9fb2b5')}</g>`; }
  s += lab(t, s0(11), 'FIRST CLUE', W / 2, 220, { size: 60 }) + lab(t, s0(12) + 1.2, 'THE EASY FOOD: [GONE]', W / 2, 300, { size: 40 });
  return scene('forest', t, u, s); } });
// 5: from the dark under the trees, it can already see you
add(cut(13), cut(14), { draw: (t, lt, u) => {
  const eye = ease(ramp(t, w(13, 4), 1.2));
  let s = K.trees(t, 1100, '#020a07', 9, 3) + `<rect width="${W}" height="${H}" fill="#000" opacity=".45"/>`;
  s += `<g transform="translate(980,560) scale(${1.4 + .3 * u})" opacity="${eye}"><ellipse cx="-60" cy="0" rx="16" ry="11" fill="${C.amber}"/><ellipse cx="60" cy="0" rx="16" ry="11" fill="${C.amber}"/><rect x="-63" y="-10" width="6" height="20" fill="#000"/><rect x="57" y="-10" width="6" height="20" fill="#000"/></g>`;
  return scene('forest', t, u, s, { rays: false, po: .2 }); } });
// 6: not your shape. your heat. (thermal view of you)
add(cut(14), cut(16), { draw: (t, lt, u) => {
  const th = ease(ramp(t, s0(15) - .1, .5));
  let s = `<g transform="translate(960,860) scale(3.2)" opacity="${1 - th}">${K.person({})}</g>`;
  s += `<g transform="translate(960,860) scale(3.2)" opacity="${th}"><ellipse cx="0" cy="-70" rx="70" ry="120" fill="url(#therm)"/><g opacity=".85">${K.person({ col: '#ffe08a', pack: '#ff8a00' })}</g></g>`;
  s += lab(t, s0(14), 'NOT YOUR SHAPE', 520, 260, { size: 48 }) + lab(t, s0(15), 'YOUR [HEAT]', 1420, 260, { size: 60 });
  return scene(th > .5 ? 'thermal' : 'forest', t, u, s, { rays: false, po: .3 }); } });
// 7: REVEAL: real photo of a golden lancehead
add(cut(16), cut(18), { photo: { img: 'ph_snake', from: [.62, .38, 1.05], to: [.70, .34, 1.35] },
  draw: (t, lt, u) => `<rect width="${W}" height="${H}" fill="url(#vgp)"/><defs><radialGradient id="vgp" cx="50%" cy="50%" r="75%"><stop offset=".55" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".6"/></radialGradient></defs>` +
    lab(t, s0(16) + .2, 'GOLDEN [LANCEHEAD]', 120, 930, { size: 58, anchor: 'start' }) + lab(t, s0(17), 'PIT VIPER · FOUND ON THIS ISLAND {ONLY}', 120, 1000, { size: 32, anchor: 'start' }) });
// 8: thousands of them
add(cut(18), cut(19), { draw: (t, lt, u) => {
  let s = K.trees(t, 1100, '#04100c', 8, 9);
  for (let i = 0; i < 26; i++) { const x = 120 + rnd(i) * 1680, y = 160 + rnd(i + 40) * 760, ti = s0(18) + .1 + i * .045; s += pop(t, ti, K.coil(.7 + rnd(i + 2) * .5), x, y); }
  s += big(t, s0(18) + .3, '[THOUSANDS]', W / 2, 560, 130);
  return scene('forest', t, u, s, { rays: false }); } });
// 9: misconception: Australia? A horror film?
add(cut(19), cut(20), { draw: (t, lt, u) => {
  const a1 = s0(19) + 1.0, a2 = w(19, 13) - .3;
  let s = pop(t, a1 - .2, `<rect x="-300" y="-190" width="600" height="380" rx="18" fill="#132a33" stroke="#e9eef0" stroke-width="4"/><polygon points="-164,-25 -160,8 -152,74 -127,82 -86,74 -37,54 -12,57 12,80 37,82 53,107 86,111 111,107 135,102 156,57 164,25 160,0 135,-25 102,-49 98,-82 78,-115 70,-111 66,-82 53,-61 29,-74 16,-82 25,-107 -4,-111 -20,-107 -33,-82 -53,-90 -70,-82 -94,-66 -102,-45 -135,-35" fill="#c98a3a" transform="translate(0,-20)"/>` +
    `<text y="160" font-family="M" font-weight="800" font-size="44" fill="#fff" text-anchor="middle">AUSTRALIA?</text>`, 560, 520);
  s += pop(t, a2 - .2, `<rect x="-300" y="-190" width="600" height="380" rx="18" fill="#132a33" stroke="#e9eef0" stroke-width="4"/><rect x="-150" y="-110" width="300" height="180" rx="10" fill="#2a2f33"/><path d="M-150,-110 L150,-110 L130,-160 L-170,-160 Z" fill="#e9eef0"/>` +
    `${[0, 1, 2, 3].map(i => `<path d="M${-150 + i * 80},-160 l40,0 l-20,50 l-40,0 z" fill="#111"/>`).join('')}<text y="160" font-family="M" font-weight="800" font-size="44" fill="#fff" text-anchor="middle">A HORROR FILM?</text>`, 1360, 520);
  s += lab(t, s0(19), 'A DEADLY SNAKE ISLAND IS...', W / 2, 190, { size: 48 });
  return scene('card', t, u, s); } });
// 10: this one is real
add(cut(20), cut(21), { draw: (t, lt, u) => scene('card', t, u, `<g opacity=".35" transform="translate(960,700)">${K.islandSil('#1b4a3a', 1.2)}</g>` + stamp(t, s0(20) + .5, 'REAL', W / 2, 520, { size: 130, rot: -8 })) });
// 11: 3D: Brazil coast -> the island, 33 km, Navy keeps the public off
add(cut(21), cut(22), { gl: 'coast', g: { cam: [[0, -46.76, -24.32, 115, 64, 0], [4.5, -46.74, -24.33, 88, 58, 2], [cut(22) - cut(21), -46.72, -24.36, 68, 52, 5]], dark: 1 },
  draw: (t, lt, u, P) => { if (!P) return ''; const [ix, iy] = P(-46.676, -24.487, .2), [cx, cy] = P(-46.79, -24.19, .05), [bx, by] = P(-46.92, -24.12, .3);
    const d = ramp(t, w(21, 11), .9); let s = '';
    s += `<line x1="${cx}" y1="${cy}" x2="${lerp(cx, ix, d)}" y2="${lerp(cy, iy, d)}" stroke="#fff" stroke-width="5" stroke-dasharray="14 12"/>`;
    s += `<circle cx="${ix}" cy="${iy}" r="${10 + 4 * Math.sin(t * 4)}" fill="${C.red}"/><circle cx="${ix}" cy="${iy}" r="${26 + 10 * Math.sin(t * 4)}" fill="none" stroke="${C.red}" stroke-width="4" opacity=".7"/>`;
    s += lab(t, s0(21) + .4, 'ILHA DA QUEIMADA GRANDE', ix, iy - 50, { size: 34 }) + lab(t, w(21, 11) + .6, '[33 KM]', (cx + ix) / 2 + 80, (cy + iy) / 2, { size: 44 });
    s += lab(t, w(21, 15), 'BRAZIL', bx, by, { size: 40, color: '#cfe0e4' });
    s += tag(t, w(21, 20), 'NO PUBLIC ACCESS', W / 2, 960, { size: 36 });
    return s + K.vignette(); } });
// 12: a story nobody has ever been able to prove
add(cut(22), cut(23), { draw: (t, lt, u) => scene('night', t, u, `<g transform="translate(960,900)">${K.lighthouse(1.4, .5, -20 + lt * 14)}</g>` + `<text x="1300" y="520" font-family="M" font-weight="900" font-size="220" fill="${C.red}" opacity="${ease(ramp(t, w(22, 9), .5))}">?</text>` +
  lab(t, s0(22) + .2, 'THE LAST FAMILY', 520, 260, { size: 46 }) + lab(t, w(22, 9), 'A STORY NOBODY CAN [PROVE]', 520, 330, { size: 36 }), { rays: false }) });
// 13: the snake's closest relative may have helped save your grandparents' hearts
add(cut(23), cut(25), { draw: (t, lt, u) => { const b = 1 + .08 * Math.max(0, Math.sin(t * 7)) ** 8;
  return scene('card', t, u, pop(t, s0(23) + 1.5, `<g transform="scale(${b * 2.2})">${K.heart(1)}</g>`, 1260, 560) + `<g transform="translate(560,600) scale(.6)">${K.snake(t * 2, { len: 760, amp: 40 })}</g>` +
    lab(t, s0(23) + .2, 'ITS CLOSEST RELATIVE', 560, 400, { size: 40 }) + lab(t, w(23, 9), 'YOUR GRANDPARENTS\' [HEARTS]?', 1260, 300, { size: 44 }) + lab(t, s0(24), 'WE\'LL GET TO BOTH', W / 2, 960, { size: 36, color: '#9fb5bb' })); } });
// 14: thesis / title card
add(cut(25), cut(26), { draw: (t, lt, u) => scene('sea', t, u, `<g opacity=".5" transform="translate(960,820) scale(1.6)">${K.islandSil('#0c2a22', 1)}</g>` +
  big(t, s0(25) + .3, 'WHY YOU\'D NEVER SURVIVE', W / 2, 470, 92) + big(t, s0(25) + .6, '[SNAKE ISLAND]', W / 2, 600, 130) + K.dots(0, 6), { push: .03 }) });


// ===================== SIZE =====================
// 15: 3D island orbit: smaller than you think, 43 hectares
add(cut(26), cut(28), { gl: 'island', g: { cam: [[0, -46.676, -24.486, 3.4, 58, 160], [cut(28) - cut(26), -46.676, -24.486, 2.8, 52, 120]], dark: 1 },
  draw: (t, lt, u, P) => lab(t, s0(26), 'SMALLER THAN YOU THINK', W / 2, 140, { size: 44 }) + big(t, w(27, 5), '[43] HECTARES', W / 2, 980, 90) + K.dots(1, 6) });
// 16: roughly 60 football pitches; walk across in half an hour
add(cut(28), cut(30), { draw: (t, lt, u) => { let s = '';
  for (let i = 0; i < 60; i++) { const c = i % 12, r = Math.floor(i / 12); s += pop(t, s0(28) + .2 + i * .022, K.pitch(1), 380 + c * 105, 300 + r * 76, 1, .25); }
  s += big(t, w(28, 1), K.counter(t, w(28, 1), 1, 0, 60, v => `≈ ${v} FOOTBALL PITCHES`), W / 2, 200, 64);
  const walk = clamp((t - s0(29)) / 3, 0, 1); s += fade(t, s0(29), `<g transform="translate(${lerp(380, 1540, walk)},840) scale(.8)">${K.person({})}</g>` + `<line x1="380" y1="860" x2="1540" y2="860" stroke="#fff" stroke-width="3" stroke-dasharray="10 10" opacity=".5"/>`);
  s += lab(t, w(29, 6), '~30 MIN', W / 2, 940, { size: 44 }) + lab(t, w(29, 9), '...[IN THEORY]', W / 2, 1000, { size: 34 });
  return scene('card', t, u, s); } });
// 17: one snake per square metre -> 430,000
add(cut(30), cut(32), { draw: (t, lt, u) => { let s = '';
  const n = Math.floor(clamp((t - s0(30) - 1) / 4, 0, 1) * 220);
  for (let i = 0; i < n; i++) { const c = i % 22, r = Math.floor(i / 22); s += `<g transform="translate(${300 + c * 60},${330 + r * 54})">${K.coil(.42)}</g>`; }
  s += lab(t, s0(30), 'THE OLD CLAIM: [1 SNAKE] PER SQUARE METRE', W / 2, 200, { size: 42 });
  s += t >= w(31, 4) - .2 ? `<rect x="560" y="430" width="800" height="200" rx="16" fill="#04121a" opacity=".85"/>` + big(t, w(31, 4) - .2, K.counter(t, w(31, 4) - .2, 1.3, 0, 430000, v => v), W / 2, 580, 130) : '';
  return scene('card', t, u, s); } });
// 18: myth -> 2,000-4,000
add(cut(32), cut(34), { draw: (t, lt, u) => {
  let s = big(t, s0(32) - .2, '430,000', W / 2, 400, 130, { color: '#9fb5bb' }) + strike(t, w(32, 4), 640, 360, 1280, 360, { w: 16 }) + stamp(t, w(32, 4), 'MYTH', 1380, 300, { size: 70 });
  s += lab(t, w(33, 1), 'WHEN SCIENTISTS ACTUALLY COUNTED', W / 2, 600, { size: 40 }) + big(t, w(33, 8), '[2,000 – 4,000]', W / 2, 760, 120);
  return scene('card', t, u, s); } });
// 19: newer survey ~2,500
add(cut(34), cut(35), { draw: (t, lt, u) => scene('card', t, u, pop(t, s0(34), K.paper(620, 420, 'NEWER SURVEY', 5), 700, 560) + big(t, w(34, 7), '≈ [2,500]', 1350, 600, 140) + lab(t, w(34, 7) + .4, 'SNAKES', 1350, 690, { size: 40 })) });
// 20: one deadly snake for every two badminton courts
add(cut(35), cut(36), { draw: (t, lt, u) => {
  let s = pop(t, w(35, 10) - .3, K.court(1.6), 690, 560) + pop(t, w(35, 10) - .1, K.court(1.6), 1230, 560) + pop(t, w(35, 5), K.coil(1.4), 960, 560);
  s += lab(t, s0(35), 'BAD NEWS', W / 2, 230, { size: 50 }) + lab(t, w(35, 5), '[1 DEADLY SNAKE] PER [2] BADMINTON COURTS', W / 2, 860, { size: 42 });
  return scene('card', t, u, s); } });
// 21: not on the ground... in the trees
add(cut(36), cut(38), { draw: (t, lt, u) => { const tilt = ease(ramp(t, s0(37) - .3, .9)) * 520;
  let s = `<g transform="translate(0,${tilt})">` + `<rect y="880" width="${W}" height="400" fill="#06140f"/>` + K.trees(t, 900, '#071a12', 6, 21);
  s += K.branch(200, -150, 1100, -60) + K.branch(1900, 120, 900, 220) + K.leaves(500, -180, 1.4) + K.leaves(1400, 80, 1.3);
  s += `<g transform="translate(640,-130) scale(.5)">${K.snake(t * 1.5, { len: 700, amp: 26 })}</g><g transform="translate(1380,190) scale(-.5,.5)">${K.snake(t * 1.5 + 2, { len: 700, amp: 26 })}</g></g>`;
  s += lab(t, s0(36), 'NOT ON THE [GROUND]...', W / 2, 980, { size: 46, out: s0(37) - .2 }) + lab(t, s0(37), '...IN THE [TREES]', W / 2, 150, { size: 54 });
  return scene('forest', t, u, s, { push: .02 }); } });
// 22: one rock in the Atlantic
add(cut(38), cut(39), { draw: (t, lt, u) => { const z = lerp(1, .35, ease(u));
  let s = `<g transform="translate(960,620) scale(${z})">${K.islandSil('#0e2d24', 1)}</g>` + lab(t, w(38, 3), 'THOUSANDS OF VENOMOUS SNAKES', W / 2, 220, { size: 44 }) + lab(t, w(38, 12), 'ON ONE ROCK IN THE [ATLANTIC]?', W / 2, 290, { size: 44 });
  return scene('sea', t, u, s, { push: 0 }); } });

// ===================== THE SEA MOVED =====================
add(cut(39), cut(41), { draw: (t, lt, u) => { let s = '';
  for (let k = 0; k < 4; k++) s += `<path d="M0,${700 + k * 60} ${Array.from({ length: 13 }, (_, i) => `Q${i * 160 + 80},${700 + k * 60 + (i % 2 ? -1 : 1) * 24 * Math.sin(t * 1.5 + k)} ${i * 160 + 160},${700 + k * 60}`).join(' ')} L1920,1080 L0,1080 Z" fill="#0d3a48" opacity="${.35 + k * .15}"/>`;
  s += lab(t, s0(39), 'THE MOST GEOGRAPHY THING EVER', W / 2, 360, { size: 40 }) + big(t, s0(40), 'THE SEA [MOVED]', W / 2, 520, 130) + K.dots(2, 6);
  return scene('sea', t, u, s); } });
// 3D: 11,000 years ago this was a hill on the coast
add(cut(41), cut(43), { gl: 'coast', g: { cam: [[0, -46.685, -24.475, 9, 13, 150], [cut(43) - cut(41), -46.68, -24.48, 7, 11, 132]], sea: [[0, -45]], dark: 1 },
  draw: (t, lt, u, P) => { if (!P) return ''; const [ix, iy] = P(-46.676, -24.487, .35);
    return tag(t, s0(41) + .2, '11,000 YEARS AGO', W / 2, 140, { size: 38, fill: '#2e6d8a' }) + lab(t, w(42, 3), 'A [HILL] ON THE COAST', ix, iy - 60, { size: 40 }) + lab(t, w(41, 11), 'END OF THE LAST ICE AGE', W / 2, 1000, { size: 34, color: '#cfe0e4' }) + K.vignette(); } });
// 3D: the ocean rose and swallowed the low ground
add(cut(43), cut(45), { gl: 'coast', g: { cam: [[0, -46.68, -24.48, 8, 14, 120], [cut(45) - cut(43), -46.678, -24.484, 6.5, 12, 104]], sea: [[0, -45], [1.0, -45], [6.5, 0]], dark: 1 },
  draw: (t, lt, u, P) => { if (!P) return ''; const [ix, iy] = P(-46.676, -24.487, .35); const lvl = Math.round(lerp(-45, 0, ease(clamp((lt - 1) / 5.5, 0, 1))));
    return lab(t, s0(43), 'ICE MELTS · SEA [RISES]', W / 2, 140, { size: 44 }) + lab(t, s0(43) + .3, `SEA LEVEL ${lvl === 0 ? 'TODAY' : lvl + ' M'}`, 1700, 1000, { size: 30, color: '#9fd3e6' }) +
      lab(t, s0(44), '[TRAPPED]', ix, iy - 60, { size: 54 }) + K.vignette(); } });
// 2D: including a population of lanceheads
add(cut(45), cut(46), { draw: (t, lt, u) => scene('forest', t, u, `<g transform="translate(960,640)">${K.islandSil('#0e2d24', 1.2)}</g>` + Array.from({ length: 7 }, (_, i) => pop(t, s0(45) + .4 + i * .12, K.coil(.8), 560 + i * 130, 520 - (i % 3) * 40)).join('') + lab(t, s0(45) + .3, 'A POPULATION OF [LANCEHEADS]', W / 2, 240, { size: 46 })) });
// mainland menu: rats and mice
add(cut(46), cut(47), { draw: (t, lt, u) => scene('card', t, u, lab(t, s0(46), 'MAINLAND MENU', W / 2, 220, { size: 50 }) + pop(t, w(46, 5), K.mouse(2.2), 700, 560) + pop(t, w(46, 7), K.mouse(1.6), 1220, 580) + lab(t, w(46, 5), 'RATS', 700, 720, { size: 40 }) + lab(t, w(46, 7), 'MICE', 1220, 720, { size: 40 })) });
// island: no mammals, nothing warm and furry
add(cut(47), cut(49), { draw: (t, lt, u) => scene('card', t, u, lab(t, s0(47), 'ISLAND MENU', W / 2, 220, { size: 50 }) + `<g opacity=".5">` + K.mouse(2.2).replace('<g ', '<g transform="translate(700,560) scale(2.2)" ').replace('transform="scale(2.2)"', '') + K.monkey(1.6).replace('<g ', '<g transform="translate(1220,640) scale(1.6)" ').replace('transform="scale(1.6)"', '') + `</g>` +
  cross(t, w(47, 6), 700, 540, 120) + cross(t, w(47, 6) + .2, 1220, 540, 120) + lab(t, w(47, 5), '[NO MAMMALS] AT ALL', W / 2, 840, { size: 50 }) + lab(t, s0(48), 'NOTHING WARM & FURRY', W / 2, 920, { size: 36, color: '#9fb5bb' })) });
// two options: change or starve
add(cut(49), cut(51), { draw: (t, lt, u) => { let s = lab(t, s0(49), 'TWO OPTIONS', W / 2, 220, { size: 50 });
  s += pop(t, s0(50), `<rect x="-260" y="-110" width="520" height="220" rx="20" fill="#1b5a46"/><text y="24" font-family="M" font-weight="900" font-size="80" fill="#fff" text-anchor="middle">CHANGE</text>`, 620, 560);
  s += pop(t, w(50, 2), `<rect x="-260" y="-110" width="520" height="220" rx="20" fill="#5a1b1b"/><text y="24" font-family="M" font-weight="900" font-size="80" fill="#fff" text-anchor="middle">STARVE</text>`, 1300, 560);
  return scene('card', t, u, s); } });
// they changed. they climbed.
add(cut(51), cut(53), { draw: (t, lt, u) => { const up = ease(clamp(lt / 2.6, 0, 1));
  let s = `<rect x="880" y="-20" width="160" height="1120" fill="#2a1d12"/><rect x="900" y="-20" width="30" height="1120" fill="#3b2a18"/>` + K.leaves(960, 120, 2.2) + K.leaves(860, 360, 1.4) + K.leaves(1080, 560, 1.5);
  s += `<g transform="translate(960,${lerp(1000, 420, up)}) rotate(-90)">${K.snake(t * 3, { len: 560, amp: 22, w: 34 })}</g>`;
  s += lab(t, s0(51), 'THEY CHANGED', 460, 420, { size: 52 }) + lab(t, s0(52), 'THEY [CLIMBED]', 1460, 420, { size: 58 });
  return scene('forest', t, u, s); } });

// ===================== BIRDS + VENOM =====================
add(cut(53), cut(54), { draw: (t, lt, u) => { let s = K.branch(-50, 760, 1300, 700, '#2a1d12', 46) + K.leaves(300, 700, 1.4) + K.leaves(1100, 650, 1.2);
  s += `<g transform="translate(640,690) scale(.75)">${K.snake(t * .8, { len: 760, amp: 22, flat: true })}</g>`;
  for (let i = 0; i < 6; i++) { const x = 1900 - ((t - s0(53)) * 140 + i * 160) % 2100, y = 200 + i * 55 + Math.sin(t * 2 + i) * 14; s += `<g transform="translate(${x},${y}) scale(-1.4,1.4)">${K.bird(t * 9 + i, 1)}</g>`; }
  s += lab(t, s0(53) + .3, 'UP IN THE BRANCHES', 520, 220, { size: 44 }) + lab(t, w(53, 11), 'THE ONE FOOD THAT KEEPS ARRIVING: [BIRDS]', W / 2, 980, { size: 40 });
  return scene('dawn', t, u, s); } });
// 40+ kinds of bird stop here
add(cut(54), cut(55), { draw: (t, lt, u) => { let s = '';
  for (let i = 0; i < 42; i++) { const c = i % 14, r = Math.floor(i / 14); s += pop(t, w(54, 2) + i * .03, K.bird(t * 6 + i, 1.3, ['#d7e3e6', '#f2c14e', '#9fd3e6', '#e98a6a'][i % 4]), 360 + c * 92, 470 + r * 120, 1, .25); }
  s += big(t, w(54, 2), '[40+] KINDS OF BIRD', W / 2, 300, 80) + lab(t, w(54, 10), 'STOP HERE WHILE THEY MIGRATE', W / 2, 880, { size: 38 });
  return scene('card', t, u, s); } });
// adults survive on just 1-2 of them a year
add(cut(55), cut(56), { draw: (t, lt, u) => { let s = ''; const f = ease(ramp(t, w(55, 9), .6));
  for (let i = 0; i < 42; i++) { const c = i % 14, r = Math.floor(i / 14); const keep = i === 15 || i === 23; s += `<g transform="translate(${360 + c * 92},${470 + r * 120})" opacity="${keep ? 1 : 1 - .85 * f}">${K.bird(t * 6 + i, keep ? 1.3 + .5 * f : 1.3, keep ? C.amber : '#d7e3e6')}</g>`; }
  s += lab(t, s0(55), 'ADULT LANCEHEADS MOSTLY LIVE ON', W / 2, 260, { size: 40 }) + big(t, w(55, 9), 'JUST [1–2] SPECIES A YEAR', W / 2, 360, 70);
  return scene('card', t, u, s); } });
// a bird is a hard thing to catch / the mouse: bite, run, die, trail
add(cut(56), cut(58), { draw: (t, lt, u) => { const run = ease(clamp((t - w(57, 7)) / 1.6, 0, 1)), fol = ease(clamp((t - w(57, 16)) / 1.6, 0, 1));
  let s = lab(t, s0(56), 'A BIRD IS HARD TO CATCH', W / 2, 200, { size: 46, out: s0(57) }) + lab(t, s0(57), 'BITE A [MOUSE]...', W / 2, 200, { size: 46 });
  s += `<rect y="760" width="${W}" height="320" fill="#071a12"/>`;
  s += `<line x1="700" y1="770" x2="${lerp(700, 1400, run)}" y2="770" stroke="${C.amber}" stroke-width="5" stroke-dasharray="4 18" stroke-linecap="round"/>`;
  s += `<g transform="translate(${lerp(700, 1400, run)},740) rotate(${run >= 1 ? 180 : 0})">${K.mouse(1.2)}</g>`;
  s += `<g transform="translate(${lerp(420, 1100, fol)},760) scale(.6)">${K.snake(t * 3, { len: 640, amp: 18, flat: true })}</g>`;
  s += lab(t, w(57, 8), 'RUNS A FEW METRES', 1050, 660, { size: 34 }) + lab(t, w(57, 17), 'THE SNAKE [FOLLOWS THE TRAIL]', W / 2, 960, { size: 40 });
  return scene('forest', t, u, s, { rays: false }); } });
// bite a bird: it flies away over the ocean. gone.
add(cut(58), cut(61), { draw: (t, lt, u) => { const fly = ease(clamp((t - w(58, 7)) / 3.4, 0, 1));
  let s = `<rect y="780" width="${W}" height="300" fill="#0b2c38"/>` + K.branch(-40, 520, 700, 470, '#2a1d12', 40) + `<g transform="translate(300,470) scale(.55)">${K.snake(t, { len: 600, amp: 16, flat: true })}</g>`;
  s += `<g transform="translate(${lerp(700, 2100, fly)},${lerp(440, 220, fly)}) scale(${lerp(1.8, .6, fly)})" opacity="${1 - clamp((t - s0(60)) / .6, 0, 1)}">${K.bird(t * 10, 1)}</g>`;
  s += lab(t, s0(58), 'BITE A [BIRD]...', W / 2, 200, { size: 46 }) + lab(t, s0(59), 'OVER THE OCEAN', 1400, 640, { size: 40 }) + big(t, s0(60), '[GONE]', W / 2, 900, 110);
  return scene('dawn', t, u, s); } });
// the venom had to work fast
add(cut(61), cut(62), { draw: (t, lt, u) => scene('card', t, u, pop(t, s0(61), K.watch(t, 1.6, (t - s0(61)) * 7), W / 2, 560) + lab(t, s0(61), 'THE VENOM HAD TO WORK', W / 2, 220, { size: 46 }) + big(t, w(61, 6) - .1, '[FAST]', W / 2, 900, 110)) });
// lab tests: fastest-acting in its family, possibly ~5x its mainland cousin
add(cut(62), cut(63), { draw: (t, lt, u) => { const g1 = ease(ramp(t, w(62, 17) - .6, 1.2));
  let s = lab(t, s0(62), 'LAB TESTS [SUGGEST]', W / 2, 180, { size: 44 }) + lab(t, w(62, 8), 'FASTEST-ACTING VENOM IN ITS GENUS', W / 2, 250, { size: 40, color: C.amber });
  s += fade(t, w(62, 14), `<rect x="560" y="430" width="160" height="40" fill="#9fb5bb"/><text x="540" y="462" font-family="M" font-weight="800" font-size="32" fill="#fff" text-anchor="end">MAINLAND COUSIN</text>` +
    `<rect x="560" y="560" width="${160 * lerp(1, 5, g1)}" height="40" fill="${C.red}"/><text x="540" y="592" font-family="M" font-weight="800" font-size="32" fill="#fff" text-anchor="end">GOLDEN LANCEHEAD</text>` +
    `<text x="${580 + 160 * lerp(1, 5, g1)}" y="594" font-family="M" font-weight="900" font-size="40" fill="${C.red}">~${lerp(1, 5, g1).toFixed(0)}×?</text>`);
  s += lab(t, w(62, 15), 'POSSIBLY ~5× AS POTENT', W / 2, 820, { size: 44 }) + lab(t, w(62, 15) + .3, 'EARLY LAB ESTIMATE', W / 2, 880, { size: 28, color: '#9fb5bb' });
  return scene('lab', t, u, s); } });

// ===================== THE HEAT SENSE =====================
add(cut(63), cut(64), { draw: (t, lt, u) => scene('thermal', t, u, `<g transform="translate(960,880) scale(3)"><ellipse cx="0" cy="-70" rx="70" ry="120" fill="url(#therm)"/>${K.person({ col: '#ffe08a', pack: '#ff8a00' })}</g>` + lab(t, s0(63) + .2, 'REMEMBER?', W / 2, 200, { size: 54 }) + lab(t, w(63, 5), 'IT SEES YOUR [HEAT]', W / 2, 270, { size: 44 }), { rays: false }) });
add(cut(64), cut(66), { draw: (t, lt, u) => { const z = 1 + .5 * ease(ramp(t, s0(65), 1.4)); const waves = t > w(65, 13);
  let s = `<g transform="translate(860,560) scale(${2.6 * z})">` + K.snake(0, { len: 300, amp: 0, w: 46, pit: t > w(65, 8) ? .6 + .4 * Math.sin(t * 5) : 0 }).replace('<g>', '<g transform="translate(-160,0)">') + `</g>`;
  if (waves) for (let k = 0; k < 4; k++) { const r = ((t * 120 + k * 70) % 280); s += `<circle cx="${860 + 2.6 * z * -2}" cy="${560 - 2.6 * z * 6}" r="${r}" fill="none" stroke="${C.amber}" stroke-width="4" opacity="${(1 - r / 280) * .8}"/>`; }
  s += lab(t, s0(64), 'PIT [VIPER]', W / 2, 180, { size: 50 }) + arrow(t, w(65, 7), 1360, 300, 1010, 520) + lab(t, w(65, 7), 'HEAT PIT', 1460, 280, { size: 44, color: C.amber });
  s += lab(t, w(65, 15), 'READS WARMTH LIKE A [THERMAL CAMERA]', W / 2, 960, { size: 40 });
  return scene('card', t, u, s); } });
// photo: real thermal image of a hand; HUD
add(cut(66), cut(67), { photo: { img: 'ph_thermal', from: [.5, .5, 1.0], to: [.55, .5, 1.12], filter: 'saturate(1.05) brightness(.95)' },
  draw: (t, lt, u) => `<rect x="0" y="0" width="${W}" height="${H}" fill="#000" opacity=".25"/>` + `<g stroke="#fff" stroke-width="4" fill="none" opacity=".9"><path d="M60,60 h80 M60,60 v80 M1860,60 h-80 M1860,60 v80 M60,1020 h80 M60,1020 v-80 M1860,1020 h-80 M1860,1020 v-80"/></g>` +
    `<circle cx="${W / 2}" cy="${H / 2}" r="40" fill="none" stroke="#fff" stroke-width="3"/><line x1="${W / 2 - 70}" y1="${H / 2}" x2="${W / 2 + 70}" y2="${H / 2}" stroke="#fff" stroke-width="3"/><line x1="${W / 2}" y1="${H / 2 - 70}" x2="${W / 2}" y2="${H / 2 + 70}" stroke="#fff" stroke-width="3"/>` +
    `<circle cx="1820" cy="100" r="12" fill="${C.red}" opacity="${Math.sin(t * 6) > 0 ? 1 : .2}"/>` + lab(t, s0(66), 'IN EXPERIMENTS', 120, 120, { size: 36, anchor: 'start' }) + tag(t, w(66, 8), '< 0.2 °C WARMER', W / 2, 900, { size: 44 }) + lab(t, w(66, 4), 'PIT VIPERS STRUCK [ACCURATELY]', W / 2, 1000, { size: 34 }) });
// your body runs at 37 degrees; on a shady branch you're not a person
add(cut(67), cut(69), { draw: (t, lt, u) => { const th = ease(ramp(t, w(68, 7), .5));
  let s = pop(t, s0(67), K.thermo(.86, 1.3), 420, 760) + big(t, w(67, 5), '[37] °C', 420, 960, 80);
  s += `<g opacity="${1 - th}">` + K.trees(t, 1000, '#08201a', 4, 31).replace(/<rect x="(\d+)/g, (m) => m) + `</g>`;
  s += `<g transform="translate(1250,880) scale(2.4)"><g opacity="${th}"><ellipse cx="0" cy="-70" rx="70" ry="120" fill="url(#therm)"/></g>${K.person(th > .5 ? { col: '#ffe08a', pack: '#ff8a00' } : {})}</g>`;
  s += lab(t, s0(68), 'ON A SHADY BRANCH...', 1250, 220, { size: 40 }) + lab(t, w(68, 8), 'YOU\'RE [NOT A PERSON]', 1250, 290, { size: 44 });
  return scene(th > .5 ? 'thermal' : 'forest', t, u, s, { rays: false }); } });
// you're a heater with legs
add(cut(69), cut(70), { draw: (t, lt, u) => scene('thermal', t, u, pop(t, s0(69), K.radiator(t, 2), W / 2, 640) + big(t, w(69, 2), 'A HEATER [WITH LEGS]', W / 2, 220, 90), { rays: false }) });

// ===================== THE LEGEND =====================
add(cut(70), cut(71), { draw: (t, lt, u) => scene('night', t, u, big(t, s0(70) + .1, 'THAT [FAMILY]', W / 2, 560, 120) + K.dots(3, 6), { rays: false }) });
add(cut(71), cut(72), { photo: { img: 'ph_lhtower', from: [.45, .45, 1.0], to: [.42, .42, 1.18] },
  draw: (t, lt, u) => `<rect width="${W}" height="${H}" fill="#04121a" opacity=".25"/>` + tag(t, w(71, 1), '1909', 220, 160, { size: 50, fill: C.red }) + lab(t, w(71, 3), 'BRAZIL BUILDS A [LIGHTHOUSE]', 120, 960, { size: 46, anchor: 'start' }) + lab(t, w(71, 11), 'A KEEPER + HIS FAMILY MOVE IN', 120, 1020, { size: 34, anchor: 'start' }) });
add(cut(72), cut(73), { draw: (t, lt, u) => scene('card', t, u, pop(t, s0(72), K.paper(760, 520, 'THE LOCAL LEGEND', 6, { fill: '#d9cfb4' }), W / 2, 560) + lab(t, s0(72), 'AS THE STORY GOES...', W / 2, 200, { size: 40, color: '#cfc2a0' })) });
add(cut(73), cut(74), { draw: (t, lt, u) => { const op = ease(ramp(t, w(73, 5), .6)); const sl = ease(clamp((t - w(73, 2)) / 2.4, 0, 1));
  let s = `<g transform="translate(960,880)">${K.house(1.8, '#ffd27a', op)}</g>` + `<g transform="translate(${lerp(560, 760, sl)},${lerp(560, 700, sl)}) rotate(40) scale(.45)">${K.snake(t * 3, { len: 400, amp: 18 })}</g>`;
  s += `<circle cx="1600" cy="180" r="70" fill="#e9eef0" opacity=".85"/>` + lab(t, s0(73), 'ONE NIGHT...', W / 2, 180, { size: 48 }) + lab(t, w(73, 7), 'AN [OPEN WINDOW]', W / 2, 1000, { size: 40 });
  return scene('night', t, u, s, { rays: false }); } });
add(cut(74), cut(76), { draw: (t, lt, u) => { const run = clamp((t - w(74, 7)) / 5, 0, 1);
  let s = `<rect y="820" width="${W}" height="260" fill="#050b10"/>` + K.branch(-40, 300, 1960, 260, '#1a1410', 40);
  for (let i = 0; i < 5; i++) { const x = 300 + i * 340, drop = ease(clamp((t - w(74, 13) - i * .25) / .8, 0, 1)); s += `<line x1="${x}" y1="290" x2="${x}" y2="${290 + drop * 260}" stroke="${C.gold}" stroke-width="16" stroke-linecap="round"/><circle cx="${x}" cy="${300 + drop * 260}" r="14" fill="${C.gold}"/>`; }
  for (let i = 0; i < 4; i++) s += `<g transform="translate(${lerp(200, 1500, run) - i * 70},820) scale(${i ? .45 : .6})">${K.person({ col: '#c9d3d6' })}</g>`;
  s += `<g transform="translate(1720,850)">${K.boat(.8)}</g>` + lab(t, s0(74), 'THEY RAN FOR THE [BOAT]', W / 2, 180, { size: 46 }) + fade(t, s0(75), `<rect width="${W}" height="${H}" fill="#000" opacity=".55"/>`) + big(t, s0(75), 'NONE OF THEM MADE IT', W / 2, 560, 80, { out: s0(76) });
  return scene('night', t, u, s, { rays: false, po: .2 }); } });
add(cut(76), cut(78), { draw: (t, lt, u) => scene('card', t, u, `<g transform="translate(960,560)">${K.paper(760, 520, 'THE LOCAL LEGEND', 6, { fill: '#d9cfb4' })}</g>` + lab(t, s0(76), 'A CHILLING STORY', W / 2, 200, { size: 46 }) + stamp(t, w(77, 6), 'NO RECORD', W / 2, 600, { size: 90 }) + lab(t, w(77, 3), '...AND ONLY A [STORY]', W / 2, 960, { size: 40 })) });
add(cut(78), cut(79), { draw: (t, lt, u) => scene('night', t, u, `<g transform="translate(700,940)">${K.lighthouse(1.6, .7, -15 + Math.sin(t * .6) * 25)}</g>` + tag(t, w(78, 8), 'AUTOMATED BY THE 1920s', 1300, 420, { size: 38, fill: '#2e6d8a' }) + lab(t, w(78, 14), 'NOBODY HAS LIVED HERE [SINCE]', 1300, 560, { size: 40 }), { rays: false }) });

// ===================== WHAT'S YOUR PLAN =====================
const plans = ['GO FAST', 'GO AT NIGHT', 'THICK BOOTS', 'ANTIVENOM'];
function plan(t, hi, struck, x = 1240, y = 330) { let s = `<rect x="${x - 60}" y="${y - 110}" width="680" height="${100 + plans.length * 110}" rx="20" fill="#0d222b" stroke="#e9eef0" stroke-opacity=".3" stroke-width="3"/>` +
    `<text x="${x}" y="${y - 40}" font-family="M" font-weight="900" font-size="44" fill="#fff">YOUR PLAN</text>`;
  plans.forEach((p, i) => { const yy = y + 60 + i * 110; s += `<text x="${x}" y="${yy}" font-family="M" font-weight="800" font-size="46" fill="${i === hi ? C.amber : '#e9eef0'}" opacity="${i === hi ? 1 : .6}">${i + 1}. ${p}</text>`;
    if (struck[i] !== undefined) s += strike(t, struck[i], x - 10, yy - 16, x + 34 * p.length + 70, yy - 16, { w: 10 }); }); return s; }
add(cut(79), cut(81), { draw: (t, lt, u) => { const go = ease(clamp((t - s0(79)) / 3, 0, 1));
  let s = `<rect y="780" width="${W}" height="300" fill="#071c24"/>` + `<g transform="translate(400,780)">${K.islandSil('#0a1f1a', .9)}</g>` + `<g transform="translate(${lerp(760, 1900, go)},800)">${K.boat(.8)}</g>` + `<g transform="translate(560,700) scale(.8)">${K.person({})}</g>`;
  s += lab(t, s0(79), 'THE BOAT HAS [LEFT]', 560, 200, { size: 44 }) + fade(t, s0(80) - .3, plan(t, -1, []));
  return scene('sea', t, u, s); } });
add(cut(81), cut(82), { draw: (t, lt, u) => scene('card', t, u, plan(t, 0, []) + `<g transform="translate(560,760) scale(1.6)">${K.person({})}</g>` + `<path d="M380,640 l-90,0 M400,700 l-120,0 M380,760 l-90,0" stroke="#fff" stroke-width="8" stroke-linecap="round" opacity=".6"/>` + lab(t, s0(81), 'OPTION 1: [GO FAST]', 560, 300, { size: 46 })) });
add(cut(82), cut(83), { gl: 'island', g: { cam: [[0, -46.677, -24.488, .9, 14, 215], [cut(83) - cut(82), -46.676, -24.484, .75, 22, 175]], dark: 1 },
  draw: (t, lt, u) => lab(t, w(82, 3), 'STEEP · ROCKY · FOREST', W / 2, 140, { size: 40 }) + big(t, w(82, 10) - .2, 'OVER [200 M] HIGH', W / 2, 980, 80) + K.vignette() });
add(cut(83), cut(84), { draw: (t, lt, u) => { let s = K.branch(1000, 480, 1960, 420, '#2a1d12', 40) + K.leaves(1500, 430, 1.4) + `<g transform="translate(1260,450) scale(-.55,.55)">${K.snake(t * 2, { len: 520, amp: 14, tongue: Math.sin(t * 12) > 0 ? 1 : 0 })}</g>`;
  s += `<g transform="translate(760,980) scale(3.8)">${K.person({})}</g>` + `<line x1="400" y1="470" x2="1700" y2="470" stroke="${C.red}" stroke-width="4" stroke-dasharray="14 10"/>` + lab(t, s0(83), 'AT [FACE HEIGHT]', 420, 420, { size: 50 });
  return scene('forest', t, u, s); } });
add(cut(84), cut(86), { draw: (t, lt, u) => scene('night', t, u, plan(t, 1, { 0: s0(84) - .1 }) + `<circle cx="420" cy="260" r="110" fill="#e9eef0"/><circle cx="470" cy="230" r="100" fill="#0b1626"/>` + `<g transform="translate(560,860) scale(2)">${K.person({ col: '#7d8a8f' })}</g>` +
  lab(t, s0(84), 'OPTION 2: GO AT [NIGHT]', 560, 520, { size: 44 }) + lab(t, s0(85), 'THIS SNAKE DOESN\'T NEED [LIGHT]', 560, 600, { size: 36 }), { rays: false }) });
add(cut(86), cut(87), { draw: (t, lt, u) => scene('thermal', t, u, `<rect width="${W}" height="${H}" fill="#12063a"/>` + `<g transform="translate(960,900) scale(3.2)"><ellipse cx="0" cy="-70" rx="${80 + 8 * Math.sin(t * 3)}" ry="130" fill="url(#therm)"/>${K.person({ col: '#fff3b0', pack: '#ffb400' })}</g>` +
  lab(t, s0(86), 'ON A [COOL NIGHT]', W / 2, 180, { size: 48 }) + lab(t, w(86, 8), 'YOU STAND OUT [EVEN MORE]', W / 2, 260, { size: 40 }), { rays: false }) });
add(cut(87), cut(90), { draw: (t, lt, u) => { let s = plan(t, 2, { 0: 0, 1: s0(87) - .1 }) + pop(t, s0(87), K.boot(2.2), 560, 760) + lab(t, s0(87), 'OPTION 3: THICK [BOOTS]', 560, 300, { size: 44 });
  s += t >= s0(88) && t < s0(89) ? `<text x="560" y="420" font-family="M" font-weight="900" font-size="80" fill="#3ccf6e" text-anchor="middle">✓ SMART</text>` : '';
  s += t >= s0(89) ? `<g transform="translate(560,620) scale(2)">${K.person({})}</g>` + arrow(t, s0(89), 260, 360, 520, 360, { bend: -40 }) + lab(t, s0(89), 'NOW DO YOUR [NECK]', 560, 220, { size: 48 }) : '';
  return scene('card', t, u, s); } });
add(cut(90), cut(92), { draw: (t, lt, u) => scene('lab', t, u, plan(t, 3, { 0: 0, 1: 0, 2: s0(90) - .1 }) + pop(t, s0(90), K.vial(2.6), 560, 700) + lab(t, s0(90), 'OPTION 4: [ANTIVENOM]', 560, 300, { size: 44 }) + lab(t, w(91, 6), 'BUTANTAN INSTITUTE · SÃO PAULO', 560, 900, { size: 32, color: '#cfe0e4' })) });
add(cut(92), cut(93), { draw: (t, lt, u) => { const d = ease(clamp((t - s0(92)) / 2.5, 0, 1)), b = ease(clamp((t - w(92, 21)) / 1.2, 0, 1));
  let s = `<g transform="translate(320,620)">${K.islandSil('#0e2d24', .5)}</g>` + `<rect x="1460" y="420" width="220" height="200" fill="#e9eef0"/><rect x="1545" y="450" width="50" height="140" fill="${C.red}"/><rect x="1500" y="495" width="140" height="50" fill="${C.red}"/>`;
  s += `<line x1="420" y1="600" x2="${lerp(420, 1440, d)}" y2="600" stroke="#fff" stroke-width="5" stroke-dasharray="16 12"/>` + lab(t, w(92, 2), 'NEAREST HOSPITAL: [1+ HOUR] BY BOAT', W / 2, 520, { size: 40 });
  s += `<g transform="translate(${lerp(320, 900, b)},${lerp(760, 680, b)}) scale(1.4)">${K.bird(t * 10, 1)}</g>` + lab(t, w(92, 14), 'THE VENOM EVOLVED FOR [SECONDS]', W / 2, 900, { size: 40 });
  return scene('sea', t, u, s); } });
add(cut(93), cut(95), { photo: { img: 'ph_navy', from: [.5, .5, 1.0], to: [.55, .5, 1.15] },
  draw: (t, lt, u) => `<rect width="${W}" height="${H}" fill="#04121a" opacity=".3"/>` + lab(t, s0(93), 'BOTTOM LINE', 120, 900, { size: 44, anchor: 'start' }) + lab(t, w(94, 10), 'THE [NAVY] ALREADY CHOSE THE PLAN', 120, 970, { size: 40, anchor: 'start' }) });
add(cut(95), cut(96), { draw: (t, lt, u) => scene('card', t, u, plan(t, -1, { 0: 0, 1: 0, 2: 0, 3: s0(95) - .2 }, 1240, 330) + big(t, s0(95) - .05, 'DON\'T', 520, 520, 150) + big(t, s0(95) + .2, '[LAND.]', 520, 680, 150)) });

// ===================== THE TWIST =====================
add(cut(96), cut(97), { draw: (t, lt, u) => scene('card', t, u, lab(t, s0(96), 'BEFORE YOU CALL THEM [MONSTERS]', W / 2, 400, { size: 46 }) + big(t, w(96, 9), 'THE [TWIST]', W / 2, 600, 130) + K.dots(4, 6)) });
add(cut(97), cut(98), { draw: (t, lt, u) => scene('card', t, u, pop(t, s0(97), K.paper(700, 520, 'OFFICIAL BITE RECORDS', 0), W / 2, 560) + big(t, w(97, 3), '0', W / 2, 700, 220, { color: '#1b1b1b', sw: 0 }) + lab(t, w(97, 8), 'ANYONE BITTEN ON SNAKE ISLAND: [NONE ON RECORD]', W / 2, 960, { size: 36 })) });
add(cut(98), cut(100), { draw: (t, lt, u) => scene('sea', t, u, `<g transform="translate(960,860)">${K.boat(1.6)}</g>` + lab(t, s0(98), '"FISHERMEN FOUND DEAD ON THE ROCKS"', W / 2, 300, { size: 40 }) + stamp(t, s0(99) + .2, 'UNCONFIRMED', W / 2, 560, { size: 90 })) });
add(cut(100), cut(101) - 0, { draw: (t, lt, u) => scene('forest', t, u, `<g transform="translate(1300,940) scale(6)">${K.person({ col: '#0a0f12', pack: '#0a0f12' })}</g>` + `<g transform="translate(560,820) scale(.6)">${K.snake(t * 4, { len: 420, amp: 20 })}</g>` + lab(t, s0(100), 'IF ANYONE SHOULD BE SCARED...', 560, 300, { size: 42 }) + lab(t, w(100, 6), 'IT\'S THE [SNAKES]', 560, 380, { size: 50 }), { rays: false }) });
add(cut(101), cut(103), { draw: (t, lt, u) => { let s = pop(t, s0(101) - .3, `<rect x="-330" y="-120" width="660" height="240" rx="24" fill="${C.red}"/><text y="-18" font-family="M" font-weight="900" font-size="64" fill="#fff" text-anchor="middle">CRITICALLY</text><text y="66" font-family="M" font-weight="900" font-size="64" fill="#fff" text-anchor="middle">ENDANGERED</text>`, W / 2, 380);
  s += lab(t, w(102, 3), 'ONE ISLAND', 520, 720, { size: 40 }) + lab(t, w(102, 6), 'CAN\'T LEAVE', W / 2, 720, { size: 40 }) + lab(t, w(102, 11), '[INBREEDING]', 1400, 720, { size: 40 }) + lab(t, w(102, 17), 'FOR THOUSANDS OF YEARS', W / 2, 860, { size: 34, color: '#9fb5bb' });
  return scene('card', t, u, s); } });
add(cut(103), cut(104), { draw: (t, lt, u) => scene('card', t, u, pop(t, w(103, 5), `<circle r="90" fill="none" stroke="#9fd3e6" stroke-width="16"/><path d="M60,-60 L120,-120 M80,-120 L120,-120 L120,-80" stroke="#9fd3e6" stroke-width="16" fill="none"/><path d="M0,90 L0,170 M-40,130 L40,130" stroke="#f29fc4" stroke-width="16"/>`, W / 2, 470) +
  lab(t, s0(103), 'SOME ARE BORN WITH [BOTH] MALE AND FEMALE PARTS', W / 2, 220, { size: 38 }) + lab(t, w(103, 11), 'MOST OF THOSE [CAN\'T BREED]', W / 2, 860, { size: 44 })) });
add(cut(104), cut(106), { draw: (t, lt, u) => scene('card', t, u, lab(t, s0(104), 'AND THEN THERE\'S [US]', W / 2, 200, { size: 46 }) + tag(t, w(105, 1), '2008', 520, 380, { size: 44, fill: '#2e6d8a' }) + pop(t, w(105, 5), K.pricetag('$30,000', 1.5), 1100, 560) + lab(t, w(105, 13), 'OFFERED FOR A SINGLE GOLDEN LANCEHEAD', W / 2, 900, { size: 38 })) });
add(cut(106), cut(108), { draw: (t, lt, u) => scene('sea', t, u, `<g transform="translate(960,760)">${K.islandSil('#0e2d24', 1.1)}</g>` + pop(t, s0(106) + .3, K.lock(1.1), 960, 520) + lab(t, s0(106), 'WHY THE ISLAND IS [CLOSED]', W / 2, 200, { size: 46 }) + lab(t, w(107, 4), 'PROTECTING YOU FROM THE SNAKES...', W / 2, 960, { size: 36, out: s0(108) })) });
add(cut(108), cut(109), { draw: (t, lt, u) => scene('card', t, u, pop(t, s0(108), K.shield(2.2), 960, 560) + `<g transform="translate(960,590) scale(.35)">${K.snake(t * 2, { len: 500, amp: 18 })}</g>` + `<g transform="translate(1560,880) scale(2.2)">${K.person({ col: '#7d8a8f' })}</g>` + lab(t, s0(108), '...AND THE SNAKES FROM [YOU]', W / 2, 200, { size: 48 })) });

// ===================== THE MEDICINE =====================
add(cut(109), cut(110), { draw: (t, lt, u) => { const b = 1 + .1 * Math.max(0, Math.sin(t * 7)) ** 8; return scene('card', t, u, pop(t, s0(109), `<g transform="scale(${b * 2.6})">${K.heart(1)}</g>`, W / 2, 600) + lab(t, w(109, 5), 'YOUR GRANDPARENTS\' [HEARTS]', W / 2, 220, { size: 48 }) + K.dots(5, 6)); } });
add(cut(110), cut(111), { photo: { img: 'ph_jararaca', from: [.45, .45, 1.0], to: [.42, .4, 1.15] },
  draw: (t, lt, u) => `<rect width="${W}" height="${H}" fill="#04121a" opacity=".25"/>` + tag(t, w(110, 2), '1960s · BRAZIL', 260, 160, { size: 40, fill: '#2e6d8a' }) + lab(t, w(110, 12), 'THE MAINLAND COUSIN: [JARARACA]', 120, 980, { size: 46, anchor: 'start' }) });
add(cut(111), cut(112), { draw: (t, lt, u) => { const d = ease(clamp((t - w(111, 7)) / 1.2, 0, 1)); const a = lerp(-40, 70, d) * Math.PI / 180;
  return scene('lab', t, u, `<g transform="translate(960,620)"><path d="M-300,0 A300,300 0 0 1 300,0" fill="none" stroke="#e9eef0" stroke-width="22"/><path d="M-300,0 A300,300 0 0 1 -150,-260" fill="none" stroke="#3ccf6e" stroke-width="22"/><path d="M150,-260 A300,300 0 0 1 300,0" fill="none" stroke="${C.red}" stroke-width="22"/>` +
    `<line x1="0" y1="0" x2="${Math.sin(-a) * -250}" y2="${-Math.cos(a) * 250}" stroke="${C.amber}" stroke-width="14" stroke-linecap="round"/><circle r="22" fill="#e9eef0"/></g>` + lab(t, w(111, 3), 'A MOLECULE THAT MADE', W / 2, 200, { size: 44 }) + big(t, w(111, 6), 'BLOOD PRESSURE [DROP]', W / 2, 860, 80)); } });
add(cut(112), cut(113), { draw: (t, lt, u) => { const p = ease(clamp((t - s0(112)) / 5, 0, 1));
  let s = `<line x1="300" y1="560" x2="${lerp(300, 1620, p)}" y2="560" stroke="#e9eef0" stroke-width="8"/>` + pop(t, s0(112), `<circle r="20" fill="${C.amber}"/>`, 300, 560) + lab(t, s0(112), '1960s · VENOM RESEARCH', 300, 480, { size: 32 });
  s += pop(t, w(112, 4), K.pill(1.4), 960, 400) + lab(t, w(112, 4), '[CAPTOPRIL]', 960, 560 + 90, { size: 56 }) + lab(t, w(112, 14), 'FOR HIGH BLOOD PRESSURE', 960, 720, { size: 34 });
  s += pop(t, w(112, 17), `<circle r="20" fill="${C.red}"/>`, 1620, 560) + lab(t, w(112, 17), '1981 · APPROVED IN THE US', 1620, 480, { size: 32 });
  return scene('lab', t, u, s); } });
add(cut(113), cut(114), { draw: (t, lt, u) => { let s = ''; for (let i = 0; i < 48; i++) { const c = i % 12, r = Math.floor(i / 12); s += pop(t, s0(113) + i * .03, `<g transform="scale(.35)">${K.person({ col: '#cfd6d8', pack: '#7d8a8f' })}</g>`, 400 + c * 102, 470 + r * 130, 1, .25); }
  return scene('card', t, u, s + big(t, s0(113), '[MILLIONS]', W / 2, 280, 110) + lab(t, w(113, 4), 'HAVE TAKEN MEDICINES THAT TRACE BACK TO IT', W / 2, 1000, { size: 34 })); } });
add(cut(114), cut(115), { draw: (t, lt, u) => scene('card', t, u, `<g transform="translate(560,640)">${K.islandSil('#0e2d24', .55)}</g>` + `<g transform="translate(560,560) scale(.4)">${K.snake(t * 2, { len: 600, amp: 20 })}</g>` + lab(t, w(114, 10), 'MOST FEARED ISLAND', 560, 820, { size: 38 }) +
  `<text x="960" y="600" font-family="M" font-weight="900" font-size="90" fill="#fff" text-anchor="middle" opacity="${ease(ramp(t, w(114, 15), .4))}">→</text>` + pop(t, w(114, 16), `<g transform="scale(2)">${K.heart(1)}</g>`, 1360, 600) + lab(t, w(114, 17), 'MILLIONS OF [HEARTS]', 1360, 820, { size: 38 })) });
add(cut(115), cut(116), { photo: { img: 'ph_island_aerial', from: [.5, .5, 1.0], to: [.52, .48, 1.12] },
  draw: (t, lt, u) => `<rect width="${W}" height="${H}" fill="#04121a" opacity=".25"/>` + lab(t, s0(115) + .3, 'A FEW TIMES A YEAR, SCIENTISTS [STILL LAND]', 120, 960, { size: 40, anchor: 'start' }) + tag(t, w(115, 12), 'WITH PERMISSION', 1560, 140, { size: 32, fill: '#2e6d8a' }) });

// ===================== BOOKEND =====================
add(cut(116), cut(119), { gl: 'island', g: { cam: [[0, -46.676, -24.487, 4.2, 5, 30], [cut(119) - cut(116), -46.676, -24.487, 3.2, 7, 18]], dark: .85 },
  draw: (t, lt, u) => lab(t, s0(116) + .2, 'ONE LAST TIME', W / 2, 160, { size: 40 }) + lab(t, w(117, 5), '[33 KM] FROM BRAZIL', W / 2, 980, { size: 44 }) + lab(t, w(118, 3), 'GREEN · QUIET · PERFECT', W / 2, 1040 - 0, { size: 30, color: '#cfe0e4' }) + K.vignette() });
add(cut(119), cut(120), { draw: (t, lt, u) => { const land = ease(clamp((t - s0(119) - 2.5) / 2.4, 0, 1));
  let s = K.branch(-40, 640, 1300, 600, '#2a1d12', 44) + K.leaves(1100, 560, 1.4) + `<g transform="translate(520,600) scale(.65)">${K.snake(t * .6, { len: 760, amp: 16, flat: true })}</g>`;
  s += `<g transform="translate(${lerp(2000, 1200, land)},${lerp(220, 560, land)}) scale(-1.5,1.5)">${K.bird(land >= 1 ? 0 : t * 9, 1)}</g>` + lab(t, s0(119), 'WAITING FOR A [TIRED BIRD]', W / 2, 200, { size: 46 });
  return scene('dawn', t, u, s); } });
add(cut(120), cut(122), { draw: (t, lt, u) => scene('sea', t, u, `<g transform="translate(560,800)">${K.islandSil('#0e2d24', .8)}</g>` + `<g transform="translate(1400,840)">${K.boat(1.2)}</g><g transform="translate(1360,800) scale(.6)">${K.person({})}</g>` + lab(t, s0(120), 'IT ISN\'T WAITING FOR [YOU]', W / 2, 260, { size: 50 }) + lab(t, s0(121), 'IT NEVER WAS', W / 2, 340, { size: 40, color: '#cfe0e4' })) });
add(cut(122), cut(123), { gl: 'coast', g: { cam: [[0, -46.68, -24.48, 8, 14, 125], [cut(123) - cut(122), -46.678, -24.484, 6.5, 12, 110]], sea: [[0, -45], [.6, -45], [4.2, 0]], dark: .95 },
  draw: (t, lt, u, P) => { if (!P) return ''; const [ix, iy] = P(-46.676, -24.487, .35); return lab(t, w(122, 6), 'STUCK ON A [HILL]', ix, iy - 60, { size: 44 }) + lab(t, w(122, 13), 'SURVIVING EVER SINCE', W / 2, 980, { size: 40 }) + K.vignette(); } });
add(cut(123), cut(125), { draw: (t, lt, u) => { let s = `<g transform="translate(960,560)"><circle r="300" fill="#0e3a48"/><path d="M-160,-120 C-80,-200 60,-180 120,-100 C180,-20 140,80 60,120 C-40,170 -160,110 -200,20 C-230,-50 -200,-90 -160,-120 Z" fill="#1d5a46"/></g>`;
  for (let i = 0; i < 5; i++) s += pop(t, s0(123) + .3 + i * .25, `<circle r="14" fill="${C.red}"/><text y="-26" font-family="M" font-weight="900" font-size="40" fill="#fff" text-anchor="middle">?</text>`, 960 + Math.cos(i * 1.3) * 200, 560 + Math.sin(i * 1.9) * 170);
  s += lab(t, s0(123), 'WHERE SHOULD WE DROP YOU [NEXT]?', W / 2, 160, { size: 46 }) + tag(t, s0(124), 'TELL US IN THE COMMENTS', W / 2, 960, { size: 36 });
  return scene('sea', t, u, s); } });
add(cut(125), cut(127), { draw: (t, lt, u) => { let s = `<g transform="translate(620,700)">${K.islandSil('#0e2d24', .6)}</g><g transform="translate(1300,700)">${K.islandSil('#16382c', .7)}</g>` +
  `<line x1="960" y1="300" x2="960" y2="820" stroke="#e9eef0" stroke-width="5" stroke-dasharray="18 14"/>` + lab(t, w(125, 6), 'TODAY', 620, 420, { size: 54 }) + lab(t, w(125, 13), '[TOMORROW]', 1300, 420, { size: 54 }) + lab(t, w(125, 9), 'AN ISLAND WHERE YOU CAN SEE', W / 2, 200, { size: 40 }) + tag(t, s0(126), 'NEXT', W / 2, 960, { size: 40 });
  return scene('sea', t, u, s); } });
add(cut(127), 490, { badge: s0(127) - .1, draw: (t, lt, u) => K.particles(t, 40) + big(t, s0(127) + .1, 'BHUGOL', W / 2, 620, 130) + K.vignette() });

export const SHOTS = sh;
export { s0, w, scene, add, cut, sh };
