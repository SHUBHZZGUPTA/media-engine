import React, { useEffect } from "react";
import { Composition } from "remotion";
import { LakeShort, LAKE_FRAMES } from "./videos/lake/Lake";
// Logs the WebGL renderer string once per browser tab; the Kaggle job aborts if it is ever not the NVIDIA GPU.
const Probe: React.FC = () => {
  useEffect(() => {
    try {
      const c = document.createElement("canvas");
      const g: any = c.getContext("webgl2") || c.getContext("webgl");
      const e = g && g.getExtension("WEBGL_debug_renderer_info");
      console.error("GLRENDERER " + (e ? g.getParameter(e.UNMASKED_RENDERER_WEBGL) : "none"));
    } catch (err) { console.error("GLRENDERER error " + err); }
  }, []);
  return null;
};
const WrappedLake: React.FC = () => <><Probe /><LakeShort /></>;
export const Root: React.FC = () => (
  <Composition id="LakeShort" component={WrappedLake} durationInFrames={LAKE_FRAMES} fps={30} width={1080} height={1920} />
);
