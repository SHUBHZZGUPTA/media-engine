// The whole place as one three.js scene: sky, the lake (polar water mesh with a whirlpool funnel, bowl-shaped bed that
// opens into a shaft), oil rig, barges, tug, island, canal + waterfall, shore trees; a far-away cross-section slab
// (lake + earth + salt mine), a bathtub set, a money desk and the officials' table. update(id, f, camera) poses
// everything for shot `id` at frame f (pure function of id + f).
import * as THREE from "three";
import { V, lam, Kit } from "./build";
import { ctex, rep, grassHD, cloudHD } from "./paint";
import { LIGHTS, LOOK } from "./lights";
import { TONE, CHAR, untone, twoTone } from "./shade";
import { NOINK } from "./ink";
import { Pool, Actor, Fx, stage } from "./cast";
import {
  FPS, SHOTS, camAt, smooth, clamp01, lin, LR, FLOOR, WL, SO, SZ, SLAB_W, SLAB_BOT, LAKE_HW, SLAB_FLOOR, ROOM_X, ROOM_TOP, ROOM_BOT,
  BATH, DESK, OFFICE, BARGES, BOAT, POSTS, holeR, lakeLevel, funnel, rigTilt, rigSink, mineWater, canalFlow, fall, pillarK, plugUp,
  T_STUCK, T_PUNCH, T_SWALLOW, T_BARGES, BATH_PLUG, ShotDef,
} from "./story";

export const loadKit = async (): Promise<Kit> => ({} as Kit);

const rnd = (seed: number, k = 0) => { const x = Math.sin(seed * 127.1 + k * 311.7) * 43758.5453; return x - Math.floor(x); };
const mat = (key: string, color: string) => lam(key, () => ({ color }));
const vmat = () => lam("vertexColored", () => ({ vertexColors: true }));
const box = (m_: THREE.Material, cx: number, cy: number, cz: number, sx: number, sy: number, sz: number) => {
  const m = new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), m_);
  m.position.set(cx, cy, cz); m.castShadow = true; m.receiveShadow = true;
  return m;
};
const cyl = (m_: THREE.Material, r0: number, r1: number, h: number, seg = 16) => {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(r1, r0, h, seg), m_);
  m.castShadow = true; m.receiveShadow = true;
  return m;
};
const ball = (m_: THREE.Material, r: number, ws = 14, hs = 10) => {
  const m = new THREE.Mesh(new THREE.SphereGeometry(r, ws, hs), m_);
  m.castShadow = true; m.receiveShadow = true;
  return m;
};
const beamMesh = (m_: THREE.Material, a: THREE.Vector3, b: THREE.Vector3, th: number) => {
  const m = new THREE.Mesh(new THREE.BoxGeometry(th, a.distanceTo(b), th), m_);
  m.position.copy(a).add(b).multiplyScalar(0.5);
  m.quaternion.setFromUnitVectors(V(0, 1, 0), b.clone().sub(a).normalize());
  m.castShadow = true; m.receiveShadow = true;
  return m;
};

// ---------------- lake geometry rules (shared by the mesh and by objects floating on it) ----------------
export const bowl = (r: number) => FLOOR * smooth((LR - r) / 3);
const funnelR = (st: number) => 7 + 7 * funnel(st);
/** water surface height at (x, z) at story time st */
export const waterY = (x: number, z: number, st: number) => {
  const r = Math.hypot(x, z), D = 9.5 * funnel(st), q = r / funnelR(st);
  return lakeLevel(st) - D / (1 + q * q) ** 1.4;
};

// ---------------- painted textures ----------------
const stripeTex = (key: string, w: number, h: number, draw: (g: CanvasRenderingContext2D) => void) => {
  const t = ctex(key, w, h, (g) => draw(g));
  t.wrapS = t.wrapT = THREE.RepeatWrapping; t.colorSpace = THREE.SRGBColorSpace; t.needsUpdate = true;
  return t;
};
const pipeTex = () => stripeTex("pipeStripes", 64, 256, (g) => {
  g.fillStyle = "#f2b632"; g.fillRect(0, 0, 64, 256);
  g.fillStyle = "#2d3140";
  for (let k = -4; k < 12; k++) { g.beginPath(); g.moveTo(0, k * 32); g.lineTo(64, k * 32 - 32); g.lineTo(64, k * 32 - 16); g.lineTo(0, k * 32 + 16); g.fill(); }
});
const fallsTex = () => stripeTex("fallsTex", 128, 512, (g) => {
  g.fillStyle = "#7fd0ee"; g.fillRect(0, 0, 128, 512);
  for (let k = 0; k < 26; k++) {
    const x = rnd(k, 1) * 128, y = rnd(k, 2) * 512, h = 90 + rnd(k, 3) * 200;
    g.fillStyle = rnd(k, 4) < 0.6 ? "#ffffff" : "#4aa8d8";
    g.fillRect(x - 5, y, 8 + rnd(k, 5) * 8, h); g.fillRect(x - 5, y - 512, 8 + rnd(k, 5) * 8, h); g.fillRect(x - 5, y + 512, 8 + rnd(k, 5) * 8, h);
  }
});
const flowTex = () => stripeTex("canalFlow", 128, 128, (g) => {
  g.fillStyle = "#3aa7c8"; g.fillRect(0, 0, 128, 128);
  g.strokeStyle = "#a9e6f5"; g.lineWidth = 9; g.lineCap = "round";
  for (let k = 0; k < 2; k++) { g.beginPath(); g.moveTo(16, 24 + k * 64); g.lineTo(64, 56 + k * 64); g.lineTo(112, 24 + k * 64); g.stroke(); }
});
const spiralTex = () => stripeTex("tubSpiral", 256, 256, (g) => {
  g.fillStyle = "#58b8e8"; g.fillRect(0, 0, 256, 256);
  g.strokeStyle = "#d4f2ff"; g.lineWidth = 9; g.lineCap = "round";
  for (let a = 0; a < 3; a++) {
    g.beginPath();
    for (let i = 0; i <= 60; i++) { const r = 8 + i * 1.9, th = a * 2.09 + i * 0.13; const x = 128 + r * Math.cos(th), y = 128 + r * Math.sin(th); if (i) g.lineTo(x, y); else g.moveTo(x, y); }
    g.stroke();
  }
});
const tileTex = (key: string, c0: string, c1: string, n: number) => {
  const t = ctex(key, 512, 512, (g) => {
    g.fillStyle = c0; g.fillRect(0, 0, 512, 512);
    g.strokeStyle = c1; g.lineWidth = 6;
    for (let k = 0; k <= n; k++) { g.beginPath(); g.moveTo((k * 512) / n, 0); g.lineTo((k * 512) / n, 512); g.stroke(); g.beginPath(); g.moveTo(0, (k * 512) / n); g.lineTo(512, (k * 512) / n); g.stroke(); }
  });
  t.wrapS = t.wrapT = THREE.RepeatWrapping; t.needsUpdate = true;
  return t;
};
const mapTex = () => ctex("officeMap", 512, 384, (g) => {
  g.fillStyle = "#f3e7c4"; g.fillRect(0, 0, 512, 384);
  g.fillStyle = "#8ec9e0"; g.beginPath(); g.ellipse(190, 190, 110, 80, 0.3, 0, 7); g.fill();
  g.fillStyle = "#7fbf6a"; g.beginPath(); g.ellipse(360, 120, 70, 45, -0.4, 0, 7); g.fill();
  g.strokeStyle = "#a8402f"; g.lineWidth = 8; g.setLineDash([14, 12]); g.beginPath(); g.moveTo(60, 320); g.quadraticCurveTo(230, 250, 430, 330); g.stroke();
  g.setLineDash([]); g.strokeStyle = "#241726"; g.lineWidth = 6; g.strokeRect(6, 6, 500, 372);
  g.strokeStyle = "#a8402f"; g.lineWidth = 14; g.beginPath(); g.moveTo(170, 170); g.lineTo(220, 215); g.moveTo(220, 170); g.lineTo(170, 215); g.stroke();
});

// ---------------- polar meshes (water surface, lake bed) ----------------
class Polar {
  geo = new THREE.BufferGeometry();
  pos: Float32Array; col: Float32Array; nr: number; ns: number;
  constructor(nr: number, ns: number) {
    this.nr = nr; this.ns = ns;
    const n = nr * (ns + 1);
    this.pos = new Float32Array(n * 3); this.col = new Float32Array(n * 3);
    const idx: number[] = [];
    for (let k = 0; k < nr - 1; k++) for (let j = 0; j < ns; j++) {
      const a = k * (ns + 1) + j, b = a + 1, c = a + ns + 1, d = c + 1;
      idx.push(a, b, c, b, d, c);
    }
    this.geo.setAttribute("position", new THREE.BufferAttribute(this.pos, 3));
    this.geo.setAttribute("color", new THREE.BufferAttribute(this.col, 3));
    this.geo.setIndex(idx);
  }
  set(k: number, j: number, x: number, y: number, z: number, c: THREE.Color) {
    const i = (k * (this.ns + 1) + j) * 3;
    this.pos[i] = x; this.pos[i + 1] = y; this.pos[i + 2] = z;
    this.col[i] = c.r; this.col[i + 1] = c.g; this.col[i + 2] = c.b;
  }
  done() {
    (this.geo.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    (this.geo.attributes.color as THREE.BufferAttribute).needsUpdate = true;
    this.geo.computeVertexNormals();
  }
}
const C = (hex: string) => new THREE.Color(hex);
const WC = { deep: C("#1f8fb8"), mid: C("#2aa9c6"), light: C("#5fd0dc"), dark: C("#0f5f8c"), foam: C("#f2fbff") };
const BED = { mud: C("#7a6247"), mudDark: C("#4f3d2e"), wall: C("#9a7653"), wallDark: C("#7d5c3e") };
const tmpC = new THREE.Color();

// ---------------- rig, barge, tug, boat, tree builders ----------------
const RM = () => ({
  red: mat("rigRed", "#d8452c"), yel: mat("rigYel", "#f2b632"), steel: mat("rigSteel", "#8a909c"), dark: mat("rigDark", "#3a3d4a"),
  white: mat("rigWhite", "#f1f3f6"), glass: mat("rigGlass", "#5f8fb8"),
});
/** oil platform with its pivot at the lake surface (y = 0 local); legs reach down to `depth` below it */
function buildRig(depth: number) {
  const g = new THREE.Group(), M = RM();
  const deckY = 6.5;
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
    const leg = cyl(M.yel, 0.5, 0.5, depth + deckY, 12);
    leg.position.set(sx * 6.4, (deckY - depth) / 2, sz * 6.4); g.add(leg);
    const collar = cyl(M.dark, 0.8, 0.8, 1.2, 12); collar.position.set(sx * 6.4, 0.2, sz * 6.4); g.add(collar);
  }
  g.add(beamMesh(M.steel, V(-6.4, -depth * 0.1, -6.4), V(6.4, deckY - 1, -6.4), 0.28), beamMesh(M.steel, V(6.4, -depth * 0.1, -6.4), V(-6.4, deckY - 1, -6.4), 0.28));
  g.add(beamMesh(M.steel, V(-6.4, -depth * 0.1, 6.4), V(6.4, deckY - 1, 6.4), 0.28), beamMesh(M.steel, V(6.4, -depth * 0.1, 6.4), V(-6.4, deckY - 1, 6.4), 0.28));
  g.add(box(M.dark, 0, deckY, 0, 16.5, 1.1, 16.5), box(M.red, 0, deckY + 0.7, 0, 16.7, 0.35, 16.7));
  g.add(box(M.white, -4.6, deckY + 2.5, -4.6, 5, 3.6, 5), box(M.red, -4.6, deckY + 4.5, -4.6, 5.6, 0.5, 5.6), box(M.glass, -4.6, deckY + 2.9, -2.05, 3.2, 1.2, 0.2));
  g.add(box(M.yel, 5, deckY + 1.5, -5, 3, 2, 3), box(M.steel, 5.2, deckY + 1.9, 4.8, 2.2, 2.4, 2.2));
  for (const s of [-1, 1]) {
    g.add(box(M.yel, s * 8.1, deckY + 1.5, 0, 0.18, 0.18, 16.2), box(M.yel, 0, deckY + 1.5, s * 8.1, 16.2, 0.18, 0.18));
    for (let k = -3; k <= 3; k++) { g.add(box(M.yel, s * 8.1, deckY + 1.1, k * 2.6, 0.16, 1.2, 0.16), box(M.yel, k * 2.6, deckY + 1.1, s * 8.1, 0.16, 1.2, 0.16)); }
  }
  // derrick: tapered tower with rungs and braces
  const y0 = deckY + 0.7, y1 = 30, b0 = 3.4, b1 = 0.95, N = 6;
  const corner = (k: number, sx: number, sz: number) => { const t = k / N, h = b0 + (b1 - b0) * t; return V(sx * h, y0 + (y1 - y0) * t, sz * h); };
  const q = [[-1, -1], [1, -1], [1, 1], [-1, 1]] as const;
  for (const [sx, sz] of q) g.add(beamMesh(M.red, corner(0, sx, sz), corner(N, sx, sz), 0.42));
  for (let k = 0; k <= N; k++) {
    for (let i = 0; i < 4; i++) g.add(beamMesh(M.red, corner(k, q[i][0], q[i][1]), corner(k, q[(i + 1) % 4][0], q[(i + 1) % 4][1]), 0.22));
    if (k < N) for (let i = 0; i < 4; i++) g.add(beamMesh(M.red, corner(k, q[i][0], q[i][1]), corner(k + 1, q[(i + 1) % 4][0], q[(i + 1) % 4][1]), 0.16));
  }
  g.add(box(M.dark, 0, y1 + 0.9, 0, 2.6, 1.8, 2.6), box(M.yel, 0, y1 + 2.2, 0, 1.2, 0.9, 1.2));
  const beacon = new THREE.Mesh(new THREE.SphereGeometry(0.5, 10, 8), new THREE.MeshBasicMaterial({ color: new THREE.Color(3, 0.3, 0.2) }));
  beacon.position.set(0, y1 + 3.1, 0); g.add(beacon);
  // drill pipe: striped, rotating; length set per frame
  const pipeMat = twoTone(new THREE.MeshLambertMaterial({ map: pipeTex() }));
  const pipe = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 1, 16).translate(0, 0.5, 0), pipeMat);
  pipe.castShadow = true; g.add(pipe); g.userData.pipe = pipe; g.userData.top = y1;
  const bit = new THREE.Mesh(new THREE.ConeGeometry(0.9, 1.8, 12).rotateX(Math.PI), mat("bitSteel", "#9aa0ad"));
  bit.castShadow = true; g.add(bit); g.userData.bit = bit;
  return g;
}
/** hang the pipe from the derrick top down to y = bottom (rig-local) */
function setPipe(rig: THREE.Group, bottom: number, t: number, shake = 0) {
  const pipe = rig.userData.pipe as THREE.Mesh, bit = rig.userData.bit as THREE.Mesh, top = rig.userData.top as number;
  const len = Math.max(0.1, top - bottom);
  pipe.scale.set(1, len, 1); pipe.position.set(shake, bottom, 0); pipe.rotation.y = t * 7;
  const tex = (pipe.material as THREE.MeshLambertMaterial).map!; tex.repeat.set(1, Math.max(1, len / 4));
  bit.position.set(shake, bottom - 0.9, 0); bit.rotation.y = t * 7;
}
function buildBarge(i: number) {
  const g = new THREE.Group();
  const pal = ["#c4482f", "#2f79b5", "#d9a33a", "#4d8a5a", "#7a5aa8", "#c46a8a"];
  const hull = mat("hull" + (i % 3), ["#3b4a63", "#5b3b3b", "#2f5a55"][i % 3]);
  g.add(box(hull, 0, 0.1, 0, 12, 2.2, 4.8), box(mat("bargeRim", "#c9ced8"), 0, 1.2, 0, 12.3, 0.25, 5.1));
  const n = 3 + (i % 3);
  for (let k = 0; k < n; k++) g.add(box(mat("crate" + ((i + k) % 6), pal[(i + k) % 6]), -4.4 + k * (8.8 / Math.max(1, n - 1)), 2.2, (k % 2 ? 0.7 : -0.6), 2.3, 2.0 + (k % 2) * 0.6, 2.3));
  if (i % 4 === 0) g.add(box(mat("bargeCab", "#f1f3f6"), 4.6, 2.5, 0, 2.4, 2.8, 2.6));
  return g;
}
function buildTug() {
  const g = new THREE.Group();
  g.add(box(mat("tugHull", "#a8402f"), 0, 0.1, 0, 7, 1.8, 3.2), box(mat("tugRim", "#2e3146"), 0, 1.1, 0, 7.2, 0.2, 3.4));
  g.add(box(mat("rigWhite", "#f1f3f6"), -0.8, 2.3, 0, 3, 2.2, 2.4), box(mat("rigGlass", "#5f8fb8"), 0.72, 2.5, 0, 0.12, 0.9, 1.8));
  const ch = cyl(mat("tugStack", "#d8452c"), 0.5, 0.5, 2.2, 12); ch.position.set(-1.6, 4.2, 0); g.add(ch);
  const band = cyl(mat("tugBand", "#2e3146"), 0.52, 0.52, 0.5, 12); band.position.set(-1.6, 4.9, 0); g.add(band);
  return g;
}
function buildBoat() {
  const g = new THREE.Group();
  g.add(box(mat("boatHull", "#b9733e"), 0, 0.2, 0, 3.8, 0.8, 1.5), box(mat("boatInner", "#d9a066"), 0, 0.65, 0, 3.4, 0.12, 1.2));
  const bow = new THREE.Mesh(new THREE.ConeGeometry(0.75, 1.1, 4).rotateZ(-Math.PI / 2).rotateY(Math.PI / 4), mat("boatHull", "#b9733e"));
  bow.position.set(2.4, 0.2, 0); bow.scale.set(1, 0.7, 1); bow.castShadow = true; g.add(bow);
  g.add(box(mat("boatSeat", "#8a5a30"), -0.3, 0.9, 0, 0.6, 0.12, 1.3));
  const rod = cyl(mat("rod", "#5a3b2a"), 0.022, 0.022, 3.4, 6); rod.position.set(1.2, 2.1, 0.2); rod.rotation.z = -0.9; rod.layers.set(NOINK); g.add(rod);
  const line = cyl(mat("rodLine", "#e8e8e8"), 0.015, 0.015, 3.2, 4); line.position.set(2.7, 1.2, 0.2); line.layers.set(NOINK); g.add(line);
  const bob = ball(mat("bobber", "#d8452c"), 0.14, 8, 6); bob.position.set(2.7, -0.15, 0.2); g.add(bob);
  return g;
}
function buildTree(seed: number, h: number) {
  const g = new THREE.Group();
  const trunk = cyl(mat("trunk", "#8a5a3c"), 0.04 * h, 0.025 * h, h * 0.45, 8); trunk.position.y = h * 0.22; g.add(trunk);
  const gr = ["#62ae4c", "#56a447", "#72b853", "#4a9142"][Math.floor(rnd(seed, 1) * 4)];
  for (const [dx, dy, dz, r] of [[0, 0.62, 0, 0.34], [0.2, 0.5, 0.1, 0.26], [-0.18, 0.55, -0.1, 0.27], [0.02, 0.84, 0, 0.22]] as const) {
    const s = ball(mat("leaf" + gr, gr), r * h, 12, 9); s.position.set(dx * h, dy * h, dz * h); g.add(s);
  }
  return g;
}

export class World {
  root = new THREE.Group();
  private pool = new Pool();
  private actors: Actor[] = [];
  private fxs: Fx[] = [];
  private hemi: THREE.HemisphereLight; private sun: THREE.DirectionalLight; private fill: THREE.DirectionalLight;
  private sky: THREE.Mesh; private skyMat: THREE.ShaderMaterial;
  private fog = new THREE.Fog("#bccbec", 25, 420);
  private sunDisc: THREE.Sprite; private sunHalo: THREE.Sprite;
  private sunCache = new Map<number, THREE.Vector3>();
  private cloudMaps: Record<"day" | "golden", THREE.Texture[]>;
  private clouds: THREE.Mesh[] = [];
  private frustum = new THREE.Frustum();
  private m4 = new THREE.Matrix4(); private sphere = new THREE.Sphere(); private v = new THREE.Vector3();
  private gMain = new THREE.Group(); private gSlab = new THREE.Group(); private gBath = new THREE.Group(); private gDesk = new THREE.Group();
  private waterP = new Polar(58, 96); private bedP = new Polar(24, 96); private shaft: THREE.Mesh;
  private rig: THREE.Group; private barges: THREE.Group[] = []; private tug: THREE.Group; private boat: THREE.Group; private island: THREE.Group;
  private fallM: THREE.Mesh; private fallTex: THREE.Texture; private canalTex: THREE.Texture;
  private tubRim: THREE.Group; private duck: THREE.Group; private postsG: THREE.Group; private postSegs: THREE.Mesh[][] = [[], []];
  private office: THREE.Group;
  private slabWaterGeo = new THREE.BufferGeometry(); private roomWater: THREE.Mesh; private pour: THREE.Mesh;
  private slabRig: THREE.Group; private gapL: THREE.Mesh; private gapR: THREE.Mesh; private pillars: THREE.Mesh[] = []; private chunks: THREE.Mesh[] = [];
  private waterMat!: THREE.MeshBasicMaterial; private bathToys!: THREE.Group; private tubWater: THREE.Mesh; private tubSwirl: THREE.Mesh; private plug: THREE.Mesh; private chain: THREE.Mesh;
  private stacks: THREE.Mesh[] = []; private bags: THREE.Mesh[] = [];

  constructor(_kit: Kit) {
    const R = this.root;
    // ---- sky + light ----
    this.skyMat = new THREE.ShaderMaterial({
      uniforms: { c0: { value: new THREE.Color() }, c1: { value: new THREE.Color() }, c2: { value: new THREE.Color() },
        c3: { value: new THREE.Color() }, c4: { value: new THREE.Color() }, e: { value: new THREE.Vector4() } },
      vertexShader: "varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }",
      fragmentShader: `uniform vec3 c0, c1, c2, c3, c4; uniform vec4 e; varying vec3 vP;
        void main(){ float el = asin(clamp(normalize(vP).y, -1.0, 1.0));
          vec3 c = mix(c0, c1, smoothstep(0.0, e.x, el));
          c = mix(c, c2, smoothstep(e.x, e.y, el));
          c = mix(c, c3, smoothstep(e.y, e.z, el));
          c = mix(c, c4, smoothstep(e.z, e.w, el));
          gl_FragColor = vec4(c, 1.0); }`,
      side: THREE.BackSide, depthWrite: false, fog: false,
    });
    this.sky = new THREE.Mesh(new THREE.SphereGeometry(1100, 48, 24), this.skyMat);
    this.sky.renderOrder = -1; this.sky.frustumCulled = false; this.sky.layers.set(NOINK);
    R.add(this.sky);
    const disc = ctex("sunDisc", 128, 128, (g) => { const gr = g.createRadialGradient(64, 64, 58, 64, 64, 64); gr.addColorStop(0, "rgba(255,255,255,1)"); gr.addColorStop(1, "rgba(255,255,255,0)"); g.fillStyle = gr; g.fillRect(0, 0, 128, 128); });
    const halo = ctex("sunHalo", 256, 256, (g) => {
      const im = g.createImageData(256, 256);
      for (let y = 0; y < 256; y++) for (let x = 0; x < 256; x++) {
        const u = Math.hypot(x - 127.5, y - 127.5) / 128;
        const a = (0.55 * Math.exp(-((u / 0.25) ** 2)) + 0.35 * Math.exp(-((u / 0.6) ** 2))) * (1 - Math.min(1, Math.max(0, (u - 0.8) / 0.2)));
        const i = (y * 256 + x) * 4; im.data[i] = im.data[i + 1] = im.data[i + 2] = 255; im.data[i + 3] = Math.round(255 * Math.min(1, a));
      }
      g.putImageData(im, 0, 0);
    });
    this.sunDisc = new THREE.Sprite(new THREE.SpriteMaterial({ map: disc, color: new THREE.Color(6.0, 4.4, 2.4), fog: false, depthWrite: false }));
    this.sunHalo = new THREE.Sprite(new THREE.SpriteMaterial({ map: halo, color: new THREE.Color(1, 1, 1), fog: false, depthWrite: false, depthTest: true, transparent: true, blending: THREE.AdditiveBlending }));
    this.sunDisc.renderOrder = -0.5; this.sunHalo.renderOrder = 5;
    for (const m of [this.sunDisc, this.sunHalo]) { m.frustumCulled = false; m.layers.set(NOINK); R.add(m); }
    this.hemi = new THREE.HemisphereLight("#cfe6ff", "#6c5c8c", 1.1);
    this.sun = new THREE.DirectionalLight("#fff0d6", 2.6);
    this.sun.castShadow = true; this.sun.shadow.mapSize.set(4096, 4096);
    this.fill = new THREE.DirectionalLight("#9fb8ff", 0.35);
    R.add(this.hemi, this.sun, this.sun.target, this.fill, this.fill.target);
    this.cloudMaps = { day: [0, 1, 2, 3].map((k) => cloudHD(k, LOOK.day.cloud)), golden: [0, 1, 2, 3].map((k) => cloudHD(k, LOOK.golden.cloud)) };
    for (let i = 0; i < 9; i++) {
      const a = (i / 9) * Math.PI * 2 + 0.3, d = 620 + (i % 3) * 60;
      const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ map: this.cloudMaps.day[i % 4], color: new THREE.Color(1.1, 1.1, 1.1), transparent: true, depthWrite: false, fog: false }));
      const w = 130 + (i % 4) * 30;
      m.position.set(Math.cos(a) * d, 120 + (i % 4) * 38, Math.sin(a) * d); m.scale.set(w, w / 2, 1);
      m.layers.set(NOINK);
      this.clouds.push(m); R.add(m);
    }
    R.add(this.gMain, this.gSlab, this.gBath, this.gDesk);

    // ================= MAIN: ground, bed, water, shaft, shore =================
    const gm = this.gMain;
    const grass = lam("grassHD", () => ({ map: grassHD() }));
    rep((grass as THREE.MeshLambertMaterial).map!, 90, 90);
    const ground = new THREE.Mesh(new THREE.RingGeometry(LR - 0.02, 360, 128, 1).rotateX(-Math.PI / 2), grass);
    ground.receiveShadow = true; gm.add(ground);
    const bed = new THREE.Mesh(this.bedP.geo, vmat()); bed.receiveShadow = true; bed.castShadow = true; bed.frustumCulled = false; gm.add(bed);
    this.waterMat = new THREE.MeshBasicMaterial({ vertexColors: true }); const water = new THREE.Mesh(this.waterP.geo, this.waterMat); water.frustumCulled = false; gm.add(water);
    this.shaft = new THREE.Mesh(new THREE.CylinderGeometry(1, 1, 70, 32, 1, true).translate(0, -35, 0), new THREE.MeshLambertMaterial({ color: "#3a2a38", side: THREE.DoubleSide }));
    this.shaft.frustumCulled = false; gm.add(this.shaft);
    const camPts: [number, number][] = [];
    for (const sh of SHOTS) if (sh.place === "main") for (let f = sh.a; f < sh.b; f += 10) { const c = camAt(sh.id, f); camPts.push([c.pos[0], c.pos[2]]); }
    for (let i = 0; i < 90; i++) {
      const a = rnd(i, 1) * Math.PI * 2, r = LR + 4 + rnd(i, 2) ** 1.5 * 90, h = 7 + rnd(i, 3) * 7;
      if (Math.abs(a - Math.PI / 2) < 0.16 && r < LR + 60) continue; // keep the canal clear
      if (camPts.some(([cx, cz]) => Math.hypot(cx - Math.cos(a) * r, cz - Math.sin(a) * r) < 11)) continue; // never plant a tree in a lens
      const t = buildTree(i, h); t.position.set(Math.cos(a) * r, 0, Math.sin(a) * r); t.rotation.y = rnd(i, 4) * 6; gm.add(t);
    }
    for (let i = 0; i < 9; i++) {
      const a = (i / 9) * Math.PI * 2 + 0.4, r = 230 + rnd(i, 5) * 60, s = 60 + rnd(i, 6) * 50;
      const hill = ball(mat("hill" + (i % 3), ["#6faa63", "#5f9a6a", "#78b36b"][i % 3]), 1, 24, 14);
      hill.position.set(Math.cos(a) * r, -s * 0.25, Math.sin(a) * r); hill.scale.set(s * 1.6, s * 0.7, s * 1.3); hill.castShadow = false; gm.add(hill);
    }
    // canal (south shore, along +z) with low banks, and the waterfall sheet at its mouth
    this.canalTex = flowTex();
    const canal = new THREE.Mesh(new THREE.PlaneGeometry(10, 240).rotateX(-Math.PI / 2), twoTone(new THREE.MeshLambertMaterial({ map: this.canalTex })));
    canal.position.set(0, 0.12, LR + 120); canal.receiveShadow = true; gm.add(canal);
    for (const s of [-1, 1]) gm.add(box(mat("levee", "#8c6b45"), s * 6.2, 0.55, LR + 120, 2.6, 1.1, 240));
    this.fallTex = fallsTex();
    this.fallM = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ map: this.fallTex, side: THREE.DoubleSide, color: new THREE.Color(1.15, 1.15, 1.15) }));
    this.fallM.rotation.y = Math.PI; this.fallM.visible = false; gm.add(this.fallM);
    // island (swallowed with the lake): grassy mound with a cottage and trees
    this.island = new THREE.Group();
    const mound = cyl(mat("islandSide", "#7d5a3c"), 14, 11, 4.5, 28); mound.position.y = -0.8; this.island.add(mound);
    const cap = new THREE.Mesh(new THREE.CircleGeometry(11, 28).rotateX(-Math.PI / 2), grass); cap.position.y = 1.46; cap.receiveShadow = true; this.island.add(cap);
    this.island.add(box(mat("cottage", "#e8d8b8"), 3, 3.0, 2, 4, 3, 3.4));
    const roof = new THREE.Mesh(new THREE.ConeGeometry(3.4, 2.2, 4).rotateY(Math.PI / 4), mat("cottageRoof", "#b5553a")); roof.position.set(3, 5.5, 2); roof.castShadow = true; this.island.add(roof);
    for (const [x, z, h] of [[-5, 1, 8], [-2, -5, 9], [6, -4, 7], [-6, 5, 7]] as const) { const t = buildTree(x * 3 + z, h); t.position.set(x, 1.4, z); this.island.add(t); }
    this.island.position.set(-20, 0, -18); gm.add(this.island);
    this.rig = buildRig(-FLOOR + WL); gm.add(this.rig);
    for (let i = 0; i < BARGES; i++) { const bg = buildBarge(i); this.barges.push(bg); gm.add(bg); }
    this.tug = buildTug(); gm.add(this.tug);
    this.boat = buildBoat(); gm.add(this.boat);
    // bathtub rim around the lake (shot 16) + rubber duck
    this.tubRim = new THREE.Group();
    const rim = new THREE.Mesh(new THREE.TorusGeometry(LR + 2.2, 2.6, 16, 128).rotateX(Math.PI / 2), mat("tubWhite", "#f6f8fb"));
    rim.position.y = 1.2; rim.castShadow = true; rim.receiveShadow = true; this.tubRim.add(rim);
    for (const [x, z] of [[1, 1], [-1, 1], [1, -1], [-1, -1]] as const) {
      const foot = ball(mat("tubFoot", "#e0b84a"), 5, 14, 10); foot.position.set(x * (LR + 2) * 0.72, -1, z * (LR + 2) * 0.72); foot.scale.set(1, 0.8, 1); this.tubRim.add(foot);
    }
    this.tubRim.visible = false; gm.add(this.tubRim);
    this.duck = new THREE.Group();
    const dy = mat("duckYellow", "#ffd43b");
    const body = ball(dy, 3, 16, 12); body.scale.set(1.25, 0.95, 1); this.duck.add(body);
    const head = ball(dy, 1.9, 14, 10); head.position.set(2.2, 2.4, 0); this.duck.add(head);
    this.duck.add(box(mat("duckBeak", "#f08a2c"), 3.9, 2.2, 0, 1.6, 0.5, 1.4));
    for (const s of [-1, 1]) { const e = ball(mat("duckEye", "#241726"), 0.28, 8, 6); e.position.set(3.0, 2.9, s * 0.9); this.duck.add(e); }
    this.duck.position.set(-9, WL + 1.8, 5); this.duck.scale.setScalar(1.5); this.duck.visible = false; gm.add(this.duck);
    // the two gauge posts of the last shot: one block against twenty
    this.postsG = new THREE.Group();
    POSTS.forEach((p, pi) => {
      const n = pi === 0 ? 1 : 20;
      for (let k = 0; k < n; k++) {
        const s = box(mat("postSeg" + (k % 2), k % 2 ? "#f4f6fa" : "#2d8fd6"), p[0], WL + 1.5 + k * 3, p[2], 3, 3, 3);
        s.visible = false; this.postSegs[pi].push(s); this.postsG.add(s);
      }
    });
    this.postsG.visible = false; gm.add(this.postsG);
    // officials' table (shot 19): table, map, drill bit
    this.office = new THREE.Group();
    this.office.position.set(...OFFICE);
    this.office.add(box(mat("deskWood", "#9a6a3f"), 0, 1.0, 0.8, 5, 0.3, 2.4));
    for (const [x, z] of [[-2.3, -0.2], [2.3, -0.2], [-2.3, 1.8], [2.3, 1.8]]) this.office.add(box(mat("deskWood2", "#7a5230"), x, 0.45, z, 0.3, 0.9, 0.3));
    const mapM = new THREE.Mesh(new THREE.PlaneGeometry(2.6, 1.95).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ map: mapTex() }));
    mapM.position.set(-0.95, 1.17, 0.8); mapM.rotation.y = 0.15; this.office.add(mapM);
    const bitM = new THREE.Mesh(new THREE.ConeGeometry(0.6, 1.5, 12), mat("bitSteel", "#9aa0ad")); bitM.position.set(1.4, 1.9, 0.8); bitM.rotation.z = Math.PI / 2 + 0.2; bitM.castShadow = true; this.office.add(bitM);
    this.office.add(box(mat("rigDark", "#3a3d4a"), 2.0, 1.4, 0.8, 0.6, 0.4, 0.6));
    this.office.visible = false; gm.add(this.office);

    // ================= SLAB: cross-section of lake, earth and mine =================
    const gs = this.gSlab;
    const earth = [mat("earthTop", "#7a4f33"), mat("earthMid", "#a8704a"), mat("earthDeep", "#8a6444"), mat("earthRock", "#6d6a78")];
    const depth = 12, cz = SO[2], slabZ0 = SO[2] - 6;
    const slabBox = (mt: THREE.Material, x0: number, x1: number, y0: number, y1: number) => { const m = box(mt, (x0 + x1) / 2, (y0 + y1) / 2, cz, x1 - x0, y1 - y0, depth); gs.add(m); return m; };
    gs.add(box(mat("slabBack", "#6f5a78"), 0, SLAB_BOT / 2, slabZ0 - 0.4, SLAB_W * 2 + 2, -SLAB_BOT + 4, 0.6));
    for (const [x0, x1] of [[-SLAB_W, -ROOM_X], [ROOM_X, SLAB_W]] as const) {
      slabBox(mat("slabGrass", "#6aab4f"), x0, x1, -1.2, 0);
      slabBox(earth[0], x0, x1, -6, -1.2);
      slabBox(earth[1], x0, x1, ROOM_TOP, -6);
      slabBox(mat("saltWall", "#efe6dc"), x0, x1, ROOM_BOT, ROOM_TOP);
      slabBox(earth[3], x0, x1, SLAB_BOT, ROOM_BOT);
    }
    for (const [x0, x1] of [[-ROOM_X, -LAKE_HW], [LAKE_HW, ROOM_X]] as const) { slabBox(mat("slabGrass", "#6aab4f"), x0, x1, -1.2, 0); slabBox(earth[0], x0, x1, SLAB_FLOOR, -1.2); }
    this.gapL = slabBox(earth[2], -ROOM_X, 0, ROOM_TOP, SLAB_FLOOR);
    this.gapR = slabBox(earth[2], 0, ROOM_X, ROOM_TOP, SLAB_FLOOR);
    slabBox(earth[3], -ROOM_X, ROOM_X, SLAB_BOT, ROOM_BOT);
    gs.add(box(mat("saltBack", "#f6efe6"), 0, (ROOM_TOP + ROOM_BOT) / 2, slabZ0 + 0.1, ROOM_X * 2, ROOM_TOP - ROOM_BOT, 0.2));
    gs.add(box(mat("saltFloor", "#e6dccf"), 0, ROOM_BOT + 0.05, cz, ROOM_X * 2, 0.1, depth));
    [-14, -7, 7, 14].forEach((x) => {
      const p = box(mat("saltPillar", "#fff7ee"), x, (ROOM_TOP + ROOM_BOT) / 2, SO[2] - 1.5, 2.6, ROOM_TOP - ROOM_BOT, 2.6); gs.add(p); this.pillars.push(p);
    });
    for (let i = 0; i < 7; i++) { const c = box(mat("saltChunk", "#fff7ee"), -9 + i * 3, ROOM_TOP - 1, SO[2] + (i % 3) - 2, 1.2 + (i % 3) * 0.4, 1.2, 1.4); c.visible = false; gs.add(c); this.chunks.push(c); }
    const sw = new THREE.Mesh(this.slabWaterGeo, mat("slabWaterMat", "#2aa9c6")); sw.frustumCulled = false; sw.receiveShadow = true; gs.add(sw);
    this.roomWater = box(mat("roomWater", "#2a95c0"), 0, ROOM_BOT, SO[2] + 0.5, ROOM_X * 2 - 0.2, 1, depth - 1.2); gs.add(this.roomWater);
    this.pour = box(new THREE.MeshBasicMaterial({ color: "#4fc4e8" }) as unknown as THREE.Material, 0, (ROOM_TOP + ROOM_BOT) / 2, SO[2], 1, 1, 2); gs.add(this.pour);
    this.slabRig = buildRig(-SLAB_FLOOR); this.slabRig.position.set(0, 0, SO[2]); gs.add(this.slabRig);

    // ================= BATH: tub, tiles, water, plug =================
    const gb = this.gBath;
    const floorT = tileTex("bathFloor", "#e9f1f6", "#bcd0dc", 8); floorT.repeat.set(10, 10);
    const bathFloor = new THREE.Mesh(new THREE.PlaneGeometry(120, 120).rotateX(-Math.PI / 2), twoTone(new THREE.MeshLambertMaterial({ map: floorT })));
    bathFloor.position.set(...BATH); bathFloor.receiveShadow = true; gb.add(bathFloor);
    const wallT = tileTex("bathWall", "#bfe6d8", "#8cc4b0", 8); wallT.repeat.set(10, 4);
    const bathWall = new THREE.Mesh(new THREE.PlaneGeometry(120, 40), twoTone(new THREE.MeshLambertMaterial({ map: wallT })));
    bathWall.position.set(BATH[0], 20, BATH[2] - 12); bathWall.receiveShadow = true; gb.add(bathWall);
    const tub = new THREE.Group(); tub.position.set(...BATH); gb.add(tub);
    const white = mat("tubWhite", "#f6f8fb");
    tub.add(box(white, 0, 0.6, 0, 9, 0.6, 4.2), box(white, 0, 1.3, 1.85, 9.2, 2.0, 0.5), box(white, 0, 1.3, -1.85, 9.2, 2.0, 0.5), box(white, 4.35, 1.3, 0, 0.5, 2.0, 4.2), box(white, -4.35, 1.3, 0, 0.5, 2.0, 4.2));
    for (const [x, z] of [[-3.6, -1.5], [3.6, -1.5], [-3.6, 1.5], [3.6, 1.5]]) { const f = ball(mat("tubFoot", "#e0b84a"), 0.45, 10, 8); f.position.set(x, 0.3, z); tub.add(f); }
    const tap = cyl(mat("tapSteel", "#c9ced8"), 0.18, 0.18, 1.6, 10); tap.position.set(-3.6, 3.2, -1.5); tub.add(tap);
    const spout = cyl(mat("tapSteel", "#c9ced8"), 0.18, 0.18, 1.2, 10); spout.rotation.z = Math.PI / 2; spout.position.set(-3.0, 3.9, -1.5); tub.add(spout);
    tub.add(box(mat("tubInner", "#dfe9f2"), 0, 0.88, 0, 8.2, 0.08, 3.2));
    this.tubWater = box(mat("tubWaterMat", "#58b8e8"), 0, 1.5, 0, 8.1, 1, 3.15); tub.add(this.tubWater);
    this.tubSwirl = new THREE.Mesh(new THREE.CircleGeometry(1.5, 32).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ map: spiralTex() })); tub.add(this.tubSwirl);
    this.plug = cyl(mat("plugRubber", "#2e3146"), 0.5, 0.42, 0.35, 14); tub.add(this.plug);
    this.bathToys = new THREE.Group(); tub.add(this.bathToys);
    const d2 = this.duck.clone(); d2.visible = true; d2.position.set(0, 0, 0); d2.scale.setScalar(0.28); this.bathToys.add(d2);
    const b2 = buildBarge(1); b2.scale.setScalar(0.12); this.bathToys.add(b2);
    const t2 = buildTug(); t2.scale.setScalar(0.14); this.bathToys.add(t2);
    this.chain = cyl(mat("chainSteel", "#b7bcc7"), 0.05, 0.05, 1, 6); tub.add(this.chain);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.22, 0.06, 8, 16), mat("chainSteel", "#b7bcc7")); ring.position.set(0, 0.25, 0); this.plug.add(ring);

    // ================= DESK: panelled wall, desk, money =================
    const gd = this.gDesk;
    const dFloor = new THREE.Mesh(new THREE.PlaneGeometry(120, 120).rotateX(-Math.PI / 2), mat("deskFloor", "#7a5a3a")); dFloor.position.set(...DESK); dFloor.receiveShadow = true; gd.add(dFloor);
    const dWall = new THREE.Mesh(new THREE.PlaneGeometry(120, 40), mat("deskWall", "#2f5a4a")); dWall.position.set(DESK[0], 20, DESK[2] - 12); dWall.receiveShadow = true; gd.add(dWall);
    gd.add(box(mat("deskTop", "#a8742f"), DESK[0], 1.0, DESK[2], 5.6, 0.3, 2.2), box(mat("deskBase", "#6b4a26"), DESK[0], 0.43, DESK[2], 5.3, 0.86, 1.9));
    for (let i = 0; i < 9; i++) {
      const s = box(mat("bills" + (i % 2), i % 2 ? "#5faa5f" : "#4f9a54"), DESK[0] - 2.3 + (i % 5) * 0.42, 1.4, DESK[2] - 0.2 + Math.floor(i / 5) * 0.6, 0.34, 0.5, 0.45);
      s.visible = false; this.stacks.push(s); gd.add(s);
    }
    for (let i = 0; i < 4; i++) {
      const bg = ball(mat("moneyBag", "#c9a56a"), 0.55, 12, 10); bg.position.set(DESK[0] + 1.9 + (i % 2) * 0.6, 1.75 + Math.floor(i / 2) * 0.0, DESK[2] + 0.1 + Math.floor(i / 2) * 0.7); bg.scale.set(1, 1.1, 1); bg.visible = false; this.bags.push(bg); gd.add(bg);
    }
    gd.add(box(mat("gavelWood", "#7a4f2a"), DESK[0] + 2.3, 1.4, DESK[2] + 0.5, 0.9, 0.4, 0.4), box(mat("gavelHandle", "#9a6a3a"), DESK[0] + 2.3, 1.4, DESK[2] + 1.0, 0.16, 0.16, 1.0));
  }

  private shotSun(id: number, s: ShotDef, az0: number, el0: number) {
    let v = this.sunCache.get(id);
    if (v) return v;
    let fx = 0, fz = 0;
    for (let f = s.a; f < s.b; f += 3) {
      const c = camAt(id, f), x = c.look[0] - c.pos[0], z = c.look[2] - c.pos[2], n = Math.hypot(x, z) || 1;
      fx += x / n; fz += z / n;
    }
    const n = Math.hypot(fx, fz) || 1; fx /= n; fz /= n;
    const az = THREE.MathUtils.degToRad(az0), el = THREE.MathUtils.degToRad(el0);
    const hx = fx * Math.cos(az) - fz * Math.sin(az), hz = fz * Math.cos(az) + fx * Math.sin(az);
    v = new THREE.Vector3(hx * Math.cos(el), Math.sin(el), hz * Math.cos(el)).normalize();
    this.sunCache.set(id, v);
    return v;
  }
  private actor(i: number) { while (this.actors.length <= i) this.actors.push(new Actor(this.root)); return this.actors[i]; }
  private fx(i: number) { while (this.fxs.length <= i) this.fxs.push(new Fx(this.root)); return this.fxs[i]; }

  // ---------------- main-scene posing ----------------
  private poseMain(st: number, t: number, id: number, tub: boolean) {
    const hr = holeR(st), fu = funnel(st), Rf = funnelR(st);
    const bp = this.bedP, h0 = Math.max(0.02, hr);
    for (let k = 0; k < bp.nr; k++) {
      const u = k / (bp.nr - 1);
      const r = u < 0.55 ? h0 + (LR - 4 - h0) * (u / 0.55) ** 1.4 : LR - 4 + 4 * ((u - 0.55) / 0.45);
      for (let j = 0; j <= bp.ns; j++) {
        const th = (j / bp.ns) * Math.PI * 2, y = bowl(r), wall = r > LR - 3.4;
        const n = rnd(Math.floor(th * 9) + k * 3, 1);
        tmpC.copy(wall ? (Math.floor(th * 14) % 2 ? BED.wall : BED.wallDark) : BED.mud).lerp(BED.mudDark, wall ? 0 : 0.35 * (1 - r / LR) + 0.25 * n);
        bp.set(k, j, Math.cos(th) * r, y, Math.sin(th) * r, tmpC);
      }
    }
    bp.done();
    this.shaft.scale.set(h0, 1, h0); this.shaft.position.y = bowl(h0); this.shaft.visible = hr > 0.05;
    const wp = this.waterP, spin = (t * 0.9 + (st > T_PUNCH ? (st - T_PUNCH) * 0.5 : 0)) * (0.4 + fu);
    for (let k = 0; k < wp.nr; k++) {
      const r = LR * (k / (wp.nr - 1)) ** 1.7;
      for (let j = 0; j <= wp.ns; j++) {
        const th = (j / wp.ns) * Math.PI * 2, x = Math.cos(th) * r, z = Math.sin(th) * r;
        let y = waterY(x, z, st);
        if (y <= bowl(r) + 0.04 || (hr > 0.05 && r < hr)) y = r < hr ? Math.min(y, FLOOR) - 14 : bowl(r) - 0.6;
        const rn = rnd(Math.floor(th * 7) + k * 5, 2);
        tmpC.copy(WC.mid).lerp(WC.deep, smooth(r / LR) * 0.7).lerp(WC.light, rn * 0.12);
        const w = fu * Math.exp(-((r / (Rf * 2.6)) ** 2));
        if (w > 0.01) {
          const phase = 3 * th + 2.4 * Math.log(1 + r) - spin * 3.2, s = 0.5 + 0.5 * Math.sin(phase);
          tmpC.lerp(WC.dark, w * 0.55 * smooth((s - 0.2) / 0.5));
          tmpC.lerp(WC.foam, w * smooth((s - 0.82) / 0.12) * 0.9);
          tmpC.lerp(WC.dark, w * smooth(1 - r / (hr + 4)) * 0.6);
        }
        wp.set(k, j, x, y, z, tmpC);
      }
    }
    wp.done();
    // rig: tilt, lean, sink into the funnel; pipe hangs to the bed
    const tilt = rigTilt(st), sink = rigSink(st);
    this.rig.visible = !tub && sink < 0.995 && st < 40;
    this.rig.rotation.set(0, 0, -tilt);
    this.rig.position.set(-sink * 4, WL - sink * 24, 0);
    setPipe(this.rig, FLOOR - 1, t, st > T_STUCK && st < T_PUNCH ? 0.1 * Math.sin(t * 38) : 0);
    // barges: calm formation, spiral into the funnel, then pop back up
    const formation = (i: number): [number, number] => [6 + (i % 4) * 8 + (i % 2) * 1.5, 13 + (i >> 2) * 9];
    this.barges.forEach((g, i) => {
      const [fx, fz] = formation(i), r0 = Math.hypot(fx, fz), th0 = Math.atan2(fz, fx);
      const d = T_SWALLOW - 0.8 + (i % 6) * 0.45 + (i >> 3) * 0.3, u = clamp01((st - d) / 2.7);
      const bob = 0.18 * Math.sin(t * 1.3 + i * 1.9);
      let x = fx, z = fz, yaw = rnd(i, 3) * 0.3 - 0.15, y = waterY(fx, fz, st) + bob, roll = 0, pitch = 0, vis = true;
      if (st >= d && st < T_BARGES) {
        const rr = r0 * (1 - u ** 1.6), th = th0 + u * 7.5 + u * u * 4;
        x = Math.cos(th) * rr; z = Math.sin(th) * rr;
        yaw = -th + Math.PI / 2 + u * 3; y = waterY(x, z, st) - 0.2 - 4 * u ** 3;
        roll = 0.9 * u; pitch = 0.5 * u;
        vis = u < 0.995 && rr > Math.max(0.5, hr * 0.6);
      } else if (st >= T_BARGES) {
        if (i >= 9) vis = false;
        else {
          const rise = clamp01((st - (T_BARGES + 0.35 * i)) / 1.4), wob = Math.sin(rise * 12) * (1 - rise) * 0.6;
          const ax = -14 + (i % 5) * 9, az = 8 + (i >> 1) * 5;
          x = ax; z = az; y = waterY(ax, az, st) - 5 * (1 - rise) ** 2 + wob * 0.5 + bob * rise;
          yaw = rnd(i, 7) * 1.2 - 0.6; roll = wob * 0.3; vis = rise > 0.02;
        }
      }
      g.visible = tub ? true : vis;
      g.position.set(x, y, z); g.rotation.set(pitch, yaw, roll, "YXZ");
    });
    const tu = clamp01((st - (T_SWALLOW + 1.2)) / 2.4), tf: [number, number] = [-6, 28], tr = Math.hypot(...tf), tth = Math.atan2(tf[1], tf[0]);
    {
      const rr = tr * (1 - tu ** 1.6), th = tth + tu * 7 + tu * tu * 4;
      const sunk = st >= T_SWALLOW + 1.2 && (tu >= 0.995 || rr < Math.max(0.5, hr * 0.6));
      const x = tu > 0 ? Math.cos(th) * rr : tf[0], z = tu > 0 ? Math.sin(th) * rr : tf[1];
      this.tug.visible = !sunk && !tub; this.tug.position.set(x, waterY(x, z, st) - (tu > 0 ? 0.3 + 4 * tu ** 3 : 0) + 0.15 * Math.sin(t * 1.6), z);
      this.tug.rotation.set(0.5 * tu, tu > 0 ? -th + Math.PI / 2 + tu * 3 : -0.3, 0.9 * tu, "YXZ");
    }
    const iu = smooth((st - 29.4) / 3.4);
    this.island.visible = iu < 0.995 && !tub;
    this.island.position.set(-20 + 14 * iu, -9 * iu ** 1.5, -18 + 13 * iu); this.island.rotation.set(0.3 * iu, iu * 2, 0.4 * iu);
    const bu = smooth((st - 26.6) / 5.0), bx = BOAT[0] - 16 * bu, bz = BOAT[2] + 20 * bu;
    this.boat.visible = !tub && st < 42;
    this.boat.position.set(bx, waterY(bx, bz, st) + 0.05 + 0.06 * Math.sin(t * 1.5), bz); this.boat.rotation.set(0, -0.2 + 0.5 * bu, 0.04 * Math.sin(t * 1.1) + 0.08 * bu);
    this.canalTex.offset.y = -(canalFlow(st) * t * 0.9) % 1;
    const fa = fall(st);
    this.fallM.visible = fa > 0.02;
    if (this.fallM.visible) {
      const top = 0.3, bot = Math.max(FLOOR, waterY(0, LR - 3, st)), hgt = Math.max(0.5, top - bot);
      this.fallM.position.set(0, (top + bot) / 2, LR - 2.4); this.fallM.scale.set(9 * Math.min(1, fa * 1.4), hgt, 1);
      this.fallTex.repeat.set(1, Math.max(1, hgt / 8)); this.fallTex.offset.y = (t * 2.2) % 1;
    }
    this.tubRim.visible = tub;
    this.duck.visible = tub; this.duck.position.y = WL + 1.8 + 0.3 * Math.sin(t * 2); this.duck.rotation.y = 0.5 + 0.1 * Math.sin(t);
    this.office.visible = id === 19;
    this.postsG.visible = id >= 21;
    this.postSegs.forEach((segs, pi) => segs.forEach((s, k) => {
      const t0 = pi === 0 ? 66.34 : 66.45 + k * 0.045, u = clamp01((t - t0) / 0.25), e = (u < 1 ? 1 + Math.sin(u * Math.PI) * 0.15 : 1) * smooth(u);
      s.visible = u > 0; s.scale.set(e, e, e);
    }));
  }

  // ---------------- slab posing ----------------
  private poseSlab(st: number, t: number) {
    const hr = holeR(st), hs = Math.max(0.9, hr * 0.85), W = ROOM_X;
    this.gapL.scale.x = Math.max(0.001, (W - hs) / W); this.gapL.position.x = -(hs + (W - hs) / 2);
    this.gapR.scale.x = Math.max(0.001, (W - hs) / W); this.gapR.position.x = hs + (W - hs) / 2;
    const k = (SLAB_FLOOR + 0.6 - WL) / (-10.7 - WL), lvl = WL + (lakeLevel(st) - WL) * k, fu = funnel(st);
    const N = 61, pos = new Float32Array(N * 4 * 3), idx: number[] = [];
    for (let i = 0; i < N; i++) {
      const x = -LAKE_HW + (2 * LAKE_HW * i) / (N - 1), d = fu * 6.5 * Math.exp(-((x / 6.5) ** 2));
      const top = Math.max(SLAB_FLOOR + 0.05, lvl - d), hole = Math.abs(x) < hs && st > T_PUNCH - 0.5;
      const y = hole ? Math.min(top, SLAB_FLOOR + 0.05) : top;
      pos.set([x, SLAB_FLOOR, SZ + 0.03, x, y, SZ + 0.03, x, y, SZ + 0.03, x, y, SO[2] - 5.9], i * 12);
    }
    for (let i = 0; i < N - 1; i++) {
      const a = i * 4, b = (i + 1) * 4;
      idx.push(a, b, b + 1, a, b + 1, a + 1, a + 2, b + 2, b + 3, a + 2, b + 3, a + 3);
    }
    this.slabWaterGeo.setAttribute("position", new THREE.BufferAttribute(pos, 3)); this.slabWaterGeo.setIndex(idx); this.slabWaterGeo.computeVertexNormals();
    const mw = Math.max(0.02, mineWater(st));
    this.roomWater.scale.y = mw; this.roomWater.position.y = ROOM_BOT + mw / 2;
    const flow = st > T_PUNCH ? Math.min(1, (st - T_PUNCH) / 0.6) : 0, pw = Math.max(0.2, hs * 1.3) * flow;
    const topY = ROOM_TOP + 0.3, botY = ROOM_BOT + mw;
    this.pour.visible = flow > 0.02; this.pour.scale.set(Math.max(0.01, pw), Math.max(0.1, topY - botY), 1); this.pour.position.set(0, (topY + botY) / 2, SO[2]);
    const pk = pillarK(st);
    this.pillars.forEach((p) => { p.scale.set(pk, 1, pk); });
    this.chunks.forEach((c, i) => {
      const u = clamp01((st - 50.6 - i * 0.35) / 0.9); c.visible = st > 50.6 + i * 0.35 && st < 70;
      c.position.y = ROOM_TOP - 1 - u * u * (ROOM_TOP - ROOM_BOT - 3 - mw * 0.5); c.rotation.set(u * 3, u * 2, u);
    });
    const tilt = rigTilt(st), sink = rigSink(st), tp = plugUp(t);
    this.slabRig.visible = sink < 0.995 && st < 40;
    this.slabRig.position.set(-sink * 3, WL - sink * 26, SO[2]); this.slabRig.rotation.set(0, 0, -tilt);
    let bit = st < T_PUNCH ? lin([[10, -18], [T_STUCK, -46.4], [T_PUNCH, -46.4]], st) : lin([[T_PUNCH, ROOM_TOP + 1], [T_PUNCH + 0.4, ROOM_TOP - 4], [30, ROOM_TOP - 6]], st);
    if (tp > 0) bit += tp * 26;
    setPipe(this.slabRig, bit, t, st > T_STUCK && st < T_PUNCH ? 0.14 * Math.sin(t * 38) : 0);
  }

  // ---------------- bath + desk posing ----------------
  private poseBath(t: number) {
    const drain = clamp01((t - BATH_PLUG) / 2.2), lvl = Math.max(0.03, 1.15 * (1 - smooth(drain)));
    const top = 0.92 + lvl;
    this.tubWater.scale.y = lvl; this.tubWater.position.y = 0.92 + lvl / 2; this.tubWater.visible = lvl > 0.05;
    this.tubSwirl.position.set(0, top + 0.01, 0); this.tubSwirl.rotation.y = -t * (2 + 8 * drain); this.tubSwirl.scale.setScalar(0.4 + 1.6 * drain);
    this.tubSwirl.visible = drain > 0.02 && drain < 0.97;
    const pu = smooth((t - BATH_PLUG) / 0.5);
    this.plug.position.set(0, 0.96 + pu * 1.3, 0); this.chain.scale.set(1, 0.5 + pu * 1.0, 1); this.chain.position.set(0, 0.96 + pu * 1.3 + (0.5 + pu * 1.0) / 2, 0);
    // toys float on the water, then spiral down the drain with it
    this.bathToys.children.forEach((c, i) => {
      const r0 = [2.2, 3.0, 1.2][i], th0 = [0.6, 2.7, 4.4][i], u = clamp01((drain - 0.1 * i) / 0.9), r = r0 * (1 - u ** 1.5) + 0.05, th = th0 + u * 9 + 0.25 * Math.sin(t + i);
      c.position.set(Math.cos(th) * r * 1.3, top + [0.1, 0.12, 0.1][i] - 0.5 * u ** 3, Math.sin(th) * r * 0.55);
      c.rotation.set(0.6 * u, -th + 1.5 + 3 * u, 0.5 * u);
      c.visible = u < 0.985;
    });
  }
  private poseDesk(t: number) {
    this.stacks.forEach((s, i) => { const u = clamp01((t - (59.5 + i * 0.2)) / 0.25); s.visible = u > 0; const e = smooth(u) * (1 + 0.12 * Math.sin(u * Math.PI)); s.scale.set(e, e * (1 + (i % 3) * 0.25), e); });
    this.bags.forEach((s, i) => { const u = clamp01((t - (60.2 + i * 0.25)) / 0.25); s.visible = u > 0; s.scale.setScalar(smooth(u)); });
  }

  update(id: number, f: number, cam: THREE.PerspectiveCamera, scene: THREE.Scene) {
    const t = f / FPS, s = SHOTS[id - 1], st = s.tau(t), L = LIGHTS[s.light];
    const c = camAt(id, f);
    cam.position.set(...c.pos); cam.up.set(0, 1, 0); cam.lookAt(...c.look); cam.rotateZ(c.roll);
    cam.fov = c.fov; cam.near = 0.2; cam.far = 1500; cam.updateProjectionMatrix(); cam.updateMatrixWorld();
    const focus = V(...c.look), dist = cam.position.distanceTo(focus);
    cam.layers.enable(NOINK);
    this.gMain.visible = s.place === "main"; this.gSlab.visible = s.place === "slab"; this.gBath.visible = s.place === "bath"; this.gDesk.visible = s.place === "desk";
    if (s.place === "main") this.poseMain(st, t, id, !!s.tub);
    else if (s.place === "slab") this.poseSlab(st, t);
    else if (s.place === "bath") this.poseBath(t);
    else this.poseDesk(t);
    const K = LOOK[s.light], sunDir = this.shotSun(id, s, s.place === "main" ? L.az : 150, s.place === "main" ? L.el : Math.max(L.el, 45));
    if (s.light === "golden") this.waterMat.color.setRGB(2.0, 0.95, 0.8); else this.waterMat.color.setRGB(1.3, 1.3, 1.2);
    this.hemi.color.set(L.sky); this.hemi.groundColor.set(L.ground); this.hemi.intensity = L.hemiI;
    this.sun.color.set(L.sunCol); this.sun.intensity = L.sunI;
    let Rr = THREE.MathUtils.clamp(dist * 1.15 + 7, 12, 95);
    if (s.light === "golden") Rr = Math.max(Rr, 30);
    this.sun.position.copy(focus).addScaledVector(sunDir, 220); this.sun.target.position.copy(focus);
    const sc = this.sun.shadow.camera;
    sc.left = -Rr; sc.right = Rr; sc.top = Rr; sc.bottom = -Rr; sc.near = 20; sc.far = 480; sc.updateProjectionMatrix();
    this.sun.shadow.bias = L.bias; this.sun.shadow.normalBias = L.normalBias * (Rr / 12);
    this.fill.intensity = 0;
    TONE.uLitCol.value.set(...L.lit); TONE.uShadeCol.value.set(...L.shade); TONE.uShadeLift.value.set(...L.lift);
    TONE.uLambert.value = L.lambert; TONE.uSideK.value = L.sideK; TONE.uTerm.value = L.term; TONE.uBounce.value.set(...K.bounce); TONE.uSat.value = K.sat;
    CHAR.uCharTint.value.set(...L.charTint); CHAR.uCharShade.value = L.charShade; CHAR.uGrad.value = L.charGrad;
    CHAR.uBodyGrad.value = L.bodyGrad; CHAR.uSideTint.value.set(...L.sideTint);
    const su = this.skyMat.uniforms;
    K.sky.c.forEach((h, i) => untone(h, su["c" + i].value));
    const e = K.sky.e.map((deg) => THREE.MathUtils.degToRad(deg));
    su.e.value.set(e[1], e[2], e[3], e[4]);
    this.sky.position.copy(cam.position);
    untone(L.fog, this.fog.color);
    const mainPlace = s.place === "main";
    this.fog.near = mainPlace ? L.fogNear : 140; this.fog.far = mainPlace ? L.fogFar : 800;
    scene.fog = this.fog; scene.background = null;
    const showSun = s.light === "golden";
    this.sunDisc.visible = this.sunHalo.visible = showSun;
    if (showSun) {
      this.sunDisc.position.copy(cam.position).addScaledVector(sunDir, 900);
      this.sunDisc.scale.setScalar(2 * 900 * Math.tan(THREE.MathUtils.degToRad(1.7)));
      this.sunHalo.position.copy(this.sunDisc.position); this.sunHalo.scale.setScalar(2 * 900 * Math.tan(THREE.MathUtils.degToRad(24)));
      (this.sunHalo.material as THREE.SpriteMaterial).color.set(L.sunDisc).multiplyScalar(1.3);
    }
    for (let i = 0; i < this.clouds.length; i++) {
      const m = this.clouds[i], mm = m.material as THREE.MeshBasicMaterial;
      m.lookAt(cam.position.x, m.position.y, cam.position.z);
      mm.map = this.cloudMaps[s.light][i % 4];
    }
    // ---- cast + effects ----
    const right = V(0, 0, 0).setFromMatrixColumn(cam.matrixWorld, 0);
    const stg = stage(id, t, st, { pos: cam.position, right, sun: sunDir });
    this.frustum.setFromProjectionMatrix(this.m4.multiplyMatrices(cam.projectionMatrix, cam.matrixWorldInverse));
    const tint = s.light === "golden" ? "#ffcf9e" : "#ffffff";
    let ai = 0;
    const used: Actor[] = [];
    for (const p of stg.places) {
      const sc2 = p.scale ?? 1;
      if (!this.frustum.intersectsSphere(this.sphere.set(this.v.set(p.x, p.y + 1.1 * sc2, p.z), 3.5))) continue;
      const a = this.actor(ai++);
      const [w, h, k] = p.size ?? [300, 500, 0.5];
      a.r = this.pool.req(p.key, w, h, k, p.draw);
      a.mesh.visible = true;
      a.mesh.position.set(p.x, p.y, p.z);
      a.mesh.rotation.set(0, p.yaw ?? Math.atan2(cam.position.x - p.x, cam.position.z - p.z), p.roll ?? 0);
      a.mesh.scale.set(p.mirror ? -sc2 : sc2, sc2, sc2);
      if (a.mat.emissiveMap) a.mat.emissive.set(tint);
      a.mesh.castShadow = L.actorShadow;
      used.push(a);
    }
    for (let i = ai; i < this.actors.length; i++) this.actors[i].mesh.visible = false;
    let fi = 0;
    const fused: Fx[] = [];
    for (const p of stg.fx) {
      if (!this.frustum.intersectsSphere(this.sphere.set(this.v.set(p.x, p.y, p.z), Math.max(p.w, p.h)))) continue;
      const e2 = this.fx(fi++);
      e2.r = this.pool.req(p.key, p.cw, p.ch, 1, p.draw);
      e2.use(!!p.soft);
      e2.mesh.visible = true;
      e2.mesh.position.set(p.x, p.y, p.z);
      if (p.flat) e2.mesh.rotation.set(-Math.PI / 2, 0, p.rot ?? 0);
      else { e2.mesh.quaternion.copy(cam.quaternion); e2.mesh.rotateZ(p.rot ?? 0); }
      e2.mesh.scale.set(p.w, p.h, 1);
      fused.push(e2);
    }
    for (let i = fi; i < this.fxs.length; i++) this.fxs[i].mesh.visible = false;
    this.pool.flush();
    for (const a of used) a.bind();
    for (const e3 of fused) e3.bind();
    return focus;
  }
}
