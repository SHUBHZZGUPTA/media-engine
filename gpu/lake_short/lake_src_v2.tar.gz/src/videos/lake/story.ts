// "The Lake That Went Down the Drain": timeline of the Lake Peigneur short (Louisiana, 20 Nov 1980).
// Shots are timed to the narration words (~/lake-short/voice/words.json). Camera grammar from the bridge short:
// continuous slow push-ins, smootherstep glides of 18-40 f, hard cuts on big reframes, 7-frame impact kicks.
// Four places: MAIN (the lake and its shore at the origin), SLAB (a cross-section of lake + earth + salt mine, far
// away at z = 600) and two small sets (BATH and DESK) for the bathtub and the settlement.
export const FPS = 30;
export const TOTAL = 2076;
export const D0 = 0; // ground level (build.ts imports it)
export type V3 = [number, number, number];

export const clamp01 = (x: number) => Math.max(0, Math.min(1, x));
export const smooth = (x: number) => { const u = clamp01(x); return u * u * (3 - 2 * u); };
export const easeOut = (u: number) => 1 - (1 - clamp01(u)) ** 4;
export const lin = (pts: [number, number][], x: number) => {
  if (x <= pts[0][0]) return pts[0][1];
  for (let i = 1; i < pts.length; i++) if (x <= pts[i][0]) {
    const [x0, y0] = pts[i - 1], [x1, y1] = pts[i];
    return y0 + ((y1 - y0) * (x - x0)) / (x1 - x0);
  }
  return pts[pts.length - 1][1];
};
/** smooth version of lin (smoothstep between the points) */
export const slin = (pts: [number, number][], x: number) => {
  if (x <= pts[0][0]) return pts[0][1];
  for (let i = 1; i < pts.length; i++) if (x <= pts[i][0]) {
    const [x0, y0] = pts[i - 1], [x1, y1] = pts[i];
    return y0 + (y1 - y0) * smooth((x - x0) / (x1 - x0));
  }
  return pts[pts.length - 1][1];
};

// ---------------- places ----------------
export const LR = 46; // lake radius (m)
export const FLOOR = -12; // lake bed at the centre (cartoon depth, so the drain reads)
export const WL = -0.5; // lake surface
export const SO: V3 = [0, 0, 600]; // cross-section slab: centre of its 12 m thickness
export const SZ = SO[2] + 6; // the cut face of the slab (cameras look at it from +z)
export const SLAB_W = 24, SLAB_TOP = 0, SLAB_BOT = -76; // half width, ground level, bottom
export const LAKE_HW = 17; // half width of the lake in the slab
export const SLAB_FLOOR = -9; // lake bed in the slab
export const ROOM_X = 19, ROOM_TOP = -50, ROOM_BOT = -64; // salt mine room in the slab
export const BATH: V3 = [600, 0, 0];
export const DESK: V3 = [-600, 0, 0];

// ---------------- story physics (st = story time in seconds, = narration time except in the hook) ----------------
export const T_STUCK = 18.3, T_TILT0 = 21.3, T_PUNCH = 24.76, T_WHIRL = 27.84, T_SWALLOW = 29.2, T_CANAL = 33.9;
export const T_DRAINED = 38.3, T_PLUG = 48.66, T_REFILL0 = 60.8, T_REFILL1 = 65.4, T_BARGES = 62.4;
export const holeR = (st: number) => lin([[T_PUNCH - 0.1, 0], [T_PUNCH + 0.3, 0.7], [28, 2.4], [33, 5.2], [45, 7.2], [53.5, 11], [70, 11]], st);
export const lakeLevel = (st: number) =>
  st < T_REFILL0 ? slin([[T_PUNCH + 0.2, WL], [27.8, -0.9], [33, -5.2], [38, -10.7], [56, -10.7]], st) : slin([[T_REFILL0, -10.7], [T_REFILL1, WL]], st);
export const funnel = (st: number) => lin([[T_PUNCH + 0.3, 0], [T_WHIRL, 0.45], [30.5, 1], [40, 0.9], [46, 0.2], [51, 0]], st);
export const rigTilt = (st: number) => slin([[T_TILT0, 0], [23.5, 0.05], [T_PUNCH + 0.4, 0.2], [27.7, 0.42], [29.3, 0.8]], st);
export const rigSink = (st: number) => smooth((st - 29.2) / 2.6);
export const mineWater = (st: number) => lin([[T_PUNCH + 0.2, 0], [29, 1.6], [38, 7], [47, 12.5], [70, 13]], st); // m of water in the mine
export const canalFlow = (st: number) => (st < T_CANAL ? 1 : -1); // +1 = towards the Gulf (normal), -1 = backwards
export const fall = (st: number) => clamp01((st - T_CANAL) / 0.5) * (1 - clamp01((st - 41.5) / 3)); // waterfall strength
export const pillarK = (st: number) => lin([[50.2, 1], [53.2, 0.42], [60, 0.4]], st); // salt pillars dissolving
/** t = narration time: the drill bit is pulled up like a plug on "pulled the plug" */
export const plugUp = (t: number) => smooth((t - T_PLUG) / 1.6);
export const BATH_PLUG = 43.92; // "Pull the plug"
export const BARGES = 11;

// ---------------- shots ----------------
export type Light = "day" | "golden";
export type Place = "main" | "slab" | "bath" | "desk";
export type ShotDef = { id: number; a: number; b: number; light: Light; place: Place; tau: (t: number) => number; tub?: boolean };
export const SHOTS: ShotDef[] = [
  { id: 1, a: 0, b: 130, light: "day", place: "main", tau: (t) => 29.1 + t }, // hook (flash-forward into the whirlpool)
  { id: 2, a: 130, b: 181, light: "golden", place: "main", tau: (t) => t },
  { id: 3, a: 181, b: 300, light: "golden", place: "main", tau: (t) => t },
  { id: 4, a: 300, b: 363, light: "golden", place: "main", tau: (t) => t },
  { id: 5, a: 363, b: 442, light: "day", place: "main", tau: (t) => t },
  { id: 6, a: 442, b: 548, light: "day", place: "slab", tau: (t) => t },
  { id: 7, a: 548, b: 639, light: "day", place: "slab", tau: (t) => t },
  { id: 8, a: 639, b: 721, light: "day", place: "main", tau: (t) => t },
  { id: 9, a: 721, b: 835, light: "day", place: "slab", tau: (t) => t },
  { id: 10, a: 835, b: 876, light: "day", place: "main", tau: (t) => t },
  { id: 11, a: 876, b: 1017, light: "day", place: "main", tau: (t) => t },
  { id: 12, a: 1017, b: 1149, light: "day", place: "main", tau: (t) => t },
  { id: 13, a: 1149, b: 1216, light: "day", place: "main", tau: (t) => t },
  { id: 14, a: 1216, b: 1285, light: "day", place: "main", tau: (t) => t },
  { id: 15, a: 1285, b: 1377, light: "day", place: "bath", tau: (t) => t },
  { id: 16, a: 1377, b: 1413, light: "day", place: "main", tau: () => 8, tub: true },
  { id: 17, a: 1413, b: 1485, light: "day", place: "slab", tau: (t) => 26 + (t - 47.1) * 0.5 },
  { id: 18, a: 1485, b: 1625, light: "day", place: "slab", tau: (t) => t },
  { id: 19, a: 1625, b: 1781, light: "day", place: "main", tau: (t) => t },
  { id: 20, a: 1781, b: 1873, light: "day", place: "desk", tau: (t) => t },
  { id: 21, a: 1873, b: 1990, light: "day", place: "main", tau: (t) => t },
  { id: 22, a: 1990, b: TOTAL, light: "golden", place: "main", tau: (t) => t },
];
/** crossfades (frames) at place/time changes; a white 4-frame flash after the hook */
export const XFADE: Record<number, number> = { 5: 6, 20: 8, 21: 8, 22: 10 };
export const FLASH_AT = 130;

export const shotAt = (f: number) => SHOTS.find((s) => f >= s.a && f < s.b) ?? SHOTS[SHOTS.length - 1];
export const layersAt = (f: number): { id: number; alpha: number }[] => {
  for (const s of SHOTS) {
    const x = XFADE[s.id];
    if (x && f >= s.a - x / 2 && f < s.a + x / 2) return [{ id: s.id - 1, alpha: 1 }, { id: s.id, alpha: (f - (s.a - x / 2) + 1) / (x + 1) }];
  }
  return [{ id: shotAt(f).id, alpha: 1 }];
};

// ---------------- camera ----------------
export type Cam = { pos: V3; look: V3; fov: number; roll: number };
type Shot = Partial<Cam> & { pos: V3; look: V3 };
type Key = { f: number; dur?: number; cut?: boolean; s: (f: number) => Shot };
export const glide = (u: number) => { const x = clamp01(u); return x * x * x * (x * (6 * x - 15) + 10); };
const mix = (a: Cam, b: Cam, k: number): Cam => ({
  pos: a.pos.map((v, i) => v + (b.pos[i] - v) * k) as V3, look: a.look.map((v, i) => v + (b.look[i] - v) * k) as V3,
  fov: a.fov + (b.fov - a.fov) * k, roll: a.roll + (b.roll - a.roll) * k,
});
const full = (c: Shot): Cam => ({ fov: 40, roll: 0, ...c });
const run = (keys: Key[], f: number) => {
  let cur = full(keys[0].s(f));
  for (let i = 1; i < keys.length; i++) {
    const k = keys[i];
    if (f < k.f) break;
    cur = k.cut ? full(k.s(f)) : mix(cur, full(k.s(f)), glide((f - k.f) / (k.dur ?? 24)));
  }
  return cur;
};
export const T = (f: number) => f / FPS;
const pushK = (f: number, f0: number, rate: number, punch = 0, n = 35) => {
  const x = Math.max(0, f - f0);
  let s = rate * x;
  if (punch > rate) for (let i = 0; i < Math.min(x, n); i++) s += (punch - rate) * Math.max(0, Math.min(1, (i + 0.5) / 8, (n - i - 0.5) / 8));
  return Math.exp(-s);
};
const dolly = (pos: V3, look: V3, k: number, rest: Partial<Cam> = {}): Shot =>
  ({ pos: [look[0] + (pos[0] - look[0]) * k, look[1] + (pos[1] - look[1]) * k, look[2] + (pos[2] - look[2]) * k], look, ...rest });
const rolled = (s: (f: number) => Shot, roll: number) => (f: number): Shot => ({ ...s(f), roll });

/** where the fisherman's boat sits (the CU looks at it) */
export const BOAT: V3 = [-16, WL, 24];
export const SLAB_AT = (x: number, y: number, d: number): V3 => [SO[0] + x, y, SZ + d]; // d metres in front of the cut face
export const SHORE: V3 = [-26, 0, 40];
export const OFFICE: V3 = [30, 0, 54];
export const POSTS: V3[] = [[-8, WL, -12], [8, WL, -12]];

// shot 1: flash-forward, whirlpool from above, then lower and closer
const S1a = (f: number) => dolly([18, 50, 72], [0, -4, -2], pushK(f, 0, 0.003), { fov: 54 });
const S1b = (f: number) => dolly([-25, 19, 40], [0, -3, 0], pushK(f, 40, 0.003), { fov: 52, roll: -0.04 });
const S1c = (f: number) => dolly([7, 2.2, 26], [0, 1.5, 0], pushK(f, 85, 0.003), { fov: 42, roll: 0.04 });
// shots 2-4: calm golden morning, then the fisherman
const S2a = (f: number) => dolly([-31, 4.5, 62], [2, 5.5, 0], pushK(f, 130, 0.0025), { fov: 46 });
const S3a = (f: number) => dolly([-24, 3.2, 40], [-8, 10, 2], pushK(f, 181, 0.0018), { fov: 60 });
const S3b = (f: number) => dolly([-6, 3.4, 44], [-15, 3.5, 22], pushK(f, 236, 0.002), { fov: 46, roll: -0.03 });
const S4a = (f: number) => dolly([-12.2, 1.9, 28.4], [-16.1, 1.55, 24], pushK(f, 300, 0.0025), { fov: 33 });
// shot 5: the rig, then low at the rotating pipe
const S5a = (f: number) => dolly([38, 17, 50], [0, 11, 0], pushK(f, 363, 0.002), { fov: 52 });
const S5b = (f: number) => dolly([11, 4.2, 31], [0, 12, 0], pushK(f, 400, 0.003), { fov: 50, roll: 0.04 });
// shots 6-7, 9, 17-18: the slab (cross-section)
const S6a = (f: number) => dolly(SLAB_AT(0, -57.5, 27), [0, -58, SO[2]], pushK(f, 442, 0.002), { fov: 40 });
const S6b = (f: number) => dolly(SLAB_AT(3, -58.5, 17), [2, -59.5, SO[2]], pushK(f, 490, 0.003), { fov: 38, roll: -0.035 });
const S7a = (f: number) => dolly(SLAB_AT(0, -25, 120), [0, -25, SO[2]], pushK(f, 548, 0.0012), { fov: 46 });
const S7b = (f: number) => dolly(SLAB_AT(0, -44, 34), [0, -47, SO[2]], pushK(f, 585, 0.003, 0.006, 30), { fov: 38, roll: 0.04 });
const S9a = (f: number) => dolly(SLAB_AT(0, -48, 40), [0, -53, SO[2]], pushK(f, 721, 0.0025, 0.006, 35), { fov: 40 });
const S9b = (f: number) => dolly(SLAB_AT(3, -58, 36), [1, -58, SO[2]], pushK(f, 765, 0.003), { fov: 40, roll: -0.04 });
const S17a = (f: number) => dolly(SLAB_AT(0, -50, 56), [0, -55, SO[2]], pushK(f, 1413, 0.002), { fov: 42 });
const S17b = (f: number) => dolly(SLAB_AT(0, -50, 30), [0, -53, SO[2]], pushK(f, 1450, 0.0035, 0.007, 30), { fov: 38, roll: 0.04 });
const S18a = (f: number) => dolly(SLAB_AT(0, -30, 98), [0, -31, SO[2]], pushK(f, 1485, 0.0022), { fov: 46 });
const S18b = (f: number) => dolly(SLAB_AT(0, -48, 52), [0, -50, SO[2]], pushK(f, 1560, 0.003), { fov: 44, roll: -0.035 });
// shot 8: the rig tilts
const S8a = (f: number) => dolly([34, 12, 44], [0, 15, 0], pushK(f, 639, 0.0025), { fov: 52 });
const S8b = (f: number) => dolly([22, 9, 34], [0, 15, 0], pushK(f, 680, 0.003, 0.006, 30), { fov: 52, roll: -0.06 });
// shots 10-12: whirlpool, swallow, canal + waterfall
const S10a = (f: number) => dolly([20, 34, 52], [0, -4, 0], pushK(f, 835, 0.003), { fov: 46 });
const S11a = (f: number) => dolly([-8, 22, 50], [0, -2, 0], pushK(f, 876, 0.002), { fov: 54 });
const S11b = (f: number) => dolly([14, 5, 40], [0, 1, 0], pushK(f, 930, 0.003, 0.006, 30), { fov: 50, roll: 0.05 });
const S11c = (f: number) => dolly([-6, 30, 40], [0, -6, -2], pushK(f, 975, 0.003), { fov: 54 });
const S12a = (f: number) => dolly([-14, 3, 20], [0, -3, LR - 2], pushK(f, 1017, 0.0022), { fov: 48 });
const S12b = (f: number) => dolly([26, 12, 6], [0, -2, LR - 2], pushK(f, 1070, 0.0025), { fov: 50, roll: -0.04 });
// shots 13-14: people on the shore, then the empty bed
const S13a = (f: number) => dolly([-18.5, 1.3, 45.5], [SHORE[0] - 0.5, 1.7, SHORE[2]], pushK(f, 1149, 0.002), { fov: 40 });
const S14a = (f: number) => dolly([-4, 9, 66], [0, -5, 4], pushK(f, 1216, 0.0025, 0.005, 40), { fov: 46, roll: 0.03 });
// shot 15-16: the bathtub, then the lake as a tub
const S15a = (f: number) => dolly([BATH[0] + 3, 7.5, BATH[2] + 11], [BATH[0], 1.4, BATH[2]], pushK(f, 1285, 0.002), { fov: 42 });
const S15b = (f: number) => dolly([BATH[0] + 1.6, 6.0, BATH[2] + 6], [BATH[0] + 0.4, 1.0, BATH[2]], pushK(f, 1330, 0.003, 0.006, 30), { fov: 38, roll: -0.04 });
const S16a = (f: number) => dolly([-24, 30, 92], [0, 0, 0], pushK(f, 1377, 0.002), { fov: 46 });
// shot 19: the report (two officials argue over a drill bit and a map)
const S19a = (f: number) => dolly([OFFICE[0], 2.3, OFFICE[2] + 19], [OFFICE[0], 1.5, OFFICE[2] + 0.8], pushK(f, 1625, 0.002), { fov: 42 });
const S19b = (f: number) => dolly([OFFICE[0] + 4.6, 1.9, OFFICE[2] + 8], [OFFICE[0] + 3.2, 1.7, OFFICE[2] + 0.8], pushK(f, 1672, 0.003), { fov: 36, roll: 0.04 });
const S19c = (f: number) => dolly([OFFICE[0] - 4.6, 1.9, OFFICE[2] + 8], [OFFICE[0] - 3.2, 1.7, OFFICE[2] + 0.8], pushK(f, 1720, 0.003, 0.006, 30), { fov: 36, roll: -0.04 });
// shot 20: money
const S20a = (f: number) => dolly([DESK[0] - 0.4, 1.9, DESK[2] + 9.5], [DESK[0] + 0.0, 2.0, DESK[2]], pushK(f, 1781, 0.0025, 0.006, 30), { fov: 42 });
const S20b = (f: number) => dolly([DESK[0] + 1.2, 2.2, DESK[2] + 6], [DESK[0] + 0.8, 2.1, DESK[2]], pushK(f, 1826, 0.003), { fov: 36, roll: 0.04 });
// shots 21-22: barges bob back up, then the two gauge posts
const S21a = (f: number) => dolly([30, 14, 56], [-4, 0, 6], pushK(f, 1873, 0.002), { fov: 44 });
const S21b = (f: number) => dolly([-4, 3, 40], [-4, 0.8, 14], pushK(f, 1925, 0.003), { fov: 42, roll: 0.03 });
const S22a = (f: number) => dolly([0, 7, 44], [0, 8, -12], pushK(f, 1990, 0.002), { fov: 40 });
/** crane up the tall post: camera rises while it looks up to the top */
const S22b = (f: number) => {
  const u = glide((f - 2022) / 54);
  return { pos: [0, 7 + 32 * u, 44 + 10 * u] as V3, look: [0, 8 + 40 * u, -12] as V3, fov: 40 + 8 * u, roll: 0 };
};

const CAMS: Record<number, Key[]> = {
  1: [{ f: 0, s: S1a }, { f: 40, cut: true, s: S1b }, { f: 85, cut: true, s: S1c }],
  2: [{ f: 130, s: S2a }],
  3: [{ f: 181, s: S3a }, { f: 236, dur: 30, s: S3b }],
  4: [{ f: 300, s: S4a }],
  5: [{ f: 363, s: S5a }, { f: 400, cut: true, s: S5b }],
  6: [{ f: 442, s: S6a }, { f: 490, cut: true, s: S6b }],
  7: [{ f: 548, s: S7a }, { f: 585, cut: true, s: S7b }],
  8: [{ f: 639, s: S8a }, { f: 680, cut: true, s: S8b }],
  9: [{ f: 721, s: S9a }, { f: 765, cut: true, s: S9b }],
  10: [{ f: 835, s: S10a }],
  11: [{ f: 876, s: S11a }, { f: 930, cut: true, s: S11b }, { f: 975, cut: true, s: S11c }],
  12: [{ f: 1017, s: S12a }, { f: 1070, cut: true, s: S12b }],
  13: [{ f: 1149, s: S13a }],
  14: [{ f: 1216, s: S14a }],
  15: [{ f: 1285, s: S15a }, { f: 1330, cut: true, s: S15b }],
  16: [{ f: 1377, s: S16a }],
  17: [{ f: 1413, s: S17a }, { f: 1450, cut: true, s: S17b }],
  18: [{ f: 1485, s: S18a }, { f: 1560, cut: true, s: S18b }],
  19: [{ f: 1625, s: S19a }, { f: 1672, cut: true, s: S19b }, { f: 1720, cut: true, s: S19c }],
  20: [{ f: 1781, s: S20a }, { f: 1826, cut: true, s: S20b }],
  21: [{ f: 1873, s: S21a }, { f: 1925, cut: true, s: S21b }],
  22: [{ f: 1990, s: S22a }, { f: 2022, dur: 54, s: S22b }],
};

// impact kicks: image offset flips sign every frame, decays in 7 f. Events: the punch-through, the rig falling in, the waterfall
const KICKS: [number, number][] = [[24.76, 1.2], [29.3, 1.0], [33.9, 0.8], [48.66, 0.5]];
export const kickAt = (t: number) => {
  let a = 0;
  for (const [t0, g] of KICKS) {
    const n = Math.floor((t - t0) * FPS + 1e-6);
    if (n >= 0 && n < 7) a += g * (n % 2 ? -1 : 1) * (1 - n / 7) ** 1.5;
  }
  return a;
};
export const camAt = (id: number, f: number): Cam => {
  const c = run(CAMS[id], f), a = kickAt(T(f));
  if (!a) return c;
  const d: V3 = [c.look[0] - c.pos[0], c.look[1] - c.pos[1], c.look[2] - c.pos[2]];
  const L = Math.hypot(...d), h = Math.hypot(d[0], d[2]) || 1;
  const m = (3 / 640) * Math.tan((c.fov * Math.PI) / 360) * L * a;
  return { ...c, look: [c.look[0] - (d[2] / h) * m, c.look[1] + 0.6 * m, c.look[2] + (d[0] / h) * m], roll: c.roll + a * 0.004 };
};
export const keyEnd = (id: number, f: number) => {
  let e = 0;
  for (const k of CAMS[id]) if (f >= k.f) e = k.f + (k.cut ? 0 : k.dur ?? 24);
  return Math.max(f, e);
};

// ---------------- lens: depth of field ----------------
export type Dof = { f: number; dur?: number; cInf: number; focus?: (f: number) => V3 };
export const DOF: Dof[] = [
  { f: 0, cInf: 0 },
  { f: 85, cInf: 12 },
  { f: 130, cInf: 0 },
  { f: 300, cInf: 14 }, // fisherman CU
  { f: 363, cInf: 0 },
  { f: 400, cInf: 10 }, // pipe from below
  { f: 442, cInf: 0 },
  { f: 490, cInf: 12 }, // miners MS
  { f: 548, cInf: 0 },
  { f: 585, cInf: 12 },
  { f: 639, cInf: 0 },
  { f: 721, cInf: 8 },
  { f: 835, cInf: 0 },
  { f: 930, cInf: 8 },
  { f: 975, cInf: 0 },
  { f: 1149, cInf: 10 }, // shore group
  { f: 1216, cInf: 0 },
  { f: 1285, cInf: 10 }, // bath
  { f: 1377, cInf: 0 },
  { f: 1450, cInf: 10 },
  { f: 1485, cInf: 0 },
  { f: 1560, cInf: 12 },
  { f: 1625, cInf: 9 }, // officials
  { f: 1781, cInf: 10 }, // money
  { f: 1873, cInf: 0 },
  { f: 1925, cInf: 10 },
  { f: 1990, cInf: 0 },
];
export const dofAt = (f: number) => {
  let i = 0; while (i + 1 < DOF.length && f >= DOF[i + 1].f) i++;
  const d = DOF[i], p = DOF[Math.max(0, i - 1)];
  const k = d.dur ? Math.min(1, (f - d.f) / d.dur) : 1;
  return { cInf: p.cInf + (d.cInf - p.cInf) * k, focus: d.focus };
};
export const focusAt = (id: number, f: number): V3 => {
  const d = dofAt(f);
  return d.focus ? d.focus(f) : camAt(id, f).look;
};
